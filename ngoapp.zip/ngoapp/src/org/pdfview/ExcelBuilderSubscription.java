package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.dto.SubscriptionMaster;
import org.springframework.web.servlet.view.document.AbstractExcelView;

public class ExcelBuilderSubscription extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		List<SubscriptionMaster> subscriptionlist = (List<SubscriptionMaster>) model.get("subscription");

		HSSFSheet sheet = workbook.createSheet("Esquare");
		sheet.setDefaultColumnWidth(30);

		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);

		HSSFRow header = sheet.createRow(0);

		header.createCell(0).setCellValue("District");
		header.getCell(0).setCellStyle(style);

		header.createCell(1).setCellValue("AddmissionGivenMember");
		header.getCell(1).setCellStyle(style);

		header.createCell(2).setCellValue("AdmissionCollected");
		header.getCell(2).setCellStyle(style);

		header.createCell(3).setCellValue("Balance");
		header.getCell(3).setCellStyle(style);

		header.createCell(4).setCellValue("BalanceAmount");
		header.getCell(4).setCellStyle(style);

		header.createCell(5).setCellValue("Collected");
		header.getCell(5).setCellStyle(style);

		header.createCell(6).setCellValue("Month");
		header.getCell(6).setCellStyle(style);

		header.createCell(7).setCellValue("OfferedAdmission");
		header.getCell(7).setCellStyle(style);

		header.createCell(8).setCellValue("OfferedSubscription");
		header.getCell(8).setCellStyle(style);

		header.createCell(8).setCellValue("SubGivenMember");
		header.getCell(8).setCellStyle(style);

		header.createCell(9).setCellValue("Summary");
		header.getCell(9).setCellStyle(style);

		header.createCell(11).setCellValue("Year");
		header.getCell(11).setCellStyle(style);

		int rowCount = 1;

		for (SubscriptionMaster sublist : subscriptionlist) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue(sublist.getDistrictMaster().getDistrictName());
			aRow.createCell(1).setCellValue(sublist.getAddmissionGivenMember() + "");
			aRow.createCell(2).setCellValue(sublist.getAdmissionCollected() + "");
			aRow.createCell(4).setCellValue(sublist.getBalance() + "");
			aRow.createCell(3).setCellValue(sublist.getBalanceAmount() + "");
			aRow.createCell(5).setCellValue(sublist.getCollected() + "");
			aRow.createCell(6).setCellValue(sublist.getMonth() + "");
			aRow.createCell(7).setCellValue(sublist.getOfferedAdmission() + "");
			aRow.createCell(8).setCellValue(sublist.getOfferedSubscription() + "");
			aRow.createCell(9).setCellValue(sublist.getSubGivenMember() + "");
			aRow.createCell(10).setCellValue(sublist.getSummary() + "");
			aRow.createCell(11).setCellValue(sublist.getYear());
		}

	}

}
