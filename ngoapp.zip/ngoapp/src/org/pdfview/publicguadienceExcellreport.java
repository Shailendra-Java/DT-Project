package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.dto.PublicGuidance;
import org.springframework.web.servlet.view.document.AbstractExcelView;

public class publicguadienceExcellreport extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest arg2,
			HttpServletResponse arg3) throws Exception {
		// TODO Auto-generated method stub
		List<PublicGuidance> listpublice = (List<PublicGuidance>) model.get("listpublice");

		// create a new Excel sheet
		HSSFSheet sheet = workbook.createSheet("Java Books");
		sheet.setDefaultColumnWidth(30);

		// create style for header cells

		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);

		// create header row
		HSSFRow header = sheet.createRow(0);

		header.createCell(0).setCellValue("District");
		header.getCell(0).setCellStyle(style);

		header.createCell(1).setCellValue("Month");
		header.getCell(1).setCellStyle(style);

		header.createCell(2).setCellValue("Present");
		header.getCell(2).setCellStyle(style);

		header.createCell(3).setCellValue("Leave");
		header.getCell(3).setCellStyle(style);

		header.createCell(4).setCellValue("Year");
		header.getCell(4).setCellStyle(style);

		// create data rows
		int rowCount = 1;

		for (PublicGuidance att : listpublice) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue(att.getDistrictMaster().getDistrictName());
			aRow.createCell(1).setCellValue(att.getMonth() + "");
			aRow.createCell(2).setCellValue(att.getPgId() + "");
			aRow.createCell(3).setCellValue(att.getPgParticipants() + "");
			aRow.createCell(4).setCellValue(att.getYear());
		}

	}

}
