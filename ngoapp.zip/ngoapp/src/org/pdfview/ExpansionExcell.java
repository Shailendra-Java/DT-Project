package org.pdfview;

import java.util.List;
import java.util.Map;
 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.Expansion;
import org.dto.PEreport;
import org.springframework.web.servlet.view.document.AbstractExcelView;
public class ExpansionExcell extends  AbstractExcelView{
	
	@Override
    protected void buildExcelDocument(Map<String, Object> model,
            HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        // get data model which is passed by the Spring container
        List<Expansion> listattendance3 = (List<Expansion>) model.get("listattendance3");
         
        // create a new Excel sheet
        HSSFSheet sheet = workbook.createSheet("Java Books");
        sheet.setDefaultColumnWidth(30);
         
        // create style for header cells
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontName("Arial");
        style.setFillForegroundColor(HSSFColor.BLUE.index);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        style.setFont(font);
         
        // create header row
        HSSFRow header = sheet.createRow(0);
         
        header.createCell(0).setCellValue("District");
        header.getCell(0).setCellStyle(style);
         
        header.createCell(1).setCellValue("Month");
        header.getCell(1).setCellStyle(style);
         
        header.createCell(2).setCellValue("a");
        header.getCell(2).setCellStyle(style);
         
        header.createCell(3).setCellValue("Aok");
        header.getCell(3).setCellStyle(style);
        
        header.createCell(4).setCellValue("b");
        header.getCell(4).setCellStyle(style);
        
        header.createCell(5).setCellValue("fc");
        header.getCell(5).setCellStyle(style);
        
        header.createCell(6).setCellValue("NewMember");
        header.getCell(6).setCellStyle(style);
        
        header.createCell(7).setCellValue("admissionAmount");
        header.getCell(7).setCellStyle(style);
        
        header.createCell(8).setCellValue("subAmount");
        header.getCell(8).setCellStyle(style);
        
        header.createCell(9).setCellValue("Summary");
        header.getCell(9).setCellStyle(style);
         
        header.createCell(10).setCellValue("Year");
        header.getCell(10).setCellStyle(style);
         
        // create data rows
        int rowCount = 1;
         
        for (Expansion att : listattendance3) {
            HSSFRow aRow = sheet.createRow(rowCount++);
            aRow.createCell(0).setCellValue(att.getDistrictMaster().getDistrictName());
            aRow.createCell(1).setCellValue(att.getMonth()+"");
            aRow.createCell(2).setCellValue(att.getA()+"");
            aRow.createCell(3).setCellValue(att.getaOk()+"");
            aRow.createCell(4).setCellValue(att.getB()+"");
            aRow.createCell(5).setCellValue(att.getFc()+"");
            aRow.createCell(6).setCellValue(att.getNewMember()+"");
            aRow.createCell(7).setCellValue(att.getAdmissionAmount()+"");
            aRow.createCell(8).setCellValue(att.getSubAmount()+"");
            aRow.createCell(9).setCellValue(att.getSummary()+"");
            aRow.createCell(10).setCellValue(att.getYear());
        }
    }

}
