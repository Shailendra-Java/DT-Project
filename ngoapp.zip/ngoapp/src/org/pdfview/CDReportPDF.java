package org.pdfview;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dto.AttendanceMaster;
import org.dto.CdReport;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class CDReportPDF extends AbstractITextPdfView {

	 @Override
	    protected void buildPdfDocument(Map<String, Object> model, Document doc,
	            PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
	            throws Exception {
	        // get data model which is passed by the Spring container
	        List<CdReport> listattendance1 = (List<CdReport>) model.get("listattendance1");
	         
	        //doc.add(new Paragraph("Recommended books for Spring framework"));
	         
	        PdfPTable table = new PdfPTable(12);
	        table.setWidthPercentage(100.0f);
	        table.setWidths(new float[] {3.5f, 3.0f, 3.0f, 3.0f, 3.0f,3.0f,3.0f,3.0f,3.0f,3.0f,3.0f,3.0f});
	        table.setSpacingBefore(10);
	         
	        // define font for table header row
	        Font font = FontFactory.getFont(FontFactory.HELVETICA);
	        font.setColor(BaseColor.WHITE);
	         
	        // define table header cell
	        PdfPCell cell = new PdfPCell();
	        cell.setBackgroundColor(BaseColor.BLUE);
	        cell.setPadding(5);
	         
	        // write table header
	        cell.setPhrase(new Phrase("DN", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Month", font));
	        table.addCell(cell);
	 
	        cell.setPhrase(new Phrase("ProgramName", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("ProgramType", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Advertisement", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("ChiefGuests", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Media", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Men", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Woman", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("TotalExpense", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Summary", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Year", font));
	        table.addCell(cell);
	         
	        // write table row data
	        for (CdReport att : listattendance1) {
	            table.addCell(att.getDistrictMaster().getDistrictName().substring(0,1).toUpperCase()+att.getDistrictMaster().getDistrictName().substring(1).toLowerCase());
	            table.addCell(att.getMonth()+"");
	            table.addCell(att.getProgramName()+"");
	            table.addCell(att.getProgramType()+"");
	            table.addCell(att.getAdvertisement()+"");
	            table.addCell(att.getChiefGuests()+"");
	            table.addCell(att.getMedia()+"");
	            table.addCell(att.getMen()+"");
	            table.addCell(att.getWoman()+"");
	            table.addCell(att.getTotalExpense()+"");
	            table.addCell(att.getSummary()+"");
	            table.addCell(String.valueOf(att.getYear()));
	        }
	         
	        doc.add(table);
	         
	    }
	
}
