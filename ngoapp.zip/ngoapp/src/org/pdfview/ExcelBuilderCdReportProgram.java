package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;

import org.dto.CdReportProgram;
import org.springframework.web.servlet.view.document.AbstractExcelView;

public class ExcelBuilderCdReportProgram extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		List<CdReportProgram> cdreportprogramlist1 = (List<CdReportProgram>) model.get("cdreportprogramlist1");

		HSSFSheet sheet = workbook.createSheet("Esquare");
		sheet.setDefaultColumnWidth(30);

		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);

		HSSFRow header = sheet.createRow(0);

		header.createCell(0).setCellValue("District");
		header.getCell(0).setCellStyle(style);

		header.createCell(1).setCellValue("Month");
		header.getCell(1).setCellStyle(style);

		header.createCell(2).setCellValue("Amount");
		header.getCell(2).setCellStyle(style);

		header.createCell(3).setCellValue("Beneficiaries");
		header.getCell(3).setCellStyle(style);

		header.createCell(4).setCellValue("BloodDonation");
		header.getCell(4).setCellStyle(style);

		header.createCell(5).setCellValue("NoOfAwarenessCirculars");
		header.getCell(5).setCellStyle(style);

		header.createCell(6).setCellValue("Participants");
		header.getCell(6).setCellStyle(style);

		header.createCell(7).setCellValue("ProgramExpense");
		header.getCell(7).setCellStyle(style);

		header.createCell(8).setCellValue("Summary");
		header.getCell(8).setCellStyle(style);

		header.createCell(9).setCellValue("TypeOfHelp");
		header.getCell(9).setCellStyle(style);

		header.createCell(10).setCellValue("TypeOfProgram");
		header.getCell(10).setCellStyle(style);

		header.createCell(11).setCellValue("Year");
		header.getCell(11).setCellStyle(style);

		int rowCount = 1;

		for (CdReportProgram cdreplist : cdreportprogramlist1) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue(cdreplist.getDistrictMaster().getDistrictName());
			aRow.createCell(1).setCellValue(cdreplist.getMonth() + "");
			aRow.createCell(2).setCellValue(cdreplist.getAmount() + "");
			aRow.createCell(3).setCellValue(cdreplist.getBeneficiaries() + "");
			aRow.createCell(4).setCellValue(cdreplist.getBloodDonation() + "");
			aRow.createCell(5).setCellValue(cdreplist.getNoOfAwarenessCirculars() + "");
			aRow.createCell(6).setCellValue(cdreplist.getParticipants() + "");
			aRow.createCell(7).setCellValue(cdreplist.getProgramExpense() + "");
			aRow.createCell(8).setCellValue(cdreplist.getSummary() + "");
			aRow.createCell(9).setCellValue(cdreplist.getTypeOfHelp() + "");
			aRow.createCell(10).setCellValue(cdreplist.getTypeOfProgram() + "");
			aRow.createCell(11).setCellValue(cdreplist.getYear());
		}

	}
}