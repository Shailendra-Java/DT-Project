package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dto.CdReportProgram;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfBuilderCdReportProgram extends AbstractITextPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		List<CdReportProgram> cdreportprogramlist = (List<CdReportProgram>) model.get("cdreportprogram");

		PdfPTable table = new PdfPTable(12);
		table.setWidthPercentage(100.0f);
		table.setWidths(new float[] { 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f });
		table.setSpacingBefore(10);

		Font font = FontFactory.getFont(FontFactory.HELVETICA);
		font.setColor(BaseColor.WHITE);

		PdfPCell cell = new PdfPCell();
		cell.setBackgroundColor(BaseColor.BLUE);
		cell.setPadding(5);

		cell.setPhrase(new Phrase("DN", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Month", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Amount", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Beneficiaries", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("BloodDonation", font));
		table.addCell(cell);

		/*
		 * cell.setPhrase(new Phrase("CreatedDate", font)); table.addCell(cell);
		 */

		cell.setPhrase(new Phrase("NoOfAwarenessCirculars", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Participants", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("ProgramExpense", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Summary", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TypeOfHelp", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TypeOfProgram", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Year", font));
		table.addCell(cell);

		// write table row data
		for (CdReportProgram cdreportpgm : cdreportprogramlist) {
			table.addCell(cdreportpgm.getDistrictMaster().getDistrictName());
			table.addCell(cdreportpgm.getMonth() + "");
			table.addCell(cdreportpgm.getAmount() + "");
			table.addCell(cdreportpgm.getBeneficiaries() + "");
			table.addCell(cdreportpgm.getBloodDonation() + "");
			// table.addCell(cdreportpgm.getCreatedDate()+"");
			table.addCell(cdreportpgm.getNoOfAwarenessCirculars() + "");
			table.addCell(cdreportpgm.getParticipants() + "");
			table.addCell(cdreportpgm.getProgramExpense() + "");
			table.addCell(cdreportpgm.getSummary() + "");
			table.addCell(cdreportpgm.getTypeOfHelp() + "");
			table.addCell(cdreportpgm.getTypeOfProgram() + "");
			table.addCell(String.valueOf(cdreportpgm.getYear()));

		}

		document.add(table);
	}

}
