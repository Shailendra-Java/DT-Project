package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dto.MonthlyReport;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class monthlyreportPdf extends AbstractITextPdfView {

	@SuppressWarnings("unchecked")
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document doc, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		List<MonthlyReport> monthlypdf = (List<MonthlyReport>) model.get("monthlypdf");

		// doc.add(new Paragraph("Recommended books for Spring framework"));

		PdfPTable table = new PdfPTable(11);
		table.setWidthPercentage(100.0f);
		table.setWidths(new float[] { 3.8f, 3.0f, 3.6f, 2.6f, 3.0f, 3.2f, 3.0f, 3.0f, 3.8f, 3.0f, 2.6f });
		table.setSpacingBefore(10);

		// define font for table header row
		Font font = FontFactory.getFont(FontFactory.defaultEncoding);
		font.setColor(BaseColor.WHITE);

		// define table header cell
		PdfPCell cell = new PdfPCell();
		cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		cell.setPadding(5);

		// write table header
		cell.setPhrase(new Phrase("Districts", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("LMTM", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Members", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TLIn", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TLOut", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Dismiss", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("CMTM", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TArea", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TDivision", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TUnits", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("date", font));
		table.addCell(cell);

		// write table row data
		for (MonthlyReport mr : monthlypdf) {
			table.addCell(mr.getDistrictMaster().getDistrictName());
			table.addCell(mr.getLastMonthTotalMembers() + "");
			table.addCell(mr.getNewMembers() + "");
			table.addCell(mr.getTLIn() + "");
			table.addCell(mr.getTLOut() + "");
			table.addCell(mr.getDismiss() + "");
			table.addCell(mr.getCurrentMonthTotalMembers() + "");
			table.addCell(mr.getTotalArea() + "");
			table.addCell(mr.getTotalDivision() + "");
			table.addCell(mr.getTotalUnits() + "");
			table.addCell(mr.getCreated_Date() + "");

		}

		doc.add(table);

	}

}
