package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.dto.SubscriptionMaster;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfBuilderSubscription extends AbstractITextPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		List<SubscriptionMaster> subscriptionlist = (List<SubscriptionMaster>) model.get("subscription");

		PdfPTable table = new PdfPTable(12);
		table.setWidthPercentage(100.0f);
		table.setWidths(new float[] { 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f });
		table.setSpacingBefore(10);

		Font font = FontFactory.getFont(FontFactory.HELVETICA);
		font.setColor(BaseColor.WHITE);

		PdfPCell cell = new PdfPCell();
		cell.setBackgroundColor(BaseColor.BLUE);
		cell.setPadding(5);

		cell.setPhrase(new Phrase("DN", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Month", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Amount", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Beneficiaries", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("BloodDonation", font));
		table.addCell(cell);

		/*
		 * cell.setPhrase(new Phrase("CreatedDate", font)); table.addCell(cell);
		 */

		cell.setPhrase(new Phrase("NoOfAwarenessCirculars", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Participants", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("ProgramExpense", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Summary", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TypeOfHelp", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("TypeOfProgram", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Year", font));
		table.addCell(cell);

		// write table row data
		for (SubscriptionMaster sublist : subscriptionlist) {
			table.addCell(sublist.getDistrictMaster().getDistrictName());
			table.addCell(sublist.getAddmissionGivenMember() + "");
			table.addCell(sublist.getBalance() + "");
			table.addCell(sublist.getBalanceAmount() + "");
			table.addCell(sublist.getCollected() + "");
			// table.addCell(cdreportpgm.getCreatedDate()+"");
			table.addCell(sublist.getMonth() + "");
			table.addCell(sublist.getOfferedAdmission() + "");
			table.addCell(sublist.getOfferedSubscription() + "");
			table.addCell(sublist.getSubGivenMember() + "");
			table.addCell(sublist.getSummary() + "");
			table.addCell(String.valueOf(sublist.getYear()));

		}

		document.add(table);
	}
}
