package org.pdfview;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.Expansion;
import org.dto.PEreport;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class ExpansionPDF extends AbstractITextPdfView {

	 @Override
	    protected void buildPdfDocument(Map<String, Object> model, Document doc,
	            PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
	            throws Exception {
	        // get data model which is passed by the Spring container
	        List<Expansion> listattendance3 = (List<Expansion>) model.get("listattendance3");
	         
	        //doc.add(new Paragraph("Recommended books for Spring framework"));
	         
	        PdfPTable table = new PdfPTable(11);
	        table.setWidthPercentage(100.0f);
	        table.setWidths(new float[] {3.0f, 2.0f, 2.0f, 2.0f, 1.0f,3.0f,3.0f,3.0f,3.0f,3.0f,3.0f});
	        table.setSpacingBefore(10);
	         
	        // define font for table header row
	        Font font = FontFactory.getFont(FontFactory.HELVETICA);
	        font.setColor(BaseColor.WHITE);
	         
	        // define table header cell
	        PdfPCell cell = new PdfPCell();
	        cell.setBackgroundColor(BaseColor.BLUE);
	        cell.setPadding(5);
	         
	        // write table header
	        cell.setPhrase(new Phrase("DN", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Month", font));
	        table.addCell(cell);
	 
	        cell.setPhrase(new Phrase("a", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Aok", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("b", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("fc", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("NewMember", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("admissionAmount", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("subAmount", font));
	        table.addCell(cell);
	        
	        cell.setPhrase(new Phrase("Summary", font));
	        table.addCell(cell);
	         
	        cell.setPhrase(new Phrase("Year", font));
	        table.addCell(cell);
	         
	        // write table row data
	        for (Expansion att : listattendance3) {
	        	table.addCell(att.getDistrictMaster().getDistrictName().substring(0,1).toUpperCase()+att.getDistrictMaster().getDistrictName().substring(1).toLowerCase());
	            table.addCell(att.getMonth()+"");
	            table.addCell(att.getA()+"");
	            table.addCell(att.getaOk()+"");
	            table.addCell(att.getB()+"");
	            table.addCell(att.getFc()+"");
	            table.addCell(att.getNewMember()+"");
	            table.addCell(att.getAdmissionAmount()+"");
	            table.addCell(att.getSubAmount()+"");
	            table.addCell(att.getSummary()+"");
	            table.addCell(String.valueOf(att.getYear()));
	        }
	         
	        doc.add(table);
	         
	    }
	
}
