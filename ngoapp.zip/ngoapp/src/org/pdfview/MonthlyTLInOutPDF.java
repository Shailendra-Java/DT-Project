package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dto.MonthlyTLIN;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class MonthlyTLInOutPDF extends AbstractITextPdfView {
	
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document doc, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		List<MonthlyTLIN> monthlytlpdf = (List<MonthlyTLIN>) model.get("monthlytlpdf");
		
		     PdfPTable table = new PdfPTable(5);
		     table.setWidthPercentage(100.0f);
		     table.setWidths(new float[]{3.8f,2.6f,2.6f,3.0f,3.6f});
		     table.setSpacingBefore(10);
		     
		  // define font for table header row
		     
		     Font font = FontFactory.getFont(FontFactory.defaultEncoding);
			 font.setColor(BaseColor.WHITE);
				
		 // define table header cell
			 
			PdfPCell cell = new PdfPCell();
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			 cell.setPadding(5);
				  
	     // write table header
			 
			cell.setPhrase(new Phrase("DISTRICTS", font));
			table.addCell(cell);
			
			cell.setPhrase(new Phrase("TYPE OF TL", font));
			table.addCell(cell);
			
			cell.setPhrase(new Phrase("DATE", font));
			table.addCell(cell);
			
			cell.setPhrase(new Phrase("NAME", font));
			table.addCell(cell);
			
			cell.setPhrase(new Phrase("ADDRESS", font));
			table.addCell(cell);
			
			//write table row data
			
			for (MonthlyTLIN mt : monthlytlpdf) {
				table.addCell(mt.getDistrictMaster().getDistrictName());
				table.addCell(mt.getTypeofTL());
				table.addCell(mt.getDateofJoining());
				table.addCell(mt.getName());
				table.addCell(mt.getAddress());
							
			}
			doc.add(table);
	}

}
