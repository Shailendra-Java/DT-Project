package org.pdfview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;

import org.dto.MonthlyReport;
import org.springframework.web.servlet.view.document.AbstractExcelView;

public class MonthlyreportExcell extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// get data model which is passed by the Spring container
		List<MonthlyReport> monthlyexcell = (List<MonthlyReport>) model.get("monthlyexcell");

		// create a new Excel sheet
		HSSFSheet sheet = workbook.createSheet("Esquare");
		sheet.setDefaultColumnWidth(30);

		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);

		// create header row
		HSSFRow header = sheet.createRow(0);

		header.createCell(0).setCellValue("District");
		header.getCell(0).setCellStyle(style);

		header.createCell(1).setCellValue("LMTM");
		header.getCell(1).setCellStyle(style);

		header.createCell(2).setCellValue("Members");
		header.getCell(2).setCellStyle(style);

		header.createCell(3).setCellValue("TLIn");
		header.getCell(3).setCellStyle(style);

		header.createCell(4).setCellValue("TLOut");
		header.getCell(4).setCellStyle(style);

		header.createCell(5).setCellValue("Dismiss");
		header.getCell(5).setCellStyle(style);

		header.createCell(6).setCellValue("CMTM");
		header.getCell(6).setCellStyle(style);

		header.createCell(7).setCellValue("TArea");
		header.getCell(7).setCellStyle(style);

		header.createCell(8).setCellValue("TDivision");
		header.getCell(8).setCellStyle(style);

		header.createCell(9).setCellValue("TUnits");
		header.getCell(9).setCellStyle(style);

		header.createCell(10).setCellValue("Date");
		header.getCell(10).setCellStyle(style);

		int rowCount = 1;

		// write table row data
		for (MonthlyReport mr : monthlyexcell) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue(mr.getDistrictMaster().getDistrictName());
			aRow.createCell(1).setCellValue(mr.getLastMonthTotalMembers() + "");
			aRow.createCell(2).setCellValue(mr.getNewMembers() + "");
			aRow.createCell(3).setCellValue(mr.getTLIn() + "");
			aRow.createCell(4).setCellValue(mr.getTLOut() + "");
			aRow.createCell(5).setCellValue(mr.getDismiss() + "");
			aRow.createCell(6).setCellValue(mr.getCurrentMonthTotalMembers() + "");
			aRow.createCell(7).setCellValue(mr.getTotalArea() + "");
			aRow.createCell(8).setCellValue(mr.getTotalDivision() + "");
			aRow.createCell(9).setCellValue(mr.getTotalUnits() + "");
			aRow.createCell(10).setCellValue(mr.getCreated_Date() + "");

		}

	}

}
