package org.util;

public class Attdtypes {
	
private static int Present_in_unit = 0;
	    
private static int Total_DEC_Members = 1;
	    
private static int Guidance_Present = 2;

        public Attdtypes() {
	        System.out.println("Car Parts object created!");
	    }

         public static Integer Present_in_unit() {
			return Present_in_unit;
         }
        
         public static Integer Total_DEC_Members() {
		     return Total_DEC_Members;
			
		}
         public static Integer Guidance_Present() {
             return Guidance_Present;
			
		}

		
	}


