package org.service;

import java.util.List;

import org.dto.UserMaster;

public interface IUserService {

	void saveUser(UserMaster user);

	List<UserMaster> getUserList();

	UserMaster getUserById(int id);

	void updateUser(UserMaster user);

}
