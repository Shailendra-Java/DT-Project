package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.dao.IDistrictDao;
import org.dto.DistrictAdmin;
import org.dto.DistrictMaster;
import org.dto.MonthlyReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DistrictService implements IDistrictService {

	@Autowired
	IDistrictDao idistrict;

	@Override
	public void saveDistrict(DistrictAdmin district) {
		district.setMonth((new Date()));
		idistrict.saveDistrict(district);

	}

	@Override
	public List<DistrictAdmin> getDistrictList() {

		List<DistrictAdmin> district = idistrict.getDistrictList();
		return district;
	}

	@Override
	public DistrictAdmin getDistrictById(int id) {
		try {
			DistrictAdmin district = idistrict.getDistrictById(id);

			return district;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public void updateMonthlyReport(MonthlyReport monthlyReport) {
		try {

			idistrict.updateMonthlyReport(monthlyReport);
		} catch (Exception e) {

		}

	}

	@Override
	public DistrictMaster getdistrict(int i) {

		DistrictMaster countryMaster = idistrict.getdistrict(i);
		return countryMaster;
	}

	@Override
	public List<DistrictMaster> getDistrictMasterList() {

		List<DistrictMaster> district = idistrict.getDistrictMasterList();
		return district;
	}

	@Override
	public void saveMonthlyReport(MonthlyReport monthlyReport) {
		System.out.println("----------");
		int month = monthlyReport.getMonth();
		System.out.println("month:" + month);
		idistrict.saveMonthlyReport(monthlyReport);
	}

	@Override
	public List<MonthlyReport> getMonthlyReportList() {

		List<MonthlyReport> district = idistrict.getMonthlyReportList();
		return district;
	}

	@Override
	public MonthlyReport getMonthlyReportById(long id) {
		try {
			MonthlyReport district = idistrict.getMonthlyReportById(id);
			return district;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public MonthlyReport getMonthlyReportByMonthYearDistrict(int month, int year, int districtId) {

		MonthlyReport district = idistrict.getMonthlyReportByMonthYearDistrict(year, month, districtId);
		return district;
	}

	@Override
	public boolean savedistrict(DistrictMaster district) {

		boolean savedistrict = idistrict.saveDistrict(district);

		return savedistrict;

	}

	@Override
	public boolean getDistrictname(String districtName) {

		boolean b = idistrict.getDistrictname(districtName);

		return b;

	}

	@Override
	public List<DistrictMaster> getdistrictList() {

		List<DistrictMaster> districts = idistrict.getdistrictList();
		return districts;
	}

	@Override
	public DistrictMaster getdistrictReportById(int id) {

		DistrictMaster district = idistrict.getDistrictnameById(id);

		return district;

	}

	@Override
	public List<MonthlyReport> getMRAllreport() {
		List<MonthlyReport> list = idistrict.getMRAllreport();
		return list;
	}

	@Override
	public MonthlyReport getReportById(long id) {
		MonthlyReport list = idistrict.getmonthlyreportAll(id);
		return list;
	}

	@Override
	public MonthlyReport getMonthlyreportAll(int year, int districtId, int month) {
		MonthlyReport district = idistrict.getMonthlyReportAll(year, districtId, month);
		return district;
	}

	@Override
	public void updateDistrict(DistrictAdmin district) {
		try {

			/*
			 * district.setDistrictName((CamelCase.toCamelCase(district.getDistrictMaster().
			 * getDistrictName()))) ;
			 */

			idistrict.updateDistrict(district);
		} catch (Exception e) {

		}

	}

	@Override
	public void deleteReport(long id) {
		idistrict.deleteReport(id);

	}

	@Override
	public List<MonthlyReport> viewMonthlyReport() {
		System.out.println("hello services");
		List<MonthlyReport> viewList = idistrict.viewMonthlyReport();
		return viewList;
	}

	/*
	 * @Override public List<List<Map<Object, Object>>> getCanvasjsChartData() {
	 * System.out.println("hello chart"); return idistrict.getCanvasjsChartData(); }
	 */

	@Override
	public MonthlyReport getMonthchartReport() {
		// TODO Auto-generated method stub
		return idistrict.getMonthchartReport();
	}

	@Override
	public List<MonthlyReport> getdistrictName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MonthlyReport getMonthlyReportByMonthYearDistrict(String date1, int did) {
		MonthlyReport district = idistrict.getMonthlyReportBydateDistrict(date1, did);
		return district;
	}

	@Override
	public MonthlyReport getMonthlyReportBydateDistrict(String cdate, int did) {
		MonthlyReport district = idistrict.getMonthlyReportBydateDistrict(cdate, did);
		return district;
	}

	@Override
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<MonthlyReport> mreport = idistrict.getMRAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != mreport) {
			for (MonthlyReport report : mreport) {
				if (report.getMonth() == month && report.getYear() == year
						&& districtId == report.getDistrictMaster().getDistrictId()) {
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	@Override
	public boolean isReportExistForSelectedMonthAndYearEdit(Date created_Date, Integer districtId,
			MonthlyReport editPereport) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<MonthlyReport> report = idistrict.getMRAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(created_Date);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != report) {
			for (MonthlyReport reposrt : report) {
				if (reposrt.getMonth() == month && reposrt.getYear() == year
						&& districtId == reposrt.getDistrictMaster().getDistrictId()) {
					if (isUpdatingSelectedReportwithSameDateAndMonth(editPereport, reposrt)) {
						continue;
					}
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	private boolean isUpdatingSelectedReportwithSameDateAndMonth(MonthlyReport editReport, MonthlyReport report) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if (editReport.getYear().intValue() == report.getYear().intValue() && editReport.getMonth() == report.getMonth()
				&& editReport.getDistrictMaster().getDistrictId() == report.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}

	@Override
	public MonthlyReport getReportByDistrictId(int id) {
		MonthlyReport district = idistrict.getMonthlyReportBydateDistrict(id);
		return district;
	}

	@Override
	public MonthlyReport getMonthlyReportByMonthYearDistrict(int year, int month) {
		MonthlyReport district = idistrict.getMonthlyReportByMonthYearDistrict(year,month);
		return district;
	}

	@Override
	public List<DistrictMaster> getDistrictMasterList(String districtId) {
		List<DistrictMaster> district = idistrict.getDistrictMasterList(districtId);
		return district;
	}

	@Override
	public List<MonthlyReport> getByDistrictId(int id) {
		List<MonthlyReport>  district = idistrict.getByDistrictId(id);
		return district;
	}

}