package org.service;

import java.util.Date;
import java.util.List;

import org.dto.CdReport;
import org.dto.PEreport;

public interface PEreportService {
	void saveReport(PEreport pereport);
	List<PEreport> getPEAllreport();
	void updatePEreport(PEreport pereport);
	PEreport getReportById(Integer peId);
	public void deletePEReport(Integer peId);
	boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer districtId);
	boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer districtId,PEreport editPereport);
	public PEreport getReportByMonthYearDistrict(int m, int y, int did);
	PEreport getMonthlyreportAll(int year, int did, int m);
}
