package org.service;

import java.util.Date;
import java.util.List;

import org.dto.SubscriptionMaster;

public interface ISubscriptionService {

	void savesubscription(SubscriptionMaster subscribe);

	List<SubscriptionMaster> getSubscriptionList();

	boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId);

	SubscriptionMaster getSubscriptionById(long subId);

	void updateSubscription(SubscriptionMaster updateSubscription);

	boolean isReportExistForSelectedMonthAndYearEdit(Date sectedDate, Integer disID,
			SubscriptionMaster editSubscription);

	void deleteSubscription(long subscriptionId);

	List<SubscriptionMaster> getAllSubscription();

	SubscriptionMaster getMonthlyReportByMonthYearDistrict(int year, int month, int did);

}