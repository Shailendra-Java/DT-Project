package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.dao.IPublicGuidanceDao;
import org.dto.PublicGuidance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PublicGuidanceService implements IPublicGuidanceService {
	private static final Logger logger = LoggerFactory.getLogger(PublicGuidanceService.class);

	@Autowired
	IPublicGuidanceDao ipublicguidance;

	@Override
	public void savePublicguidance(PublicGuidance publicguidance) {
		Integer value = publicguidance.getDate();

		ipublicguidance.savePublicguidance(publicguidance);

	}

	@Override
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		// Instead of getting all record , get record exist for selected month
		List<PublicGuidance> PublicGuidance = ipublicguidance.getPublicguidanceAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		if (null != PublicGuidance) {
			for (PublicGuidance reposrt : PublicGuidance) {
				if (reposrt.getMonth() == month && reposrt.getYear() == year
						&& districtId == reposrt.getDistrictMaster().getDistrictId()) {
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	public boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate, Integer districtId,
			PublicGuidance editPereport) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<PublicGuidance> pereport = ipublicguidance.getPublicguidanceAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != pereport) {
			for (PublicGuidance reposrt : pereport) {
				if (reposrt.getMonth() == month && reposrt.getYear() == year
						&& districtId == reposrt.getDistrictMaster().getDistrictId()) {
					if (isUpdatingSelectedReportwithSameDateAndMonth(editPereport, reposrt)) {
						continue;
					}
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	private boolean isUpdatingSelectedReportwithSameDateAndMonth(PublicGuidance editReport, PublicGuidance report) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if (editReport.getYear().intValue() == report.getYear().intValue() && editReport.getMonth() == report.getMonth()
				&& editReport.getDistrictMaster().getDistrictId() == report.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}

	@Override
	public List<PublicGuidance> getPGAllreport() {

		List<PublicGuidance> publicguidance = ipublicguidance.getPublicGuidanceList();

		return publicguidance;

	}

	@Override
	public PublicGuidance geteditReportById(int pgId) {

		PublicGuidance publicguidance = ipublicguidance.geteditReportById(pgId);

		return publicguidance;

	}

	@Override
	public void updatepublicguidancereport(PublicGuidance updatepublicguidancereport) {

		PublicGuidance publicguidance = ipublicguidance.updatepublicguidancereport(updatepublicguidancereport);

	}

	@Override
	@Transactional
	public void deletePGReport(Integer pgId) {
		ipublicguidance.deletePGReport(pgId);
	}

	@Override
	public PublicGuidance getId(Integer pgId) {
		PublicGuidance editCDreport = ipublicguidance.getId(pgId);
		return editCDreport;
	}

	@Override
	public PublicGuidance getReportByMonthYearDistrict(int y, int m, int did) {
		PublicGuidance pg1 = ipublicguidance.getReportByMonthYearDistrict(y, m, did);
		return pg1;
	}

	@Override
	public PublicGuidance getReportByMonthYearDistrictpgid(int y, int m, int did) {
		PublicGuidance pg2 = ipublicguidance.getReportByMonthYearDistrictpgid(y, m, did);
		return pg2;
	}

}
