package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.dao.IAttendanceDao;
import org.dto.AttendanceMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AttendanceService implements IAttendanceService {

	@Autowired
	IAttendanceDao iattendance;

	@Override
	public void saveattendance(AttendanceMaster attendance) {

		Integer value = attendance.getDate();
		iattendance.saveattendance(attendance);

	}

	@Override
	public List<AttendanceMaster> getAttendanceList() {

		List<AttendanceMaster> attendance = iattendance.getattendanceAllreport();

		return attendance;

	}

	@Override
	public AttendanceMaster getattendanceByMonthYearDistrict(int year) {

		AttendanceMaster attendance = iattendance.getattendanceByMonthYearDistrict(year);

		return attendance;
	}

	@Override
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer DistrictID) {
		boolean isReportExistForSelectedMonthAndYear = false;
		// Instead of getting all record , get record exist for selected month
		List<AttendanceMaster> attendancereport = iattendance.getattendanceAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		System.out.println(attendancereport + "getreport");

		if (null != attendancereport) {
			for (AttendanceMaster reposrt : attendancereport) {

				if (reposrt.getMonth() == month && reposrt.getYear() == year
						&& DistrictID == reposrt.getDistrictMaster().getDistrictId()) {

					isReportExistForSelectedMonthAndYear = true;

					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	@Override
	public AttendanceMaster geteditReportById(Long id) {

		AttendanceMaster attendancemaster = iattendance.geteditReportById(id);

		return attendancemaster;

	}

	@Override
	public void updateattendancereport(AttendanceMaster attendance) {

		try {

			iattendance.updatePEreport(attendance);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public AttendanceMaster getReportById(int id) {
		AttendanceMaster editAttendanceMaster = iattendance.getReportById(id);
		return editAttendanceMaster;
	}

	@Override
	public void deleteAttendanceReport(Integer attendanceId) {
		iattendance.deleteAttendanceReport(attendanceId);

	}

	@Override
	public AttendanceMaster getReportByMonthYearDistrict(int m, int y, int did) {
		AttendanceMaster attendance = iattendance.getReportByMonthYearDistrict(m, y, did);
		return attendance;
	}

	@Override
	public AttendanceMaster getAttendancereportAll(int y, int did, int m) {
		AttendanceMaster district = iattendance.getAttendancereportAll(y, did, m);
		return district;
	}

}