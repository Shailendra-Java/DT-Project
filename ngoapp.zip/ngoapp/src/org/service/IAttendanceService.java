package org.service;

import java.util.Date;
import java.util.List;
import org.dto.AttendanceMaster;
import org.dto.PEreport;
import org.springframework.stereotype.Service;

public interface IAttendanceService {

	public void saveattendance(AttendanceMaster attendance);

	public List<AttendanceMaster> getAttendanceList();

	public boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer DistrictID);

	AttendanceMaster getattendanceByMonthYearDistrict(int year);


	public void updateattendancereport(AttendanceMaster attendance);

	public AttendanceMaster geteditReportById(Long id);
	public AttendanceMaster getReportById(int id);

	public void deleteAttendanceReport(Integer attendanceId);

	public AttendanceMaster getReportByMonthYearDistrict(int m, int y, int did);

	public AttendanceMaster getAttendancereportAll(int y, int did, int m);

	
	

	//public AttendanceMaster getValue(float percentage);

}