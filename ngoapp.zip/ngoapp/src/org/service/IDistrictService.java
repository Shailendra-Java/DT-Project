package org.service;

import java.util.Date;
import java.util.List;
import org.dto.DistrictAdmin;
import org.dto.DistrictMaster;
import org.dto.MonthlyReport;

public interface IDistrictService {

	void saveDistrict(DistrictAdmin district);

	void saveMonthlyReport(MonthlyReport monthlyReport);

	List<MonthlyReport> getMonthlyReportList();

	List<DistrictAdmin> getDistrictList();

	DistrictAdmin getDistrictById(int id);

	void updateMonthlyReport(MonthlyReport monthlyReport);

	DistrictMaster getdistrict(int i);

	List<DistrictMaster> getDistrictMasterList();

	MonthlyReport getMonthlyReportById(long mrid);

	MonthlyReport getMonthlyReportByMonthYearDistrict(int m, int y, int did);

	boolean savedistrict(DistrictMaster district);

	boolean getDistrictname(String districtName);

	List<DistrictMaster> getdistrictList();

	DistrictMaster getdistrictReportById(int id);

	void updateDistrict(DistrictAdmin district);

	List<MonthlyReport> getMRAllreport();

	MonthlyReport getReportById(long id);

	MonthlyReport getMonthlyreportAll(int year, int did, int m);

	public void deleteReport(long id);

	List<MonthlyReport> viewMonthlyReport();

	// List<List<Map<Object, Object>>> getCanvasjsChartData();

	MonthlyReport getMonthchartReport();

	// List<KeyValue> getPieChartData();

	List<MonthlyReport> getdistrictName();

	MonthlyReport getMonthlyReportByMonthYearDistrict(String date1, int did);

	MonthlyReport getMonthlyReportBydateDistrict(String cdate, int did);

	boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId);

	boolean isReportExistForSelectedMonthAndYearEdit(Date sectedDate, Integer disID, MonthlyReport editPereport);

	MonthlyReport getReportByDistrictId(int id);

	MonthlyReport getMonthlyReportByMonthYearDistrict(int year, int month);

	List<DistrictMaster> getDistrictMasterList(String districtId);

	List<MonthlyReport> getByDistrictId(int id);

}