package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.dao.CdReportProgramDAO;
import org.dto.CdReportProgram;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CdReportProgramServiceImpl implements CdReportProgramService {
	private static final Logger logger = LoggerFactory.getLogger(CdReportProgramServiceImpl.class);

	@Autowired
	private CdReportProgramDAO reportDAO;

	/*
	 * @Override public void saveCdReportProgram(CdReportProgram report) {
	 * 
	 * Integer value = report.getDate(); reportDAO.saveReport(report); }
	 */

	@Override
	public void saveReport(CdReportProgram report) {
		Integer value = report.getDate();

		reportDAO.saveReport(report);

	}

	@Override
	public List<CdReportProgram> getAllCDreportprogram() {
		System.out.println("hello services");
		List<CdReportProgram> cdreportprogram = reportDAO.getAllCdReportProgram();
		return cdreportprogram;

	}

	@Override
	public CdReportProgram getReportById(int id) {
		System.out.println("hello services");
		CdReportProgram editCDreportprogram = reportDAO.getReportById(id);

		return editCDreportprogram;
	}

	@Override
	public void updateCDreportprogram(CdReportProgram cdreportprogram) {
		this.reportDAO.updateCDreportprogram(cdreportprogram);
	}

	@Override
	public void deleteCDreportprogram(Integer cdId) {
		reportDAO.deleteCDreportprogram(cdId);

	}

	@Override
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<CdReportProgram> cdreportprogram = reportDAO.getAllCdReportProgram();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != cdreportprogram) {
			for (CdReportProgram report : cdreportprogram) {
				if (report.getMonth() == month && report.getYear() == year
						&& districtId == report.getDistrictMaster().getDistrictId()) {
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	@Override
	public boolean isReportExistForSelectedMonthAndYearEdit(Date sectedDate, Integer disID,
			CdReportProgram editCdreportprogram) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<CdReportProgram> cdreportprogram = reportDAO.getAllCdReportProgram();
		Calendar cal = Calendar.getInstance();
		cal.setTime(sectedDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != cdreportprogram) {
			for (CdReportProgram report : cdreportprogram) {
				if (report.getMonth() == month && report.getYear() == year
						&& disID == report.getDistrictMaster().getDistrictId()) {
					if (isUpdatingSelectedReportwithSameDateAndMonth(editCdreportprogram, report)) {
						continue;
					}
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	private boolean isUpdatingSelectedReportwithSameDateAndMonth(CdReportProgram editReport, CdReportProgram report) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if (editReport.getYear().intValue() == report.getYear().intValue() && editReport.getMonth() == report.getMonth()
				&& editReport.getDistrictMaster().getDistrictId() == report.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}

	@Override
	public List<CdReportProgram> viewReport() {
		System.out.println("hello services");
		List<CdReportProgram> viewList = reportDAO.viewReport();
		return viewList;
	}

	@Override
	public CdReportProgram getMonthlyReportByMonthYearDistrict(String date1, int did) {
		CdReportProgram cdreportprogram = reportDAO.getMonthlyReportByMonthYearDistrict(date1, did);
		return cdreportprogram;
	}

	@Override
	public CdReportProgram getMonthlyReportByMonthYearDistrict(int date, int month, int year, String districtName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CdReportProgram getMonthlyReportByMonthYearDistrict(int year, int month, int did) {
		CdReportProgram cdreportprogram = reportDAO.getMonthlyReportByMonthYearDistrict(year, month, did);
		return cdreportprogram;

	}

}
