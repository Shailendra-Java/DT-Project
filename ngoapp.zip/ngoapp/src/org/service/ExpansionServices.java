package org.service;

import java.util.Date;
import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.Expansion;

public interface ExpansionServices {
	public void saveExpansion(Expansion expansion);
	public void update(Expansion expansion);
	public void delete(Integer expId);
	//public void update(Expansion expansion);
    boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer DistrictId);
	boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer DistrictId,Expansion  cdreport);
	Expansion getExpansionById(Integer expId);
	List<Expansion> getAllExpansion();
	public void deleteEXReport(Integer expId);
	public Expansion getReportByMonthYearDistrict(int m, int y, int did);
	Expansion getMonthlyreportAll(int year, int did, int m);
}