package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.dao.IMonthlyTLInOutDao;
import org.dto.MonthlyReport;
import org.dto.MonthlyTLIN;
import org.dto.PublicGuidance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MonthlyTLInOutService implements IMonthlyTLInOutService{

	@Autowired
	IMonthlyTLInOutDao monthlyTLInOutDao;

	@Override
	public void saveMonthlyTLIn(MonthlyTLIN monthlyTLIN) {
		System.out.println("----------");			
		monthlyTLInOutDao.saveMonthlyTLIN(monthlyTLIN);
	}

	@Override
	public List<MonthlyTLIN> getMonthlyTLINList(String typeofTL) {
		List<MonthlyTLIN> monthlyTLIN =monthlyTLInOutDao.getMonthlyTLINList(typeofTL);
		return monthlyTLIN;
	}

	@Override
	public MonthlyTLIN getByMtlId(long mtlId) {
		MonthlyTLIN monthlyTLIN = monthlyTLInOutDao.getByMtlId(mtlId);
		return monthlyTLIN;
	}

	@Override
	public void updateTLInOutDismiss(MonthlyTLIN monthlyTLIN) {
		monthlyTLInOutDao.updateTLInOutDismiss(monthlyTLIN);
	}
	
	@Override
	public void deleteTLInOut(long mtlId) {
		monthlyTLInOutDao.deleteTLInOut(mtlId);

	}

	@Override
	public List<MonthlyTLIN> getMonthlyTLINList() {
		System.out.println("Hello MonthlyTL Services");
		List<MonthlyTLIN> monthlyTLIN =monthlyTLInOutDao.getMonthlyTLINList();
		return monthlyTLIN;
	}


	@Override
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		Calendar cal = Calendar.getInstance();
		
		cal.setTime(createdDate);
		
		int month = cal.get(Calendar.MONTH) + 1;
/*		int day = cal.get(Calendar.DATE);
*/		int year = cal.get(Calendar.YEAR);

		List<MonthlyTLIN> monthlyTLIN = monthlyTLInOutDao.getMonthlyTLINList();

		if (null != monthlyTLIN) {
			for (MonthlyTLIN report : monthlyTLIN) {
				if (report.getMonth() == month && report.getYear() == year
						&& districtId == report.getDistrictMaster().getDistrictId()) {
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	@Override
	public MonthlyTLIN getReportByMonthYearDistrict(int year, int month, int did) {
		MonthlyTLIN tl1=monthlyTLInOutDao.getReportByMonthYearDistrict(year,month,did);
		return tl1;
	}
	
	@Override
	public MonthlyTLIN getMonthlyreportAll(int year, int districtId, int month) {
		MonthlyTLIN district = monthlyTLInOutDao.getMonthlyReportAll(year, districtId, month);
		return district;
	}
	
	@Override
	public List<MonthlyTLIN> getTLAllreport(){
		List<MonthlyTLIN> list=monthlyTLInOutDao.getTLAllreport();
		return list;
		
	}

	@Override
	public MonthlyTLIN getMonthchartTLIN() {
		// TODO Auto-generated method stub
		return monthlyTLInOutDao.getMonthchartTLIN();
	}
	
	
	
}
