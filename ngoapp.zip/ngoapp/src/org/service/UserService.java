package org.service;

import java.util.Date;
import java.util.List;
import org.dao.IUserDao;
import org.dto.UserMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.util.CamelCase;
import org.util.PasswordHasher;

@Service
public class UserService implements IUserService {

	@Autowired
	IUserDao iuser;

	@Override
	public void saveUser(UserMaster user) {

		user.setFirstName(CamelCase.toCamelCase(user.getFirstName()));
		user.setLastName(CamelCase.toCamelCase(user.getLastName()));
		String cryptedPassword = new PasswordHasher().encode(user.getPassword());
		user.setPassword(cryptedPassword);
		user.setCreatedDate(new Date());
		user.setStatus(user.getStatus());
		iuser.saveUser(user);

	}

	@Override
	public List<UserMaster> getUserList() {
		List<UserMaster> users = iuser.getUserList();
		return users;
	}

	@Override
	public UserMaster getUserById(int id) {

		try {
			UserMaster user = iuser.getUserById(id);
			return user;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public void updateUser(UserMaster user) {

		try {
			user.setFirstName(CamelCase.toCamelCase(user.getFirstName()));
			user.setLastName(CamelCase.toCamelCase(user.getLastName()));

			iuser.updateUser(user);
		} catch (Exception e) {

		}

	}

}
