package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.dao.ExpansionDAO;
import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.Expansion;
import org.dto.PEreport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional
public class ExpansionServicesImpl implements ExpansionServices{
	private static final Logger logger = LoggerFactory.getLogger(ExpansionServicesImpl.class);
	
	@Autowired
	ExpansionDAO expansionDao;
	
	
	@Override
	public void saveExpansion(Expansion expansion) {
		expansionDao.saveExpansion(expansion);
	}
	
	@Override
	public void update(Expansion expansion) {
		this.expansionDao.update(expansion);
	}

	@Override
	public void delete(Integer expId) {
		// TODO Auto-generated method stub
	}

	@Override
	public List<Expansion> getAllExpansion() {
		List<Expansion> expansion=expansionDao.getAllExpansion();
		return expansion;
	}

	@Override
	public Expansion getExpansionById(Integer expId) {
		Expansion getByExpansionId=expansionDao.getExpansionById(expId);
		return getByExpansionId;
	}
	
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<Expansion> pereport = expansionDao.getAllExpansion();
		Calendar cal = Calendar.getInstance();
		//cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(Expansion reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {					
					isReportExistForSelectedMonthAndYear = true;
					break;					
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	public boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer districtId,Expansion editPereport) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<Expansion> pereport = expansionDao.getAllExpansion();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(Expansion reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {	
					  if(isUpdatingSelectedReportwithSameDateAndMonth(editPereport, reposrt)) {
						continue;			
				      }
					  isReportExistForSelectedMonthAndYear = true;
					  break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	
	private boolean isUpdatingSelectedReportwithSameDateAndMonth(Expansion editReport,Expansion report) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if(editReport.getYear().intValue() == report.getYear().intValue() && editReport.getMonth() == report.getMonth()
				&& editReport.getDistrictMaster().getDistrictId() == report.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}

	@Override
	@Transactional
	public void deleteEXReport(Integer expId) {
		expansionDao.deleteEXReport(expId);
	}

	@Override
	public Expansion getReportByMonthYearDistrict(int m, int y, int did) {
		Expansion attendance=expansionDao.getReportByMonthYearDistrict(m,y,did);
		return attendance;
	}

	@Override
	public Expansion getMonthlyreportAll(int year, int districtId, int month) {
		Expansion district = expansionDao.getMonthlyReportAll(year, districtId, month);
		return district;
	}
	
}