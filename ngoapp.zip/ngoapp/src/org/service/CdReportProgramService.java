package org.service;

import java.util.Date;
import java.util.List;

import org.dto.CdReportProgram;

public interface CdReportProgramService {

	boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId);

	/* public void saveCdReportProgram(CdReportProgram report); */

	CdReportProgram getReportById(int id);

	boolean isReportExistForSelectedMonthAndYearEdit(Date sectedDate, Integer disID,
			CdReportProgram editCdreportprogram);

	public void updateCDreportprogram(CdReportProgram cdreportprogram);

	public void deleteCDreportprogram(Integer cdId);

	public List<CdReportProgram> getAllCDreportprogram();

	void saveReport(CdReportProgram report);

	public List<CdReportProgram> viewReport();

	CdReportProgram getMonthlyReportByMonthYearDistrict(String date1, int did);

	CdReportProgram getMonthlyReportByMonthYearDistrict(int date, int month, int year, String districtName);

	CdReportProgram getMonthlyReportByMonthYearDistrict(int year, int month, int did);
}
