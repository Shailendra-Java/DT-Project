package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.dao.CdReportDao;
import org.dao.ICdReportDao;
import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.MonthlyReport;
import org.dto.PEreport;
import org.dto.UserMaster;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.util.CamelCase;
import org.util.HibernateSessionFactory;


@Service
@Transactional
public class CdReportService implements ICdReportService {

@Autowired
ICdReportDao icdreportdao;

@Autowired
private HibernateSessionFactory factory;

	@Override
	public void saveCdReport(CdReport cdreport){
		Integer value = cdreport.getDate();
		icdreportdao.saveCdReport(cdreport);
		
	}
	@Override
	public List<CdReport> getCdReportList() {
		
		List<CdReport> cdreport=icdreportdao.getCdReportList();
		return cdreport;
		
	}

/*	@Override
	public void updateCdReport(CdReport report) {
		// TODO Auto-generated method stub
		 try
			{
			 report.setProgramName(CamelCase.toCamelCase(report.getProgramName()));
			 report.setProgramType(CamelCase.toCamelCase(report.getProgramType()));
			 report.setAdvertisement(CamelCase.toCamelCase(report.getAdvertisement()));
			 report.setChiefGuests(CamelCase.toCamelCase(report.getChiefGuests()));
			 report.setMedia(CamelCase.toCamelCase(report.getMedia()));
			 report.setSummary(CamelCase.toCamelCase(report.getSummary()));
			 report.setMen(report.getMen());
			 report.setWoman(report.getWoman());
			 report.setTotalExpense(report.getTotalExpense());;
			
			 icdreportdao.updateCdReport(report);
			}
			catch (Exception e)
			{
				
			}
	}	*/
	
	@Override
	public void updateCdReport(CdReport report) {
		this.icdreportdao.updateCdReport(report);
	}
	
	/*public boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer DistrictId) {
		
		boolean isReportExistForSelectedMonthAndYear = false;
		List<CdReport> cdreport = icdreportdao.getCDAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		//isReportExistForSelectedMonthAndYear = true;
		if(null != cdreport) {
			for(CdReport reposrt:cdreport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year) {
					isReportExistForSelectedMonthAndYear = true;
					break;					
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	
	public boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer districtId,CdReport editPereport) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<CdReport> pereport = icdreportdao.getCDAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(CdReport reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {	
					  if(isUpdatingSelectedReportwithSameDateAndMonth(editPereport, reposrt)) {
						continue;			
				      }
					  isReportExistForSelectedMonthAndYear = true;
					  break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}*/
	
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<CdReport> pereport = icdreportdao.getCDAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(CdReport reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {					
					isReportExistForSelectedMonthAndYear = true;
					break;					
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	public boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer districtId,CdReport editPereport) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<CdReport> pereport = icdreportdao.getCDAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(CdReport reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {	
					  if(isUpdatingSelectedReportwithSameDateAndMonth(editPereport, reposrt)) {
						continue;			
				      }
					  isReportExistForSelectedMonthAndYear = true;
					  break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	
	
	private boolean isUpdatingSelectedReportwithSameDateAndMonth(CdReport editReport,CdReport report) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if(editReport.getYear().intValue() == report.getYear().intValue() && editReport.getMonth() == report.getMonth()
				&& editReport.getDistrictMaster().getDistrictId() == report.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}
	
	/*@Override
	public CdReport getId(int id) {
		
		try{
			CdReport user=icdreportdao.getId(id);
			return user;
		}
		catch (Exception e) {
			return null;
		}
	}*/

	@Override
	public CdReport getId(int id) {
		CdReport editCDreport=icdreportdao.getId(id);
		return editCDreport;
	}
	
	@Override
	public List<CdReport> getCDAllreport() {
		List<CdReport> pereport=icdreportdao.getCDAllreport();
		return pereport;
	}

	@Override
	@Transactional
	public void deleteCDReport(Integer Id) {
		icdreportdao.deleteCDReport(Id);
	}


	@Override
	public CdReport getMonthlyReportByMonthYearDistrict(Date date) {

		CdReport district = icdreportdao.getMonthlyReportByMonthYearDistrict(date);
		return district;
	}
	
	@Override
	public CdReport getReportByMonthYearDistrict(int m, int y, int did) {
		CdReport attendance=icdreportdao.getReportByMonthYearDistrict(m,y,did);
		return attendance;
	}
	
	@Override
	public CdReport getMonthlyreportAll(int year, int districtId, int month) {
		CdReport district = icdreportdao.getMonthlyReportAll(year, districtId, month);
		return district;
	}
	
	}
