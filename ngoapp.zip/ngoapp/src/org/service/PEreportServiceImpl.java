package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.dao.PEreportDAO;
import org.dto.CdReport;
import org.dto.PEreport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PEreportServiceImpl implements PEreportService{
	private static final Logger logger = LoggerFactory.getLogger(PEreportServiceImpl.class);
	@Autowired
	private PEreportDAO reportDAO;
	
	@Autowired
	private PEreportService pereportService;
	
	@Override
	public void saveReport(PEreport pereport) {
		
		Integer value = pereport.getDate();
		reportDAO.saveReport(pereport);
	}
	
	@Override
	public List<PEreport> getPEAllreport() {
		List<PEreport> pereport=reportDAO.getPEAllreport();
		return pereport;
	}
	
	@Override
	public PEreport getReportById(Integer peId) {
		PEreport editPEreport=reportDAO.getReportById(peId);
		return editPEreport;
	}

	@Override
	public void updatePEreport(PEreport pereport) {
		this.reportDAO.updatePEreport(pereport);
	}

	@Override
	@Transactional
	public void deletePEReport(Integer peId) {
		reportDAO.deletePEReport(peId);
	}
	
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer districtId) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<PEreport> pereport = reportDAO.getPEAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(PEreport reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {					
					isReportExistForSelectedMonthAndYear = true;
					break;					
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	public boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer districtId,PEreport editPereport) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<PEreport> pereport = reportDAO.getPEAllreport();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		
		if(null != pereport) {
			for(PEreport reposrt:pereport) {
				if(reposrt.getMonth()== month && reposrt.getYear()== year && districtId == reposrt.getDistrictMaster().getDistrictId() ) {	
					  if(isUpdatingSelectedReportwithSameDateAndMonth(editPereport, reposrt)) {
						continue;			
				      }
					  isReportExistForSelectedMonthAndYear = true;
					  break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}
	private boolean isUpdatingSelectedReportwithSameDateAndMonth(PEreport editReport,PEreport report) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if(editReport.getYear().intValue() == report.getYear().intValue() && editReport.getMonth() == report.getMonth()
				&& editReport.getDistrictMaster().getDistrictId() == report.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}
	
	@Override
	public PEreport getReportByMonthYearDistrict(int m, int y, int did) {
		PEreport attendance=reportDAO.getReportByMonthYearDistrict(m,y,did);
		return attendance;
	}
	
	@Override
	public PEreport getMonthlyreportAll(int year, int districtId, int month) {
		PEreport district = reportDAO.getMonthlyReportAll(year, districtId, month);
		return district;
	}
	
}
