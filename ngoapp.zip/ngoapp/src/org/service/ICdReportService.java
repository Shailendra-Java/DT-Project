package org.service;

import java.util.Date;
import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.MonthlyReport;
import org.dto.UserMaster;

public interface ICdReportService {

public void saveCdReport(CdReport  cdreport);
	
	public List<CdReport> getCdReportList();
	
	void updateCdReport(CdReport report);
	
	boolean isReportExistForSelectedMonthAndYear(Date createdDate,Integer DistrictId);
	
	boolean isReportExistForSelectedMonthAndYearEdit(Date createdDate,Integer DistrictId,CdReport  cdreport);
	
	List<CdReport> getCDAllreport();
	
	CdReport getId(int id);
	
	public void deleteCDReport(Integer Id);
	
	CdReport getMonthlyReportByMonthYearDistrict(Date date);
	
	public CdReport getReportByMonthYearDistrict(int m, int y, int did);
	
	CdReport getMonthlyreportAll(int year, int did, int m);
}
