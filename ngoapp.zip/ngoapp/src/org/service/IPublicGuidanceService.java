package org.service;

import java.util.Date;
import java.util.List;

import org.dto.PublicGuidance;

public interface IPublicGuidanceService {

	public void savePublicguidance(PublicGuidance publicguid);

	// public List<PublicGuidance> getPublicGuidanceList();

	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId);

	public List<PublicGuidance> getPGAllreport();

	public PublicGuidance geteditReportById(int pgId);
	/* public PublicGuidance geteditReportById1(int pgId); */

	void updatepublicguidancereport(PublicGuidance updatepublicguidancereport);

	public void deletePGReport(Integer pgId);

	PublicGuidance getId(Integer pgId);

	PublicGuidance getReportByMonthYearDistrict(int m, int y, int did);

	PublicGuidance getReportByMonthYearDistrictpgid(int y, int m, int did);
}