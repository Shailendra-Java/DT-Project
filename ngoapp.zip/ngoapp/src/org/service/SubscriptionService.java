package org.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.dao.ISubscriptionDao;
import org.dto.SubscriptionMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionService implements ISubscriptionService {

	@Autowired
	ISubscriptionDao isubscription;

	@Override
	public void savesubscription(SubscriptionMaster subscribe) {
		isubscription.savesubscription(subscribe);
	}

	@Override
	public List<SubscriptionMaster> getSubscriptionList() {
		List<SubscriptionMaster> subsciption = isubscription.getSubscriptionList();
		return subsciption;
	}

	@Override
	public boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId) {

		boolean isReportExistForSelectedMonthAndYear = false;
		List<SubscriptionMaster> subscription = isubscription.getAllSubscription();
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != subscription) {
			for (SubscriptionMaster sub : subscription) {
				if (sub.getMonth() == month && sub.getYear() == year
						&& districtId == sub.getDistrictMaster().getDistrictId()) {
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	@Override
	public SubscriptionMaster getSubscriptionById(long id) {
		System.out.println("hello services");
		SubscriptionMaster editSubscription = isubscription.getSubscriptionById(id);
		return editSubscription;

	}

	@Override
	public boolean isReportExistForSelectedMonthAndYearEdit(Date sectedDate, Integer disID,
			SubscriptionMaster editSubscription) {
		boolean isReportExistForSelectedMonthAndYear = false;
		List<SubscriptionMaster> subscription = isubscription.getAllSubscription();

		Calendar cal = Calendar.getInstance();
		cal.setTime(sectedDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);

		if (null != subscription) {
			for (SubscriptionMaster sub : subscription) {
				if (sub.getMonth() == month && sub.getYear() == year
						&& disID == sub.getDistrictMaster().getDistrictId()) {
					if (isUpdatingSelectedReportwithSameDateAndMonth(editSubscription, sub)) {
						continue;
					}
					isReportExistForSelectedMonthAndYear = true;
					break;
				}
			}
		}
		return isReportExistForSelectedMonthAndYear;
	}

	private boolean isUpdatingSelectedReportwithSameDateAndMonth(SubscriptionMaster editSubscription,
			SubscriptionMaster sub) {
		boolean isUpdatingSelectedReportwithSameDateAndMonth = false;
		if (sub.getYear().intValue() == sub.getYear().intValue() && sub.getMonth() == sub.getMonth()
				&& sub.getDistrictMaster().getDistrictId() == sub.getDistrictMaster().getDistrictId()) {
			isUpdatingSelectedReportwithSameDateAndMonth = true;
		}
		return isUpdatingSelectedReportwithSameDateAndMonth;
	}

	@Override
	public void updateSubscription(SubscriptionMaster updateSubscription) {
		this.isubscription.updateSubscription(updateSubscription);
	}

	@Override
	public void deleteSubscription(long subscriptionId) {
		isubscription.deleteSubscription(subscriptionId);
	}

	@Override
	public List<SubscriptionMaster> getAllSubscription() {
		System.out.println("inside getallSubscription method");
		List<SubscriptionMaster> subscription = isubscription.getAllSubscription();
		return subscription;
	}

	@Override

	public SubscriptionMaster getMonthlyReportByMonthYearDistrict(int year, int month, int did) {
		SubscriptionMaster subscription = isubscription.getMonthlyReportByMonthYearDistrict(year, month, did);
		return subscription;

	}

}