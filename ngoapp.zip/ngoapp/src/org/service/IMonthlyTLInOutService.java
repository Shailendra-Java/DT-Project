package org.service;

import java.util.Date;
import java.util.List;

import org.dto.MonthlyTLIN;
import org.dto.PublicGuidance;

public interface IMonthlyTLInOutService {

	void saveMonthlyTLIn(MonthlyTLIN monthlyTLIN);

	List<MonthlyTLIN> getMonthlyTLINList(String typeofTL);
	
	List<MonthlyTLIN> getMonthlyTLINList();

	MonthlyTLIN getByMtlId(long mtlId);

	void updateTLInOutDismiss(MonthlyTLIN monthlyTLIN);
	
	public void deleteTLInOut(long mtlId);

	boolean isReportExistForSelectedMonthAndYear(Date createdDate, Integer districtId);

	public MonthlyTLIN getReportByMonthYearDistrict(int year, int month, int did);
	
	MonthlyTLIN getMonthlyreportAll(int year, int did, int m);
	
	public List<MonthlyTLIN> getTLAllreport();
	
	MonthlyTLIN getMonthchartTLIN();

	
}
