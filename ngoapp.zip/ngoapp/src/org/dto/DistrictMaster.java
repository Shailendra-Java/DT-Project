package org.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "district_master")
public class DistrictMaster {

	private String districtName;
	private int districtId;

	@Column(unique = true)
	@Pattern(regexp = "[A-Z\\s]*", message = "Invalid district name!")
	// @Pattern(regexp="#\\b[a-z]+#i", message="{invalid.districtName}")
	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
		this.districtName.toUpperCase();
	}

	@Id
	@GeneratedValue
	@Column(insertable = false)
	public int getDistrictId() {
		return districtId;
	}

	public void setDistrictId(int districtId) {
		this.districtId = districtId;
	}

	private DistrictAdmin districtadmin;

	@OneToOne
	@JoinColumn(name = "districtId")
	public DistrictAdmin getDistrictadmin() {
		return districtadmin;
	}

	public void setDistrictadmin(DistrictAdmin districtadmin) {
		this.districtadmin = districtadmin;
	}

}
