package org.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="user")
public class UserMaster implements Serializable{

private Integer userId,status=1;
private String firstName,lastName,screenName,emailAddress,gender,password;
private Date createdDate;


@Id
@GeneratedValue
@Column(name="user_id")
public Integer getUserId() {
	return userId;
}
public void setUserId(Integer userId) {
	this.userId = userId;
}


@Column(name="firstname")
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}

@Column(name="lastname")
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}

@Column(name="screenname")
public String getScreenName() {
	return screenName;
}
public void setScreenName(String screenName) {
	this.screenName = screenName;
}

@Column(name="emailId")
public String getEmailAddress() {
	return emailAddress;
}
public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
}


@Column(name="gender")
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

@Column(name="password")
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

@Column(name="status",length=1,nullable=false)
public Integer getStatus() {
	return status;
}
public void setStatus(Integer status) {
	this.status = status;
}

@Temporal(TemporalType.DATE)
@Column(name="createdDate", nullable=false, updatable=false)
public Date getCreatedDate() {
	return createdDate;
}

public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}


private DistrictMaster DistrictMaster;

@OneToOne(fetch = FetchType.EAGER)
@JoinColumn(name = "districtId", updatable = false)
public DistrictMaster getDistrictMaster() {
	return DistrictMaster;
}

public void setDistrictMaster(DistrictMaster districtMaster) {
	this.DistrictMaster = districtMaster;
}
	
}
