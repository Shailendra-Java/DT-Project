package org.dto;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;

@SuppressWarnings("serial")
@Entity
@Table(name="pereport")
public class PEreport implements Serializable {
	
	private Integer peId;	
	/*private Integer  distId;*/
	 @Column(name="Date", unique=true, nullable=false)
	 
	private Integer Date;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name="createdDate", unique=true, nullable=false)
	private java.util.Date createdDate; 
	private Integer month;
	private Integer year;
	private Integer totalBasicCompleted;
	private Integer toPlay;
	private Integer attendance;
	private Integer permission;	
	private Integer absentees;	
	/*private Integer Field;*/
	private Integer percentage;
	private String summary;
	
	
	@Id
	@GeneratedValue
	@Column(name="peId")
	public Integer getPeId() {
		return peId;
	}
	public void setPeId(Integer peId) {
		this.peId = peId;
	}
	/*@Column(name="distId")
	public Integer getDistId() {
		return distId;
	}
	public void setDistId(Integer distId) {
		this.distId = distId;
	}*/
	@Column(name="date")
	public Integer getDate() {
		return Date;
	}
	public void setDate(Integer date) {
		Date = date;
	}
	@Column(name="month")
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	@Column(name="year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	@Column(name="totalBasicCompleted")
	public Integer getTotalBasicCompleted() {
		return totalBasicCompleted;
	}
	public void setTotalBasicCompleted(Integer totalBasicCompleted) {
		this.totalBasicCompleted = totalBasicCompleted;
	}
	@Column(name="toPlay")
	public Integer getToPlay() {
		return toPlay;
	}
	public void setToPlay(Integer toPlay) {
		this.toPlay = toPlay;
	}
	@Column(name="Attendance")
	public Integer getAttendance() {
		return attendance;
	}
	public void setAttendance(Integer attendance) {
		this.attendance = attendance;
	}
	@Column(name="permission")
	public Integer getPermission() {
		return permission;
	}
	public void setPermission(Integer permission) {
		this.permission = permission;
	}
	@Column(name="adsentees")
	public Integer getAbsentees() {
		return absentees;
	}
	public void setAbsentees(Integer absentees) {
		this.absentees = absentees;
	}
/*	@Column(name="feildId")
	public Integer getField() {
		return Field;
	}
	public void setField(Integer field) {
		Field = field;
	}*/
	@Column(name="percentage")
	public Integer getPercentage() {
		return percentage;
	}
	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}
	@Column(name="summery", columnDefinition = "text")
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	private DistrictMaster districtMaster;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	public DistrictMaster getDistrictMaster() {
		return districtMaster;
	}
	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.districtMaster = districtMaster;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Date == null) ? 0 : Date.hashCode());
		result = prime * result + ((districtMaster == null) ? 0 : districtMaster.hashCode());
		//result = prime * result + ((Field == null) ? 0 : Field.hashCode());
		result = prime * result + ((absentees == null) ? 0 : absentees.hashCode());
		result = prime * result + ((attendance == null) ? 0 : attendance.hashCode());
		//result = prime * result + ((distId == null) ? 0 : distId.hashCode());
		result = prime * result + ((month == null) ? 0 : month.hashCode());
		result = prime * result + ((peId == null) ? 0 : peId.hashCode());
		result = prime * result + ((percentage == null) ? 0 : percentage.hashCode());
		result = prime * result + ((permission == null) ? 0 : permission.hashCode());
		result = prime * result + ((summary == null) ? 0 : summary.hashCode());
		result = prime * result + ((toPlay == null) ? 0 : toPlay.hashCode());
		result = prime * result + ((totalBasicCompleted == null) ? 0 : totalBasicCompleted.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}
	public java.util.Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(java.util.Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PEreport other = (PEreport) obj;
		if (Date == null) {
			if (other.Date != null)
				return false;
		} else if (!Date.equals(other.Date))
			return false;
		if (districtMaster == null) {
			if (other.districtMaster != null)
				return false;
		} else if (!districtMaster.equals(other.districtMaster))
			return false;
		/*if (Field == null) {
			if (other.Field != null)
				return false;
		} else if (!Field.equals(other.Field))
			return false;*/
		if (absentees == null) {
			if (other.absentees != null)
				return false;
		} else if (!absentees.equals(other.absentees))
			return false;
		if (attendance == null) {
			if (other.attendance != null)
				return false;
		} else if (!attendance.equals(other.attendance))
			return false;
		/*if (distId == null) {
			if (other.distId != null)
				return false;
		} else if (!distId.equals(other.distId))
			return false;*/
		if (month == null) {
			if (other.month != null)
				return false;
		} else if (!month.equals(other.month))
			return false;
		if (peId == null) {
			if (other.peId != null)
				return false;
		} else if (!peId.equals(other.peId))
			return false;
		if (percentage == null) {
			if (other.percentage != null)
				return false;
		} else if (!percentage.equals(other.percentage))
			return false;
		if (permission == null) {
			if (other.permission != null)
				return false;
		} else if (!permission.equals(other.permission))
			return false;
		if (summary == null) {
			if (other.summary != null)
				return false;
		} else if (!summary.equals(other.summary))
			return false;
		if (toPlay == null) {
			if (other.toPlay != null)
				return false;
		} else if (!toPlay.equals(other.toPlay))
			return false;
		if (totalBasicCompleted == null) {
			if (other.totalBasicCompleted != null)
				return false;
		} else if (!totalBasicCompleted.equals(other.totalBasicCompleted))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "PEreport [peId=" + peId + ", distId="  + ", Date=" + Date + ", month=" + month + ", year="
				+ year + ", totalBasicCompleted=" + totalBasicCompleted + ", toPlay=" + toPlay + ", attendance="
				+ attendance + ", permission=" + permission + ", absentees=" + absentees + ", Field="  
				+ ", percentage=" + percentage + ", summary=" + summary + ", districtMaster=" + districtMaster + "]";
	}
	
	
	
}
