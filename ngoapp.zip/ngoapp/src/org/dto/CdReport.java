package org.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="CdReport")
public class CdReport  {
	
	
	
	private Integer Men,Woman,TotalExpense;
	private String ProgramName,ProgramType,Advertisement,ChiefGuests,Media,Summary;
    private Integer Id;
	private Integer month;
	private Integer year;
    
    @Column(name="Date", unique=true, nullable=false)
   	private Integer Date;
    
	@Column(name="date")
	public Integer getDate() {
		return Date;
	}
	public void setDate(Integer date) {
		Date = date;
	}
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name="createdDate", unique=true, nullable=false)
	private java.util.Date createdDate; 
	
	public java.util.Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(java.util.Date createdDate) {
		this.createdDate = createdDate;
	}
    
	@Column(name="month")
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	@Column(name="year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	
   /* private Integer month;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private java.util.Date createdDate; 
	private Integer year;*/
	
/*	@Column(name="year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;*/
    
    	@Id
    	@GeneratedValue
    	@Column(insertable=false)
    	public Integer getId() {
			return Id;
		}
		public void setId(Integer id) {
			Id = id;
		}
		
		@Column(name="Men")
		public Integer getMen() {
			return Men;
		}
		
		public void setMen(Integer men) {
			Men = men;
		}
	/*	
		@Column(name="month")
		public Integer getMonth() {
			return month;
		}
		public void setMonth(Integer month) {
			this.month = month;
		}
		*/
		@Column(name="Woman")
		public Integer getWoman() {
			return Woman;
		}
		public void setWoman(Integer woman) {
			Woman = woman;
		}
		
		@Column(name="TotalExpense")
		public Integer getTotalExpense() {
			return TotalExpense;
		}
		public void setTotalExpense(Integer totalExpense) {
			TotalExpense = totalExpense;
		}
		
		@Column(name="ProgramName")
		public String getProgramName() {
			return ProgramName;
		}
		public void setProgramName(String programName) {
			ProgramName = programName;
		}
		
		@Column(name="ProgramType")
		public String getProgramType() {
			return ProgramType;
		}
		public void setProgramType(String programType) {
			ProgramType = programType;
		}
		
		@Column(name="Advertisement")
		public String getAdvertisement() {
			return Advertisement;
		}
		public void setAdvertisement(String advertisement) {
			Advertisement = advertisement;
		}
		
		@Column(name="ChiefGuests")
		public String getChiefGuests() {
			return ChiefGuests;
		}
		public void setChiefGuests(String chiefGuests) {
			ChiefGuests = chiefGuests;
		}
		
		@Column(name="Media")
		public String getMedia() {
			return Media;
		}
		public void setMedia(String media) {
			Media = media;
		}
		
		@Column(name="Summary", columnDefinition = "text")
		public String getSummary() {
			return Summary;
		}
		public void setSummary(String summary) {
			Summary = summary;
		}
	
		
		private DistrictMaster DistrictMaster;

		@OneToOne(fetch = FetchType.EAGER)
		@JoinColumn(name = "districtId", updatable = false)
		public DistrictMaster getDistrictMaster() {
			return DistrictMaster;
		}

		public void setDistrictMaster(DistrictMaster districtMaster) {
			this.DistrictMaster = districtMaster;
		}
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((Date == null) ? 0 : Date.hashCode());
			result = prime * result + ((DistrictMaster == null) ? 0 : DistrictMaster.hashCode());
			//result = prime * result + ((Field == null) ? 0 : Field.hashCode());
			result = prime * result + ((ProgramName == null) ? 0 : ProgramName.hashCode());
			result = prime * result + ((ProgramType == null) ? 0 : ProgramType.hashCode());
			//result = prime * result + ((distId == null) ? 0 : distId.hashCode());
			result = prime * result + ((month == null) ? 0 : month.hashCode());
			result = prime * result + ((Advertisement == null) ? 0 : Advertisement.hashCode());
			result = prime * result + ((ChiefGuests == null) ? 0 : ChiefGuests.hashCode());
			result = prime * result + ((Media == null) ? 0 : Media.hashCode());
			result = prime * result + ((Summary == null) ? 0 : Summary.hashCode());
			result = prime * result + ((Men == null) ? 0 : Men.hashCode());
			result = prime * result + ((Woman == null) ? 0 : Woman.hashCode());
			result = prime * result + ((year == null) ? 0 : year.hashCode());
			result = prime * result + ((TotalExpense == null) ? 0 : TotalExpense.hashCode());
			result = prime * result + ((Id == null) ? 0 : Id.hashCode());
			return result;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CdReport other = (CdReport) obj;
			if (Date == null) {
				if (other.Date != null)
					return false;
			} else if (!Date.equals(other.Date))
				return false;
			if (DistrictMaster == null) {
				if (other.DistrictMaster != null)
					return false;
			} else if (!DistrictMaster.equals(other.DistrictMaster))
				return false;
			/*if (Field == null) {
				if (other.Field != null)
					return false;
			} else if (!Field.equals(other.Field))
				return false;*/
			if (ProgramName == null) {
				if (other.ProgramName != null)
					return false;
			} else if (!ProgramName.equals(other.ProgramName))
				return false;
			if (ProgramType == null) {
				if (other.ProgramType != null)
					return false;
			} else if (!ProgramType.equals(other.ProgramType))
				return false;
			/*if (distId == null) {
				if (other.distId != null)
					return false;
			} else if (!distId.equals(other.distId))
				return false;*/
			if (month == null) {
				if (other.month != null)
					return false;
			} else if (!month.equals(other.month))
				return false;
			if (Advertisement == null) {
				if (other.Advertisement != null)
					return false;
			} else if (!Advertisement.equals(other.Advertisement))
				return false;
			if (ChiefGuests == null) {
				if (other.ChiefGuests != null)
					return false;
			} else if (!ChiefGuests.equals(other.ChiefGuests))
				return false;
			if (Media == null) {
				if (other.Media != null)
					return false;
			} else if (!Media.equals(other.Media))
				return false;
			if (Summary == null) {
				if (other.Summary != null)
					return false;
			} else if (!Summary.equals(other.Summary))
				return false;
			if (Men == null) {
				if (other.Men != null)
					return false;
			} else if (!Men.equals(other.Men))
				return false;
			if (Woman == null) {
				if (other.Woman != null)
					return false;
			} else if (!Woman.equals(other.Woman))
				return false;
			if (year == null) {
				if (other.year != null)
					return false;
			} else if (!year.equals(other.year))
				return false;
			if (TotalExpense == null) {
				if (other.TotalExpense != null)
					return false;
			} else if (!TotalExpense.equals(other.TotalExpense))
				return false;
			if (Id == null) {
				if (other.Id != null)
					return false;
			} else if (!Id.equals(other.Id))
				return false;
			return true;
		}
		
		@Override
		public String toString() {
			return "CdReport [cdId=" + Id + ", distId="  + ", Date=" + Date + ", month=" + month + ", year="
					+ year + ", ProgramName=" + ProgramName + ", ProgramType=" + ProgramType + ", Advertisement="
					+ Advertisement + ", ChiefGuests=" + ChiefGuests + ", Media=" + Media + ", Field="  
					+ ", Men=" + Men + ", Summary=" + Summary + ", districtMaster=" + DistrictMaster + "]";
		}

}
