package org.dto;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;

@SuppressWarnings("serial")
@Entity
@Table(name = "CdReportProgram")
public class CdReportProgram implements Serializable {

	@Id
	@GeneratedValue
	@Column(name = "cdId")
	private Integer cdId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	private DistrictMaster districtMaster;

	@Column(name = "month")
	private Integer month;

	@Column(name = "year")
	private Integer year;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Integer Date;

	@Column(name = "createdDate", nullable = false)
	private java.util.Date createdDate;

	@Column(name = "typeOfHelp")
	private String typeOfHelp;

	@Column(name = "amount")
	private Integer amount;

	@Column(name = "beneficiaries")
	private Integer beneficiaries;

	@Column(name = "noOfAwarenessCirculars")
	private Integer noOfAwarenessCirculars;

	@Column(name = "programName")
	private String programName;

	@Column(name = "typeOfProgram")
	private String typeOfProgram;

	@Column(name = "participants")
	private Integer participants;

	@Column(name = "programExpense")
	private Integer programExpense;

	@Column(name = "bloodDonation")
	private Integer bloodDonation;

	@Column(name = "summary", columnDefinition = "text")
	private String summary;

	public Integer getCdId() {
		return cdId;
	}

	public void setCdId(Integer cdId) {
		this.cdId = cdId;
	}

	public DistrictMaster getDistrictMaster() {
		return districtMaster;
	}

	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.districtMaster = districtMaster;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getDate() {
		return Date;
	}

	public void setDate(Integer date) {
		Date = date;
	}

	public String getTypeOfHelp() {
		return typeOfHelp;
	}

	public void setTypeOfHelp(String typeOfHelp) {
		this.typeOfHelp = typeOfHelp;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public Integer getBeneficiaries() {
		return beneficiaries;
	}

	public void setBeneficiaries(Integer beneficiaries) {
		this.beneficiaries = beneficiaries;
	}

	public Integer getNoOfAwarenessCirculars() {
		return noOfAwarenessCirculars;
	}

	public void setNoOfAwarenessCirculars(Integer noOfAwarenessCirculars) {
		this.noOfAwarenessCirculars = noOfAwarenessCirculars;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getTypeOfProgram() {
		return typeOfProgram;
	}

	public void setTypeOfProgram(String typeOfProgram) {
		this.typeOfProgram = typeOfProgram;
	}

	public Integer getParticipants() {
		return participants;
	}

	public void setParticipants(Integer participants) {
		this.participants = participants;
	}

	public Integer getProgramExpense() {
		return programExpense;
	}

	public void setProgramExpense(Integer programExpense) {
		this.programExpense = programExpense;
	}

	public Integer getBloodDonation() {
		return bloodDonation;
	}

	public void setBloodDonation(Integer bloodDonation) {
		this.bloodDonation = bloodDonation;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public java.util.Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(java.util.Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "CdReportProgram [cdId=" + cdId + ", districtMaster=" + districtMaster + ", month=" + month + ", year="
				+ year + ", Date=" + Date + ", typeOfHelp=" + typeOfHelp + ", amount=" + amount + ", beneficiaries="
				+ beneficiaries + ", noOfAwarenessCirculars=" + noOfAwarenessCirculars + ", programName=" + programName
				+ ", typeOfProgram=" + typeOfProgram + ", participants=" + participants + ", programExpense="
				+ programExpense + ", bloodDonation=" + bloodDonation + ", summary=" + summary + "]";
	}

}
