package org.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MonthlyReport")
public class MonthlyReport implements Serializable {

	private Long mrId;
	private Date created_Date;
	private Date modified_Date;
	private Integer month;
	private Integer year;
	private Integer lastMonthTotalMembers;
	private Integer newMembers;
	private Integer TLIn;
	private Integer TLOut;
	private Integer dismiss;
	private Integer currentMonthTotalMembers;
	private Integer totalUnits;
	private Integer totalArea;
	private Integer totalDivision;
	private String summary;

	@Id
	@GeneratedValue
	@Column(name = "mrId")
	public Long getMrId() {
		return mrId;
	}

	public void setMrId(Long mrId) {
		this.mrId = mrId;
	}

	@Column(name = "Created_Date")
	public Date getCreated_Date() {
		return created_Date;
	}

	public void setCreated_Date(Date created_Date) {
		this.created_Date = created_Date;
	}

	@Column(name = "Modified_Date")
	public Date getModified_Date() {
		return modified_Date;
	}

	public void setModified_Date(Date modified_Date) {
		this.modified_Date = modified_Date;
	}

	@Column(name = "month")
	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	@Column(name = "year")
	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	@Column(name = "lastMonthTotalMembers")
	public Integer getLastMonthTotalMembers() {
		return lastMonthTotalMembers;
	}

	public void setLastMonthTotalMembers(Integer lastMonthTotalMembers) {
		this.lastMonthTotalMembers = lastMonthTotalMembers;
	}

	@Column(name = "newMembers")
	public Integer getNewMembers() {
		return newMembers;
	}

	public void setNewMembers(Integer newMembers) {
		this.newMembers = newMembers;
	}

	@Column(name = "TLIn")
	public Integer getTLIn() {
		return TLIn;
	}

	public void setTLIn(Integer tLIn) {
		TLIn = tLIn;
	}

	@Column(name = "TLOut")
	public Integer getTLOut() {
		return TLOut;
	}

	public void setTLOut(Integer tLOut) {
		TLOut = tLOut;
	}

	@Column(name = "dismiss")
	public Integer getDismiss() {
		return dismiss;
	}

	public void setDismiss(Integer dismiss) {
		this.dismiss = dismiss;
	}

	@Column(name = "currentMonthTotalMembers")
	public Integer getCurrentMonthTotalMembers() {
		return currentMonthTotalMembers;
	}

	public void setCurrentMonthTotalMembers(Integer currentMonthTotalMembers) {
		this.currentMonthTotalMembers = currentMonthTotalMembers;
	}

	@Column(name = "totalUnits")
	public Integer getTotalUnits() {
		return totalUnits;
	}

	public void setTotalUnits(Integer totalUnits) {
		this.totalUnits = totalUnits;
	}

	@Column(name = "totalArea")
	public Integer getTotalArea() {
		return totalArea;
	}

	public void setTotalArea(Integer totalArea) {
		this.totalArea = totalArea;
	}

	@Column(name = "totalDivision")
	public Integer getTotalDivision() {
		return totalDivision;
	}

	public void setTotalDivision(Integer totalDivision) {
		this.totalDivision = totalDivision;
	}

	@Column(name = "summary", columnDefinition = "text")
	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	private DistrictMaster DistrictMaster;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	public DistrictMaster getDistrictMaster() {
		return DistrictMaster;
	}

	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.DistrictMaster = districtMaster;
	}

	
	
}