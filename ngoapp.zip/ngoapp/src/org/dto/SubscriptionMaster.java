package org.dto;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "SubscriptionMaster")
public class SubscriptionMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long subId;
	private Integer month, year, offeredSubscription, collected, balance, subGivenMember, offeredAdmission,
			admissionCollected, balanceAmount, addmissionGivenMember;

	@Column(name = "summary", columnDefinition = "text")
	private String summary;

	private Integer Date;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "createdDate", nullable = false)
	private java.util.Date createdDate;

	@Id
	@GeneratedValue
	@Column(name = "subId")
	public Long getSubId() {
		return subId;
	}

	public void setSubId(Long subId) {
		this.subId = subId;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getOfferedSubscription() {
		return offeredSubscription;
	}

	public void setOfferedSubscription(Integer offeredSubscription) {
		this.offeredSubscription = offeredSubscription;
	}

	public Integer getCollected() {
		return collected;
	}

	public void setCollected(Integer collected) {
		this.collected = collected;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public Integer getSubGivenMember() {
		return subGivenMember;
	}

	public void setSubGivenMember(Integer subGivenMember) {
		this.subGivenMember = subGivenMember;
	}

	public Integer getOfferedAdmission() {
		return offeredAdmission;
	}

	public void setOfferedAdmission(Integer offeredAdmission) {
		this.offeredAdmission = offeredAdmission;
	}

	public Integer getAdmissionCollected() {
		return admissionCollected;
	}

	public void setAdmissionCollected(Integer admissionCollected) {
		this.admissionCollected = admissionCollected;
	}

	public Integer getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Integer balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public Integer getAddmissionGivenMember() {
		return addmissionGivenMember;
	}

	public void setAddmissionGivenMember(Integer addmissionGivenMember) {
		this.addmissionGivenMember = addmissionGivenMember;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	private DistrictMaster DistrictMaster;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	public DistrictMaster getDistrictMaster() {
		return DistrictMaster;
	}

	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.DistrictMaster = districtMaster;
	}

	public Integer getDate() {
		return Date;
	}

	public void setDate(Integer date) {
		Date = date;
	}

	public java.util.Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(java.util.Date createdDate) {
		this.createdDate = createdDate;
	}

}
