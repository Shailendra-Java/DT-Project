package org.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "DistrictAdmin")
public class DistrictAdmin implements Serializable {

	private Integer Id, NumberOfDivision, NumberOfArea, NumberOfUnits;
	private Date Month, Comments;

	@Id
	@GeneratedValue
	@Column(name = "id")
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	@Column(name = "NumberOfDivision")
	public Integer getNumberOfDivision() {
		return NumberOfDivision;
	}

	public void setNumberOfDivision(Integer numberOfDivision) {
		NumberOfDivision = numberOfDivision;
	}

	@Column(name = "NumberOfArea")
	public Integer getNumberOfArea() {
		return NumberOfArea;
	}

	public void setNumberOfArea(Integer numberOfArea) {
		NumberOfArea = numberOfArea;
	}

	@Column(name = "NumberOfUnits")
	public Integer getNumberOfUnits() {
		return NumberOfUnits;
	}

	public void setNumberOfUnits(Integer numberOfUnits) {
		NumberOfUnits = numberOfUnits;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "createdDate", nullable = false, updatable = false)
	public Date getMonth() {
		return Month;
	}

	public void setMonth(Date month) {
		Month = month;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "Comments", nullable = false, updatable = false)
	public Date getComments() {
		return Comments;
	}

	public void setComments(Date comments) {
		Comments = comments;
	}

	private DistrictMaster DistrictMaster;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	public DistrictMaster getDistrictMaster() {
		return DistrictMaster;
	}

	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.DistrictMaster = districtMaster;
	}

}
