package org.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;


    @SuppressWarnings("serial")
	@Entity
	@Table(name="PublicGuidance")
	public class PublicGuidance implements Serializable{
		
		private Integer pgId;
		private Integer month,year,totalPG,pgParticipants,totalJG,jgParticipants,totalFG,fgParticipants,meetForDawa,kalima;
	
		 @Column(name="Date", unique=true, nullable=false)
		 
			private Integer Date;
			@DateTimeFormat(pattern = "yyyy-MM-dd")
			@Column(name="createdDate", unique=true, nullable=false)
			private java.util.Date createdDate; 
	 
		private String Summary;
		
	   
		@Id
		@GeneratedValue
		@Column(name="pgId")
		public Integer getPgId() {
			return pgId;
		}
		public void setPgId(Integer pgId) {
			this.pgId = pgId;
		}
		
		
		@Column(name="date")
		public Integer getDate() {
			return Date;
		}
		
		public void setDate(Integer date) {
			Date = date;
		}
		@Column(name="month")
		public Integer getMonth() {
			return month;
		}
		public void setMonth(Integer month) {
			this.month = month;
		}
		
		@Column(name="year")
		public Integer getYear() {
			return year;
		}
		public void setYear(Integer year) {
			this.year = year;
		}
		
		@Column(name="totalPG")
		public Integer getTotalPG() {
			return totalPG;
		}
		
		 public java.util.Date getCreatedDate() {
				return createdDate;
			}
			public void setCreatedDate(java.util.Date createdDate) {
				this.createdDate = createdDate;
			}
		
	
		public void setTotalPG(Integer totalPG) {
			this.totalPG = totalPG;
		}
		@Column(name="pgParticipants")
		public Integer getPgParticipants() {
			return pgParticipants;
		}
		public void setPgParticipants(Integer pgParticipants) {
			this.pgParticipants = pgParticipants;
		}
		
		@Column(name="totalJG")
		public Integer getTotalJG() {
			return totalJG;
		}
		public void setTotalJG(Integer totalJG) {
			this.totalJG = totalJG;
		}
		@Column(name="jgParticipants")
		public Integer getJgParticipants() {
			return jgParticipants;
		}
		public void setJgParticipants(Integer jgParticipants) {
			this.jgParticipants = jgParticipants;
		}
		@Column(name="totalFG")
		public Integer getTotalFG() {
			return totalFG;
		}
		public void setTotalFG(Integer totalFG) {
			this.totalFG = totalFG;
		}
		@Column(name="fgParticipants")
		public Integer getFgParticipants() {
			return fgParticipants;
		}
		public void setFgParticipants(Integer fgParticipants) {
			this.fgParticipants = fgParticipants;
		}
		@Column(name="meetForDawa")
		public Integer getMeetForDawa() {
			return meetForDawa;
		}
		public void setMeetForDawa(Integer meetForDawa) {
			this.meetForDawa = meetForDawa;
		}
		@Column(name="kalima")
		public Integer getKalima() {
			return kalima;
		}
		public void setKalima(Integer kalima) {
			this.kalima = kalima;
		}
		@Column(name="Summary",columnDefinition = "text")
		public String getSummary() {
			return Summary;
		}
		public void setSummary(String summary) {
			Summary = summary;
		}

		private DistrictMaster districtMaster;
		
		@OneToOne(fetch = FetchType.EAGER)
		@JoinColumn(name = "districtId", updatable = false)
		public DistrictMaster getDistrictMaster() {
			return districtMaster;
		}
		public void setDistrictMaster(DistrictMaster districtMaster) {
			this.districtMaster = districtMaster;
		}
		
	
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((Date == null) ? 0 : Date.hashCode());
			result = prime * result + ((Summary == null) ? 0 : Summary.hashCode());
			result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
			result = prime * result + ((districtMaster == null) ? 0 : districtMaster.hashCode());
			result = prime * result + ((fgParticipants == null) ? 0 : fgParticipants.hashCode());
			result = prime * result + ((jgParticipants == null) ? 0 : jgParticipants.hashCode());
			result = prime * result + ((kalima == null) ? 0 : kalima.hashCode());
			result = prime * result + ((meetForDawa == null) ? 0 : meetForDawa.hashCode());
			result = prime * result + ((month == null) ? 0 : month.hashCode());
			result = prime * result + ((pgId == null) ? 0 : pgId.hashCode());
			result = prime * result + ((pgParticipants == null) ? 0 : pgParticipants.hashCode());
			result = prime * result + ((totalFG == null) ? 0 : totalFG.hashCode());
			result = prime * result + ((totalJG == null) ? 0 : totalJG.hashCode());
			result = prime * result + ((totalPG == null) ? 0 : totalPG.hashCode());
			result = prime * result + ((year == null) ? 0 : year.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PublicGuidance other = (PublicGuidance) obj;
			if (Date == null) {
				if (other.Date != null)
					return false;
			} else if (!Date.equals(other.Date))
				return false;
			if (Summary == null) {
				if (other.Summary != null)
					return false;
			} else if (!Summary.equals(other.Summary))
				return false;
			if (createdDate == null) {
				if (other.createdDate != null)
					return false;
			} else if (!createdDate.equals(other.createdDate))
				return false;
			if (districtMaster == null) {
				if (other.districtMaster != null)
					return false;
			} else if (!districtMaster.equals(other.districtMaster))
				return false;
			if (fgParticipants == null) {
				if (other.fgParticipants != null)
					return false;
			} else if (!fgParticipants.equals(other.fgParticipants))
				return false;
			if (jgParticipants == null) {
				if (other.jgParticipants != null)
					return false;
			} else if (!jgParticipants.equals(other.jgParticipants))
				return false;
			if (kalima == null) {
				if (other.kalima != null)
					return false;
			} else if (!kalima.equals(other.kalima))
				return false;
			if (meetForDawa == null) {
				if (other.meetForDawa != null)
					return false;
			} else if (!meetForDawa.equals(other.meetForDawa))
				return false;
			if (month == null) {
				if (other.month != null)
					return false;
			} else if (!month.equals(other.month))
				return false;
			if (pgId == null) {
				if (other.pgId != null)
					return false;
			} else if (!pgId.equals(other.pgId))
				return false;
			if (pgParticipants == null) {
				if (other.pgParticipants != null)
					return false;
			} else if (!pgParticipants.equals(other.pgParticipants))
				return false;
			if (totalFG == null) {
				if (other.totalFG != null)
					return false;
			} else if (!totalFG.equals(other.totalFG))
				return false;
			if (totalJG == null) {
				if (other.totalJG != null)
					return false;
			} else if (!totalJG.equals(other.totalJG))
				return false;
			if (totalPG == null) {
				if (other.totalPG != null)
					return false;
			} else if (!totalPG.equals(other.totalPG))
				return false;
			if (year == null) {
				if (other.year != null)
					return false;
			} else if (!year.equals(other.year))
				return false;
			return true;
		}
		@Override
		public String toString() {
			return "PublicGuidance [pgId=" + pgId + ", month=" + month + ", year=" + year + ", totalPG=" + totalPG
					+ ", pgParticipants=" + pgParticipants + ", totalJG=" + totalJG + ", jgParticipants="
					+ jgParticipants + ", totalFG=" + totalFG + ", fgParticipants=" + fgParticipants + ", meetForDawa="
					+ meetForDawa + ", kalima=" + kalima + ", Date=" + Date + ", createdDate=" + createdDate
					+ ", Summary=" + Summary + ", districtMaster=" + districtMaster + "]";
		}
		
		
		
	}