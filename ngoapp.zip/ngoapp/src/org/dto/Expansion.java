package org.dto;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="expansion")
public class Expansion {
	private Integer expId;
	//private Long distId;
	private Integer month;
	private Integer year;
	private Integer a;
	private Integer aOk;
	private Integer b;
	private Integer fc;
	private Integer newMember;
	private Integer admissionAmount;
	private Integer subAmount;
	private String summary;
	
	@Column(name="Date", unique=true, nullable=false)
	private Integer Date;
	
	@Column(name="date")
	public Integer getDate() {
		return Date;
	}
	public void setDate(Integer date) {
		Date = date;
	}
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private java.util.Date createdDate; 

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="expId")
	public Integer getExpId() {
		return expId;
	}
	public void setExpId(Integer expId) {
		this.expId = expId;
	}
	/*@Column(name="distId")
	public Long getDistId() {
		return distId;
	}
	public void setDistId(Long distId) {
		this.distId = distId;
	}*/
	@Column(name="month")
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	@Column(name="year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	@Column(name="a")
	public Integer getA() {
		return a;
	}
	public void setA(Integer a) {
		this.a = a;
	}
	@Column(name="aOk")
	public Integer getaOk() {
		return aOk;
	}
	public void setaOk(Integer aOk) {
		this.aOk = aOk;
	}
	@Column(name="b")
	public Integer getB() {
		return b;
	}
	public void setB(Integer b) {
		this.b = b;
	}
	@Column(name="fc")
	public Integer getFc() {
		return fc;
	}
	public void setFc(Integer fc) {
		this.fc = fc;
	}
	@Column(name="newMember")
	public Integer getNewMember() {
		return newMember;
	}
	public void setNewMember(Integer newMember) {
		this.newMember = newMember;
	}
	@Column(name="admissionAmount")
	public Integer getAdmissionAmount() {
		return admissionAmount;
	}
	public void setAdmissionAmount(Integer admissionAmount) {
		this.admissionAmount = admissionAmount;
	}
	@Column(name="subAmount")
	public Integer getSubAmount() {
		return subAmount;
	}
	public void setSubAmount(Integer subAmount) {
		this.subAmount = subAmount;
	}
	@Column(name="summary", columnDefinition = "text")
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	private DistrictMaster districtMaster;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	public DistrictMaster getDistrictMaster() {
		return districtMaster;
	}
	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.districtMaster = districtMaster;
	}
	
	
	public java.util.Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(java.util.Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "Expansion [expId=" + expId + ", distId=" +  ", month=" + month + ", year=" + year + ", a=" + a
				+ ", aOk=" + aOk + ", b=" + b + ", fc=" + fc + ", newMember=" + newMember + ", admissionAmount="
				+ admissionAmount + ", subAmount=" + subAmount + ", summary=" + summary + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((a == null) ? 0 : a.hashCode());
		result = prime * result + ((aOk == null) ? 0 : aOk.hashCode());
		result = prime * result + ((admissionAmount == null) ? 0 : admissionAmount.hashCode());
		result = prime * result + ((b == null) ? 0 : b.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		//result = prime * result + ((distId == null) ? 0 : distId.hashCode());
		result = prime * result + ((districtMaster == null) ? 0 : districtMaster.hashCode());
		result = prime * result + ((expId == null) ? 0 : expId.hashCode());
		result = prime * result + ((fc == null) ? 0 : fc.hashCode());
		result = prime * result + ((month == null) ? 0 : month.hashCode());
		result = prime * result + ((newMember == null) ? 0 : newMember.hashCode());
		result = prime * result + ((subAmount == null) ? 0 : subAmount.hashCode());
		result = prime * result + ((summary == null) ? 0 : summary.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Expansion other = (Expansion) obj;
		if (a == null) {
			if (other.a != null)
				return false;
		} else if (!a.equals(other.a))
			return false;
		if (aOk == null) {
			if (other.aOk != null)
				return false;
		} else if (!aOk.equals(other.aOk))
			return false;
		if (admissionAmount == null) {
			if (other.admissionAmount != null)
				return false;
		} else if (!admissionAmount.equals(other.admissionAmount))
			return false;
		if (b == null) {
			if (other.b != null)
				return false;
		} else if (!b.equals(other.b))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		/*if (distId == null) {
			if (other.distId != null)
				return false;
		} else if (!distId.equals(other.distId))
			return false;*/
		if (districtMaster == null) {
			if (other.districtMaster != null)
				return false;
		} else if (!districtMaster.equals(other.districtMaster))
			return false;
		if (expId == null) {
			if (other.expId != null)
				return false;
		} else if (!expId.equals(other.expId))
			return false;
		if (fc == null) {
			if (other.fc != null)
				return false;
		} else if (!fc.equals(other.fc))
			return false;
		if (month == null) {
			if (other.month != null)
				return false;
		} else if (!month.equals(other.month))
			return false;
		if (newMember == null) {
			if (other.newMember != null)
				return false;
		} else if (!newMember.equals(other.newMember))
			return false;
		if (subAmount == null) {
			if (other.subAmount != null)
				return false;
		} else if (!subAmount.equals(other.subAmount))
			return false;
		if (summary == null) {
			if (other.summary != null)
				return false;
		} else if (!summary.equals(other.summary))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}
	
	
	
	
}