package org.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "AttendanceMaster")
@SecondaryTable(name = "AttendanceMapping")
public class AttendanceMaster implements Serializable {

	private Integer attdId;
	private Integer month, year, Total_DEC_Members, Guidance_Present, DEC_Meet_Present, Present_in_unit, attType,
			present, leave_taken, absent, Date;
	private String summary;
	private Float percentage_Present_in_unit, percentage_Guidance_Present, percentage_Total_DEC_Members;

	@Id
	@GeneratedValue
	@Column(name = "attdId")
	public Integer getAttdId() {
		return attdId;
	}

	public void setAttdId(Integer attdId) {
		this.attdId = attdId;
	}

	@Column(name = "Date", unique = true, nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")

	private java.util.Date createdDate;

	@Column(name = "date")
	public Integer getDate() {
		return Date;
	}

	public void setDate(Integer date) {
		Date = date;
	}

	public java.util.Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(java.util.Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getPresent_in_unit() {
		return Present_in_unit;
	}

	public void setPresent_in_unit(Integer present_in_unit) {
		Present_in_unit = present_in_unit;
	}

	public Float getPercentage_Present_in_unit() {
		return percentage_Present_in_unit;
	}

	public void setPercentage_Present_in_unit(Float percentage_Present_in_unit) {
		this.percentage_Present_in_unit = percentage_Present_in_unit;
	}

	public Float getPercentage_Guidance_Present() {
		return percentage_Guidance_Present;
	}

	public void setPercentage_Guidance_Present(Float percentage_Guidance_Present) {
		this.percentage_Guidance_Present = percentage_Guidance_Present;
	}

	public Float getPercentage_Total_DEC_Members() {
		return percentage_Total_DEC_Members;
	}

	public void setPercentage_Total_DEC_Members(Float percentage_Total_DEC_Members) {
		this.percentage_Total_DEC_Members = percentage_Total_DEC_Members;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getGuidance_Present() {
		return Guidance_Present;
	}

	public void setGuidance_Present(Integer guidance_Present) {
		Guidance_Present = guidance_Present;
	}

	public Integer getTotal_DEC_Members() {
		return Total_DEC_Members;
	}

	public void setTotal_DEC_Members(Integer total_DEC_Members) {
		Total_DEC_Members = total_DEC_Members;
	}

	public Integer getDEC_Meet_Present() {
		return DEC_Meet_Present;
	}

	public void setDEC_Meet_Present(Integer dEC_Meet_Present) {
		DEC_Meet_Present = dEC_Meet_Present;
	}

	@Column(table = "AttendanceMapping")
	public Integer getAttType() {
		return attType;
	}

	public void setAttType(Integer attType) {
		this.attType = attType;
	}

	@Column(table = "AttendanceMapping")
	public Integer getPresent() {
		return present;
	}

	public void setPresent(Integer present) {
		this.present = present;
	}

	@Column(table = "AttendanceMapping")
	public Integer getLeave_taken() {
		return leave_taken;
	}

	public void setLeave_taken(Integer leave_taken) {
		this.leave_taken = leave_taken;
	}

	@Column(table = "AttendanceMapping")
	public Integer getAbsent() {
		return absent;
	}

	public void setAbsent(Integer absent) {
		this.absent = absent;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	private DistrictMaster DistrictMaster;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "districtId", updatable = false)
	public DistrictMaster getDistrictMaster() {
		return DistrictMaster;
	}

	public void setDistrictMaster(DistrictMaster districtMaster) {
		this.DistrictMaster = districtMaster;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((DEC_Meet_Present == null) ? 0 : DEC_Meet_Present.hashCode());
		result = prime * result + ((DistrictMaster == null) ? 0 : DistrictMaster.hashCode());
		result = prime * result + ((Guidance_Present == null) ? 0 : Guidance_Present.hashCode());
		result = prime * result + ((Present_in_unit == null) ? 0 : Present_in_unit.hashCode());
		result = prime * result + ((Total_DEC_Members == null) ? 0 : Total_DEC_Members.hashCode());
		result = prime * result + ((absent == null) ? 0 : absent.hashCode());
		result = prime * result + ((attType == null) ? 0 : attType.hashCode());
		result = prime * result + ((attdId == null) ? 0 : attdId.hashCode());
		result = prime * result + ((leave_taken == null) ? 0 : leave_taken.hashCode());
		result = prime * result + ((month == null) ? 0 : month.hashCode());
		result = prime * result + ((percentage_Guidance_Present == null) ? 0 : percentage_Guidance_Present.hashCode());
		result = prime * result + ((percentage_Present_in_unit == null) ? 0 : percentage_Present_in_unit.hashCode());
		result = prime * result
				+ ((percentage_Total_DEC_Members == null) ? 0 : percentage_Total_DEC_Members.hashCode());
		result = prime * result + ((present == null) ? 0 : present.hashCode());
		result = prime * result + ((summary == null) ? 0 : summary.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AttendanceMaster other = (AttendanceMaster) obj;
		if (DEC_Meet_Present == null) {
			if (other.DEC_Meet_Present != null)
				return false;
		} else if (!DEC_Meet_Present.equals(other.DEC_Meet_Present))
			return false;
		if (DistrictMaster == null) {
			if (other.DistrictMaster != null)
				return false;
		} else if (!DistrictMaster.equals(other.DistrictMaster))
			return false;
		if (Guidance_Present == null) {
			if (other.Guidance_Present != null)
				return false;
		} else if (!Guidance_Present.equals(other.Guidance_Present))
			return false;
		if (Present_in_unit == null) {
			if (other.Present_in_unit != null)
				return false;
		} else if (!Present_in_unit.equals(other.Present_in_unit))
			return false;
		if (Total_DEC_Members == null) {
			if (other.Total_DEC_Members != null)
				return false;
		} else if (!Total_DEC_Members.equals(other.Total_DEC_Members))
			return false;
		if (absent == null) {
			if (other.absent != null)
				return false;
		} else if (!absent.equals(other.absent))
			return false;
		if (attType == null) {
			if (other.attType != null)
				return false;
		} else if (!attType.equals(other.attType))
			return false;
		if (attdId == null) {
			if (other.attdId != null)
				return false;
		} else if (!attdId.equals(other.attdId))
			return false;
		if (leave_taken == null) {
			if (other.leave_taken != null)
				return false;
		} else if (!leave_taken.equals(other.leave_taken))
			return false;
		if (month == null) {
			if (other.month != null)
				return false;
		} else if (!month.equals(other.month))
			return false;
		if (percentage_Guidance_Present == null) {
			if (other.percentage_Guidance_Present != null)
				return false;
		} else if (!percentage_Guidance_Present.equals(other.percentage_Guidance_Present))
			return false;
		if (percentage_Present_in_unit == null) {
			if (other.percentage_Present_in_unit != null)
				return false;
		} else if (!percentage_Present_in_unit.equals(other.percentage_Present_in_unit))
			return false;
		if (percentage_Total_DEC_Members == null) {
			if (other.percentage_Total_DEC_Members != null)
				return false;
		} else if (!percentage_Total_DEC_Members.equals(other.percentage_Total_DEC_Members))
			return false;
		if (present == null) {
			if (other.present != null)
				return false;
		} else if (!present.equals(other.present))
			return false;
		if (summary == null) {
			if (other.summary != null)
				return false;
		} else if (!summary.equals(other.summary))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AttendanceMaster [attdId=" + attdId + ", month=" + month + ", year=" + year + ", Total_DEC_Members="
				+ Total_DEC_Members + ", Guidance_Present=" + Guidance_Present + ", DEC_Meet_Present="
				+ DEC_Meet_Present + ", Present_in_unit=" + Present_in_unit + ", attType=" + attType + ", present="
				+ present + ", leave_taken=" + leave_taken + ", absent=" + absent + ", percentage_Present_in_unit="
				+ percentage_Present_in_unit + ", percentage_Guidance_Present=" + percentage_Guidance_Present
				+ ", percentage_Total_DEC_Members=" + percentage_Total_DEC_Members + ", summary=" + summary
				+ ", DistrictMaster=" + DistrictMaster + "]";
	}

}