package org.dao;

import java.util.List;

import org.dto.CdReportProgram;

public interface CdReportProgramDAO {

	List<CdReportProgram> getAllCdReportProgram();

	void saveReport(CdReportProgram report);

	public CdReportProgram getReportById(int id);

	void updateCDreportprogram(CdReportProgram cdreportprogram);

	public void deleteCDreportprogram(Integer cdId);

	public List<CdReportProgram> viewReport();

	CdReportProgram getMonthlyReportByMonthYearDistrict(String date1, int did);

	CdReportProgram getMonthlyReportByMonthYearDistrict(int year, int month, int did);

}
