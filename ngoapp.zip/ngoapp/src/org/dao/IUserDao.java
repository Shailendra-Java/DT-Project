package org.dao;

import java.util.List;

import org.dto.UserMaster;

public interface IUserDao {

	void saveUser(UserMaster user);

	List<UserMaster> getUserList();

    UserMaster getUserById(int id);

	void updateUser(UserMaster user);
	
}
