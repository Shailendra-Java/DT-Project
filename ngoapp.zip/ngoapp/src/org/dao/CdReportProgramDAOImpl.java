package org.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.dto.CdReportProgram;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
public class CdReportProgramDAOImpl implements CdReportProgramDAO {

	private static final Logger logger = LoggerFactory.getLogger(CdReportProgramDAOImpl.class);

	@Autowired
	private HibernateSessionFactory factory;

	@Override
	@Transactional
	public void saveReport(CdReportProgram report) {
		System.out.println("hiiiiiiii save");
		Session session = factory.getSession();
		session.save(report);
		logger.info("saveReport in CdReportProgramDAOImpl=" + report);

	}

	@Override
	@Transactional
	public List<CdReportProgram> getAllCdReportProgram() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<CdReportProgram> cdreportList = session.createCriteria(CdReportProgram.class).list();
		System.out.println("hiiiiiiii DAO");
		return cdreportList;
	}

	@Override
	@Transactional
	public CdReportProgram getReportById(int id) {
		System.out.println("hello DAO");
		Session session = factory.getSession();
		CdReportProgram editCDreportprogram = (CdReportProgram) session.get(CdReportProgram.class, id);
		return editCDreportprogram;
	}

	@Override
	@Transactional
	public void updateCDreportprogram(CdReportProgram cdreportprogram) {
		Session session = factory.getSession();
		session.update(cdreportprogram);

	}

	@Override
	@Transactional
	public void deleteCDreportprogram(Integer cdId) {
		CdReportProgram deleteCDreportprogram = (CdReportProgram) factory.getSession().load(CdReportProgram.class,
				cdId);
		if (null != deleteCDreportprogram) {

			this.factory.getSession().delete(deleteCDreportprogram);

		}
	}

	@Override
	@Transactional
	public List<CdReportProgram> viewReport() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<CdReportProgram> viewList = session.createCriteria(CdReportProgram.class).list();
		System.out.println("hiiiiiiii DAO");
		return viewList;

	}

	@Transactional
	@Override
	public CdReportProgram getMonthlyReportByMonthYearDistrict(String date1, int did) {
		System.out.println("inside get" + date1 + " " + " " + did);
		Session session = factory.getSession();
		/*
		 * DateFormat sdf = new SimpleDateFormat("yyyy-mm-dd"); String createdDate1 =
		 * null; try { createdDate1 = sdf.format(date1); } catch (Exception e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

		Date startDate = null;
		try {
			startDate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(date1).getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CdReportProgram cdreportprogram = (CdReportProgram) session.createCriteria(CdReportProgram.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("createdDate", startDate))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		System.out.println("hi" + cdreportprogram);

		return cdreportprogram;
	}

	@Override
	@Transactional
	public CdReportProgram getMonthlyReportByMonthYearDistrict(int year, int month, int did) {
		System.out.println("inside get" + month + " " + year + " " + did);
		Session session = factory.getSession();
		CdReportProgram cdreportprogram = (CdReportProgram) session.createCriteria(CdReportProgram.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", did)).uniqueResult();
		System.out.println(cdreportprogram);

		return cdreportprogram;
	}

}