package org.dao;
import java.util.List;

import org.dto.UserMaster;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;


@Repository
public class UserDao implements IUserDao {
	
	@Autowired
	private HibernateSessionFactory  factory;
	
	
	@Transactional
	public void saveUser(UserMaster user)
	{
		Session session=factory.getSession();

		session.save(user);
		
	}
		
	@Transactional
	public List<UserMaster> getUserList() {
		Session session=factory.getSession();
		@SuppressWarnings("unchecked")
		List<UserMaster> users=session.createCriteria(UserMaster.class).addOrder(Order.desc("createdDate")).list();	
		return users;
	}
	
   
	@Transactional
	public UserMaster getUserById(int id) {
		Session session=factory.getSession();
		UserMaster user=(UserMaster) session.get(UserMaster.class,id);
		return user;
	}

	@Transactional
    public void updateUser(UserMaster user) {
    Session session=factory.getSession();
	session.update(user);
		
	}

}
