package org.dao;

import java.util.List;

import org.dto.MonthlyTLIN;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
 public class MonthlyTLINOutDao implements IMonthlyTLInOutDao{

	@Autowired
	private HibernateSessionFactory  factory;

	@Override
	@Transactional
	public void saveMonthlyTLIN(MonthlyTLIN monthlyTLIN) {
		Session session=factory.getSession();				
				session.save(monthlyTLIN);
	}

	@Override
	@Transactional
	public List<MonthlyTLIN> getMonthlyTLINList(String typeofTL) {
		Session session=factory.getSession();
		@SuppressWarnings("unchecked")
		List<MonthlyTLIN> monthlyTLIN=session.createCriteria(MonthlyTLIN.class)
		.add(Restrictions.eq("typeofTL", typeofTL))
		.list();	
		return monthlyTLIN;
	}

	@Override
	@Transactional
	@SuppressWarnings("unchecked")
	public MonthlyTLIN getByMtlId(long mtlId) {
		System.out.println("inside dao: "+mtlId);
		Session session=factory.getSession();
		MonthlyTLIN monthlyTLIN = (MonthlyTLIN) session.get(MonthlyTLIN.class, mtlId);
		return monthlyTLIN;
	}

	@Override
	@Transactional
	public void updateTLInOutDismiss(MonthlyTLIN monthlyTLIN) {
		System.out.println("inside update dao: ");
		Session session=factory.getSession();
		session.update(monthlyTLIN);
	}

	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<MonthlyTLIN> getMonthlyTLINList() {
		System.out.println("inside getMonthlyTLINListDao");

		Session session=factory.getSession();
		
	
		List<MonthlyTLIN> monthlyTLIN=session.createCriteria(MonthlyTLIN.class).addOrder(Order.asc("month"))
		.list();
		
		System.out.println("monthlyTLIN Inside DAo");
		
		return monthlyTLIN;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<MonthlyTLIN> getMonthlyTLINListByMonth(int month, int districtId) {
		
		System.out.println("inside getMonthlyTLINListByMonth");

		Session session=factory.getSession();
		
		List<MonthlyTLIN> monthlyTLIN= (List<MonthlyTLIN>) session.createQuery("SELECT * FROM esquare_ngo.MonthlyTLIN where month="+month+" and districtId="+districtId);
		
		return monthlyTLIN;
	}

	@Override
	@Transactional
	@SuppressWarnings("unchecked")
	public void deleteTLInOut(long mtlId) {
		Session session=factory.getSession();
		MonthlyTLIN deleteTLInOut= (MonthlyTLIN) session.load(MonthlyTLIN.class, mtlId);	
		if (null != deleteTLInOut){
			session.delete(deleteTLInOut);
		}
		System.out.println("deleted successfully"+deleteTLInOut);
	}
	
	@Transactional
	@Override
	// @SuppressWarnings("unchecked")
	public MonthlyTLIN getReportByMonthYearDistrict(int year, int month, int did) {
		// TODO Auto-generated method stub
		System.out.println("t12-----111 "+year+"tttt"+month+"llll"+did);
		
		Session session=factory.getSession();
		MonthlyTLIN tl2=(MonthlyTLIN) session.createCriteria(MonthlyTLIN.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		/*session.close();*/
		System.out.println("t12----- "+tl2);
		return tl2;
	}
	
	@Transactional
	@Override
	public MonthlyTLIN getMonthlyReportAll(int year, int districtId, int month) {
		System.out.println("inside updatall get" + month + " " + year + " " + districtId);
		Session session = factory.getSession();
		MonthlyTLIN mt = (MonthlyTLIN) session.createCriteria(MonthlyTLIN.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

		return mt;
	}
	
	
	@Override
	@Transactional
	@SuppressWarnings("unchecked")
	public List<MonthlyTLIN> getTLAllreport() {
		System.out.println("inside get TLAll Report");
		Session session = factory.getSession();
		List<MonthlyTLIN> list = session.createCriteria(MonthlyTLIN.class).addOrder(Order.asc("month"))

				.list();

		return list;
	}
	
	
	@Transactional
	@Override
	public MonthlyTLIN getMonthchartTLIN() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		MonthlyTLIN viewList = (MonthlyTLIN) session.createCriteria(MonthlyTLIN.class).list();
		System.out.println("hi MonthlchartDAO");
		return viewList;
	}

	/*@Override
	public List<MonthlyTLIN> getMonthlyTLINListByMonth() {
		// TODO Auto-generated method stub
		return null;
	}*/

	
	

	
	


	
	
}
