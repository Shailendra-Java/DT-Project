package org.dao;

import java.util.List;
import org.dto.AttendanceMaster;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.Attdtypes;
import org.util.HibernateSessionFactory;

@Repository
public class AttendanceDao implements IAttendanceDao {
	private static final Logger logger = LoggerFactory.getLogger(AttendanceDao.class);
	@Autowired
	private HibernateSessionFactory factory;

	@Override
	@Transactional
	public void saveattendance(AttendanceMaster attendance) {

		Session session = factory.getSession();
		System.out.println("checker works");
		System.out.println("Date::" + attendance.getDate());

		session.save(attendance);
		logger.info("saveReport in CDreportDAOImpl=" + attendance);

		if (attendance.getGuidance_Present() != null) {

			Integer set_Guidance_Present = Attdtypes.Guidance_Present();
			attendance.setAttType(set_Guidance_Present);
		} else if (attendance.getPresent_in_unit() != null) {

			Integer present_in_unit = Attdtypes.Present_in_unit();
			attendance.setAttType(present_in_unit);
		} else if (attendance.getDEC_Meet_Present() != null) {

			Integer Total_DEC_Members = Attdtypes.Total_DEC_Members();
			attendance.setAttType(Total_DEC_Members);
		}

	}

	@Override
	@Transactional
	public List<AttendanceMaster> getAttendanceList() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<AttendanceMaster> attendancelist = session.createCriteria(AttendanceMaster.class).list();
		return attendancelist;

	}

	@Override
	@Transactional
	public AttendanceMaster getattendanceByMonthYearDistrict(int year) {
		Session session = factory.getSession();
		AttendanceMaster attendancemaster = (AttendanceMaster) session.createCriteria(AttendanceMaster.class)
				.add(Restrictions.eq("year", year)).uniqueResult();

		return attendancemaster;

	}

	@Override
	@Transactional
	public List<AttendanceMaster> getattendanceAllreport() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<AttendanceMaster> attendanceList = session.createCriteria(AttendanceMaster.class).list();

		return attendanceList;
	}

	@Override
	@Transactional
	public AttendanceMaster geteditReportById(Long id) {
		Session session = factory.getSession();

		AttendanceMaster editPEreport = (AttendanceMaster) session.get(AttendanceMaster.class, id);

		return editPEreport;

	}

	@Override
	@Transactional

	public void updatePEreport(AttendanceMaster attendance) {
		Session session = factory.getSession();
		session.update(attendance);

	}

	@Override
	@Transactional
	public AttendanceMaster getReportById(int id) {

		Session session = factory.getSession();
		AttendanceMaster editAttendanceMaster = (AttendanceMaster) session.get(AttendanceMaster.class, id);
		return editAttendanceMaster;
	}

	@Override
	@Transactional
	public void deleteAttendanceReport(Integer attendanceId) {
		Session session = factory.getSession();
		AttendanceMaster deleteAttendanceReport = (AttendanceMaster) session.load(AttendanceMaster.class, attendanceId);
		if (null != deleteAttendanceReport) {
			this.factory.getSession().delete(deleteAttendanceReport);
		}

	}

	@Override
	@Transactional
	public AttendanceMaster getReportByMonthYearDistrict(int m, int y, int did) {
		// TODO Auto-generated method stub
		Session session = factory.getSession();
		AttendanceMaster attendance = (AttendanceMaster) session.createCriteria(AttendanceMaster.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m)).add(Restrictions.eq("year", y))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return attendance;
	}

	@Override
	@Transactional
	public AttendanceMaster getAttendancereportAll(int y, int did, int m) {
		Session session = factory.getSession();
		AttendanceMaster mr = (AttendanceMaster) session.createCriteria(AttendanceMaster.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m)).add(Restrictions.eq("year", y))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return mr;
	}

}