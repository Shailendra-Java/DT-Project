package org.dao;

import java.util.List;
import org.dto.PublicGuidance;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
public class PublicGuidanceDao implements IPublicGuidanceDao {
	private static final Logger logger = LoggerFactory.getLogger(PublicGuidanceDao.class);

	@Autowired
	private HibernateSessionFactory factory;

	@Override
	@Transactional
	public void savePublicguidance(PublicGuidance publicguid) {

		Session session = factory.getSession();

		System.out.println("Date::" + publicguid.getDate());

		session.save(publicguid);
		logger.info("saveReport in CDreportDAOImpl=" + publicguid);
	}

	@Override
	@Transactional
	public List<PublicGuidance> getPublicguidanceAllreport() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<PublicGuidance> PublicGuidance = session.createCriteria(PublicGuidance.class).list();

		return PublicGuidance;

	}

	@Override
	@Transactional
	public List<PublicGuidance> getPublicGuidanceList() {

		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<PublicGuidance> PublicGuidanceList = session.createCriteria(PublicGuidance.class).list();

		return PublicGuidanceList;

	}

	@Override
	@Transactional
	public PublicGuidance geteditReportById(int pgId) {

		Session session = factory.getSession();
		PublicGuidance editpublicguidancereport = (PublicGuidance) session.get(PublicGuidance.class, pgId);
		return editpublicguidancereport;
	}

	@Override
	@Transactional
	public PublicGuidance updatepublicguidancereport(PublicGuidance PublicGuidance) {
		Session session = factory.getSession();
		session.update(PublicGuidance);
		return PublicGuidance;
	}

	@Override
	public void deletePGReport(Integer pgId) {
		PublicGuidance deletePEreport = (PublicGuidance) factory.getSession().load(PublicGuidance.class, pgId);
		if (null != deletePEreport) {
			this.factory.getSession().delete(deletePEreport);
		}
	}

	@Override
	@Transactional
	public PublicGuidance getId(Integer pgId) {
		Session session = factory.getSession();
		PublicGuidance user = (PublicGuidance) session.get(PublicGuidance.class, pgId);
		return user;
	}

	@Override
	@Transactional
	public PublicGuidance getReportByMonthYearDistrict(int y, int m, int did) {
		// TODO Auto-generated method stub
		Session session = factory.getSession();
		PublicGuidance pg2 = (PublicGuidance) session.createCriteria(PublicGuidance.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m)).add(Restrictions.eq("year", y))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return pg2;
	}

	@Override
	@Transactional
	public PublicGuidance getReportByMonthYearDistrictpgid(int y, int m, int did) {
		// TODO Auto-generated method stub
		Session session = factory.getSession();
		PublicGuidance pg3 = (PublicGuidance) session.createCriteria(PublicGuidance.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m)).add(Restrictions.eq("year", y))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return pg3;
	}

}
