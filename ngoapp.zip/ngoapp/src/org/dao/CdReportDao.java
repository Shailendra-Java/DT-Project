package org.dao;

import java.util.Date;
import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.MonthlyReport;
import org.dto.PEreport;
import org.dto.UserMaster;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.Attdtypes;
import org.util.HibernateSessionFactory;


@Repository
public class CdReportDao implements ICdReportDao {
	
	private static final Logger logger = LoggerFactory.getLogger(CdReportDao.class);

	@Autowired
	private HibernateSessionFactory  factory;
	
	
 /*  @Transactional
	public void saveCdReport(CdReport cdreport) {
		
		Session session=factory.getSession();
		
		System.out.println("checker works");

		session.save(cdreport);
		
		 if(cdreport.getProgramName()!=null){
        	 
            Integer set_Guidance_Present= (Integer) Attdtypes.Guidance_Present();
             cdreport.setTotalExpense(set_Guidance_Present);
       }
        else if(cdreport.getProgramName()!=null){
       	 
       	   Integer present_in_unit= (Integer) Attdtypes.Present_in_unit();
       	cdreport.setMen(present_in_unit); 
        }
        else if(cdreport.getProgramType()!=null){
       	 
            Integer Total_DEC_Members= (Integer) Attdtypes.Total_DEC_Members();
            cdreport.setWoman(Total_DEC_Members);
        }
	}*/
	
	@Override
	@Transactional 
	public void saveCdReport(CdReport cdreport) {
		Session session=factory.getSession();
		session.save(cdreport);
		logger.info("saveReport in CDreportDAOImpl="+cdreport);
	}

@Transactional
public List<CdReport> getCdReportList() {
	 Session session=factory.getSession();
		@SuppressWarnings("unchecked")
		
		List<CdReport> CdReportList=session.createCriteria(CdReport.class).list();	
		return CdReportList;
}

@Transactional
public void updateCdReport(CdReport report) {
Session session=factory.getSession();
session.update(report);
}

@Transactional 
public List<CdReport> getCDAllreport() {
	Session session=factory.getSession();
	@SuppressWarnings("unchecked")
	List<CdReport> reportList=session.createCriteria(CdReport.class).list();	
	return reportList;
}

@Transactional
public CdReport getId(int id) {
	Session session=factory.getSession();
	CdReport user=(CdReport) session.get(CdReport.class,id);
	return user;
}

@Override
public void deleteCDReport(Integer Id) {
	CdReport deletePEreport=(CdReport)factory.getSession().load(CdReport.class, Id);
	if(null !=deletePEreport) {
		this.factory.getSession().delete(deletePEreport);
		
	}
	
}

@Transactional
public CdReport getMonthlyReportByMonthYearDistrict(Date date) {
	System.out.println("inside get" + date);
	Session session = factory.getSession();
	CdReport mr = (CdReport) session.createCriteria(CdReport.class)
			.createAlias("districtMaster", "dis").add(Restrictions.eq("date", date))
			.add(Restrictions.eq("date", date));

	return mr;
}

@Override
@Transactional
public CdReport getReportByMonthYearDistrict(int m, int y, int did) {
	// TODO Auto-generated method stub
	Session session=factory.getSession();
	CdReport attendance=(CdReport) session.createCriteria(CdReport.class)
			.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m))
			.add(Restrictions.eq("year", y)).add(Restrictions.eq("dis.districtId", did)).uniqueResult();

	return attendance;
}

@Transactional
@Override
public CdReport getMonthlyReportAll(int year, int districtId, int month) {
	System.out.println("inside updatall get" + month + " " + year + " " + districtId);
	Session session = factory.getSession();
	CdReport mr = (CdReport) session.createCriteria(CdReport.class)
			.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
			.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

	return mr;
}

}
