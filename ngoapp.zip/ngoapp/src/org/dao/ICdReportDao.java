package org.dao;

import java.util.Date;
import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.MonthlyReport;
import org.dto.PEreport;
import org.dto.UserMaster;

public interface ICdReportDao {

void saveCdReport(CdReport cdreport);
	
List<CdReport> getCDAllreport();
	List<CdReport> getCdReportList();
	
	void updateCdReport(CdReport report);
	
	CdReport getId(int id);
	
	public void deleteCDReport(Integer Id);
	
	CdReport getMonthlyReportByMonthYearDistrict(Date date);
	
	CdReport getReportByMonthYearDistrict(int m, int y, int did);
	
	CdReport getMonthlyReportAll(int year, int districtId, int month);
}
