package org.dao;

import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.DistrictAdmin;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.util.HibernateSessionFactory;

// Attendace DAO
public interface IAttendanceDao {

void saveattendance(AttendanceMaster attendance);

List<AttendanceMaster> getAttendanceList();

List<AttendanceMaster> getattendanceAllreport();

AttendanceMaster getattendanceByMonthYearDistrict(int year);


void updatePEreport(AttendanceMaster attendance);

AttendanceMaster geteditReportById(Long id);

AttendanceMaster getReportById(int id);

void deleteAttendanceReport(Integer attendanceId);

AttendanceMaster getReportByMonthYearDistrict(int m, int y, int did);

AttendanceMaster getAttendancereportAll(int y, int did, int m);

//AttendanceMaster getValue(float percentage);
	
}