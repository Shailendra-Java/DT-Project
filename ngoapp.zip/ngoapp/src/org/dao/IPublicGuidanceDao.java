package org.dao;

import java.util.List;

import org.dto.PublicGuidance;

public interface IPublicGuidanceDao {

	public void savePublicguidance(PublicGuidance publicguid);

	List<PublicGuidance> getPublicguidanceAllreport();
	// public void delete(Integer pgId);

	PublicGuidance geteditReportById(int pgId);

	/* PublicGuidance geteditReportById1(int pgId); */

	public PublicGuidance updatepublicguidancereport(PublicGuidance updatepublicguidancereport);

	List<PublicGuidance> getPublicGuidanceList();

	public void deletePGReport(Integer pgId);

	PublicGuidance getId(Integer pgId);

	public PublicGuidance getReportByMonthYearDistrict(int m, int y, int did);

	public PublicGuidance getReportByMonthYearDistrictpgid(int y, int m, int did);

}
