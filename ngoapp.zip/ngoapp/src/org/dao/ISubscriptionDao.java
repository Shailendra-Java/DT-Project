package org.dao;

import java.util.List;

import org.dto.SubscriptionMaster;

public interface ISubscriptionDao {

	void savesubscription(SubscriptionMaster subscribe);

	List<SubscriptionMaster> getSubscriptionList();

	List<SubscriptionMaster> getAllSubscription();

	SubscriptionMaster getSubscriptionById(long id);

	void updateSubscription(SubscriptionMaster subscription);

	void deleteSubscription(long subId);

	SubscriptionMaster getMonthlyReportByMonthYearDistrict(int year, int month, int did);

}