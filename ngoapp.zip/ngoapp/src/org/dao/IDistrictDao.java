package org.dao;

import java.util.List;
import org.dto.DistrictAdmin;
import org.dto.DistrictMaster;
import org.dto.MonthlyReport;

public interface IDistrictDao {

	void saveDistrict(DistrictAdmin district);

	void saveMonthlyReport(MonthlyReport monthlyReport);

	List<MonthlyReport> getMonthlyReportList();

	List<DistrictAdmin> getDistrictList();

	void updateDistrict(DistrictAdmin district);

	void updateMonthlyReport(MonthlyReport monthlyReport);

	DistrictAdmin getDistrictById(int id);

	DistrictMaster getdistrict(int i);

	List<DistrictMaster> getDistrictMasterList();

	MonthlyReport getMonthlyReportById(long id);

	MonthlyReport getMonthlyReportByMonthYearDistrict(int month, int year, int districtId);

	boolean saveDistrict(DistrictMaster district);

	boolean getDistrictname(String districtName);

	List<DistrictMaster> getdistrictList();

	DistrictMaster getDistrictnameById(int id);

	List<MonthlyReport> getMonthlyreportAll(int year, String dirstictName);

	MonthlyReport getmonthlyreportAll(long id);

	List<MonthlyReport> getMRAllreport();

	MonthlyReport getMonthlyReportById(int year, String dirstictName, int month);

	void deleteReport(long id);

	List<MonthlyReport> viewMonthlyReport();

	MonthlyReport getMonthlyReportAll(int year, int districtId, int month);

	MonthlyReport getMonthchartReport();

	List<MonthlyReport> getDistrictname();

	MonthlyReport getMonthlyReportAll(String date1, int did);

	MonthlyReport getMonthlyReportBydateDistrict(String cdate, int did);

	MonthlyReport getMonthlyReportBydateDistrict(int districtId);

	MonthlyReport getMonthlyReportByMonthYearDistrict(int year, int month);

	List<DistrictMaster> getDistrictMasterList(String districtId);

	List<MonthlyReport> getByDistrictId(int districtId);

}