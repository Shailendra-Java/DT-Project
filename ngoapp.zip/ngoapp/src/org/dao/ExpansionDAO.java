package org.dao;

import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.Expansion;

public interface ExpansionDAO {
	public void saveExpansion(Expansion expansion);
	public void update(Expansion expansion);
	public void delete(Integer expId);
	//public void update(Expansion expansion);
	Expansion getExpansionById(Integer expId);
	List<Expansion> getAllExpansion();
	public void deleteEXReport(Integer expId);
	Expansion getReportByMonthYearDistrict(int m, int y, int did);
	Expansion getMonthlyReportAll(int year, int districtId, int month);
	}