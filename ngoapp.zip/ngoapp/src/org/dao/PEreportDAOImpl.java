package org.dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

import org.dto.CdReport;
import org.dto.PEreport;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
	public class PEreportDAOImpl implements PEreportDAO{
	private static final Logger logger = LoggerFactory.getLogger(PEreportDAOImpl.class);
	
	@Autowired
	private HibernateSessionFactory  factory;


	@Override
	@Transactional 
	public void saveReport(PEreport pereport) {
		Session session=factory.getSession();
		session.save(pereport);
		logger.info("saveReport in PEreportDAOImpl="+pereport);
		
	}
	
	@Transactional 
	public List<PEreport> getPEAllreport() {
		Session session=factory.getSession();
		@SuppressWarnings("unchecked")
		List<PEreport> reportList=session.createCriteria(PEreport.class).list();	
		return reportList;
	}

	@Transactional
	public PEreport getReportById(Integer peId) {
		Session session=factory.getSession();
		PEreport editPEreport=(PEreport) session.get(PEreport.class,peId);
		return editPEreport;
	}
	
	@Transactional
	public void updatePEreport(PEreport pereport) {
		 Session session=factory.getSession();
		 session.update(pereport);
	}

	@Override
	public void deletePEReport(Integer peId) {
		PEreport deletePEreport=(PEreport)factory.getSession().load(PEreport.class, peId);
		if(null !=deletePEreport) {
			this.factory.getSession().delete(deletePEreport);
			
		}
		
		
		
	}

	@Override
	public PEreport getReportByMonthYearDistrict(int m, int y, int did) {
		Session session=factory.getSession();
		PEreport attendance=(PEreport) session.createCriteria(PEreport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m))
				.add(Restrictions.eq("year", y)).add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return attendance;
	}
	
	@Transactional
	@Override
	public PEreport getMonthlyReportAll(int year, int districtId, int month) {
		System.out.println("inside updatall get" + month + " " + year + " " + districtId);
		Session session = factory.getSession();
		PEreport mr = (PEreport) session.createCriteria(PEreport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

		return mr;
	}
}
