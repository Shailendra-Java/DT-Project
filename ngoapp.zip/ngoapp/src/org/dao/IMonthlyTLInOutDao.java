package org.dao;

import java.util.Date;
import java.util.List;

import org.dto.MonthlyTLIN;
import org.dto.PublicGuidance;

public interface IMonthlyTLInOutDao {

	void saveMonthlyTLIN(MonthlyTLIN monthlyTLIN);

	List<MonthlyTLIN> getMonthlyTLINList(String typeofTL);

	MonthlyTLIN getByMtlId(long mtlId);

	void updateTLInOutDismiss(MonthlyTLIN monthlyTLIN);

	List<MonthlyTLIN> getMonthlyTLINList();

	public void deleteTLInOut(long mtlId);
	
	public MonthlyTLIN getReportByMonthYearDistrict(int year, int month, int did);
	
	MonthlyTLIN getMonthlyReportAll(int year, int districtId, int month);
	
	public List<MonthlyTLIN> getTLAllreport();
	
	MonthlyTLIN getMonthchartTLIN();

	/*List<MonthlyTLIN> getMonthlyTLINListByMonth();*/

	/*List<MonthlyTLIN> getMonthlyTLINListByMonth(int month);*/

	List<MonthlyTLIN> getMonthlyTLINListByMonth(int month, int districtId);

	
	

}
