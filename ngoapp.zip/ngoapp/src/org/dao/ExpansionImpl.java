package org.dao;

import java.util.List;

import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.Expansion;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
public class ExpansionImpl implements ExpansionDAO{
	private static final Logger logger = LoggerFactory.getLogger(PEreportDAOImpl.class);

	@Autowired
	private HibernateSessionFactory factory;
	
	@Override
	@Transactional 
	public void saveExpansion(Expansion expansion) {
		Session session =factory.getSession();
		session.save(expansion);
		
	}

	@Override
	@Transactional 
	public void update(Expansion expansion) {
		 Session session=factory.getSession();
		 session.update(expansion);
		 logger.info("Inside the PEreportDAOImpl!!!!!expId="+expansion.getExpId());
		
	}

	@Override
	@Transactional 
	public void delete(Integer expId) {
		
	}

	@Override
	@Transactional 
	public List<Expansion> getAllExpansion() {
		Session session=factory.getSession();
		@SuppressWarnings("unchecked")
		List<Expansion> expansion= session.createCriteria(Expansion.class).list();
		return expansion;
	}

	@Override
	public Expansion getExpansionById(Integer expId) {
		
		Session session=factory.getSession();
		Expansion getBuId=(Expansion) session.get(Expansion.class,expId);
		return getBuId;
	}
	
	@Override
	public void deleteEXReport(Integer expId) {
		Expansion deletePEreport=(Expansion)factory.getSession().load(Expansion.class, expId);
		if(null !=deletePEreport) {
			this.factory.getSession().delete(deletePEreport);
			
		}
		
	}
	
	@Override
	@Transactional
	public Expansion getReportByMonthYearDistrict(int m, int y, int did) {
		// TODO Auto-generated method stub
		Session session=factory.getSession();
		Expansion attendance=(Expansion) session.createCriteria(Expansion.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", m))
				.add(Restrictions.eq("year", y)).add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return attendance;
	}
	
	@Transactional
	@Override
	public Expansion getMonthlyReportAll(int year, int districtId, int month) {
		System.out.println("inside updatall get" + month + " " + year + " " + districtId);
		Session session = factory.getSession();
		Expansion mr = (Expansion) session.createCriteria(Expansion.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

		return mr;
	}

}