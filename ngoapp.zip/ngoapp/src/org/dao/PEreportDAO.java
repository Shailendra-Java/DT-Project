package org.dao;

import java.util.List;

import org.dto.CdReport;
import org.dto.PEreport;

public interface PEreportDAO {
	
	void saveReport(PEreport pereport);
	List<PEreport> getPEAllreport();
	void updatePEreport(PEreport pereport);
	PEreport getReportById(Integer peId);
	public void deletePEReport(Integer peId);
	PEreport getReportByMonthYearDistrict(int m, int y, int did);
	PEreport getMonthlyReportAll(int year, int districtId, int month);
}
