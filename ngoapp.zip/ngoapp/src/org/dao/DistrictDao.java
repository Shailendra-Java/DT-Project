package org.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.dto.DistrictAdmin;
import org.dto.DistrictMaster;
import org.dto.MonthlyReport;
import org.hibernate.Criteria;
import org.hibernate.Session;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
public class DistrictDao implements IDistrictDao {

	@Autowired
	private HibernateSessionFactory factory;

	@Override
	@Transactional
	public void saveDistrict(DistrictAdmin district) {
		Session session = factory.getSession();

		session.save(district);
	}

	@Override
	@Transactional
	public List<DistrictAdmin> getDistrictList() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<DistrictAdmin> district = session.createCriteria(DistrictAdmin.class).list();
		return district;
	}

	@Override
	@Transactional
	public DistrictAdmin getDistrictById(int id) {

		Session session = factory.getSession();

		DistrictAdmin district = (DistrictAdmin) session.get(DistrictAdmin.class, id);

		return district;
	}

	@Override
	@Transactional
	public void updateMonthlyReport(MonthlyReport monthlyReport) {
		Session session = factory.getSession();
		session.update(monthlyReport);
	}

	@Override
	@Transactional
	public DistrictMaster getdistrict(int i) {

		Session session = factory.getSession();
		DistrictMaster districtMaster = (DistrictMaster) session.get(DistrictMaster.class, i);

		return districtMaster;
	}

	@Override
	@Transactional
	public List<DistrictMaster> getDistrictMasterList() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<DistrictMaster> district = session.createCriteria(DistrictMaster.class).list();
		return district;
	}

	@Override
	@Transactional
	public void saveMonthlyReport(MonthlyReport monthlyReport) {

		Session session = factory.getSession();

		session.save(monthlyReport);

	}

	@Override
	@Transactional
	public List<MonthlyReport> getMonthlyReportList() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")

		List<MonthlyReport> district = session.createCriteria(MonthlyReport.class).list();
		return district;
	}

	@Override
	@Transactional
	public void updateDistrict(DistrictAdmin district) {
		Session session = factory.getSession();
		session.update(district);

	}

	@Override
	@Transactional
	public MonthlyReport getMonthlyReportByMonthYearDistrict(int month, int year, int districtId) {
		System.out.println("inside get" + year + " " + month + " " + districtId);
		Session session = factory.getSession();
		MonthlyReport mr = (MonthlyReport) session.createCriteria(MonthlyReport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

		return mr;
	}

	@Override
	@Transactional
	public MonthlyReport getMonthlyReportById(long mrId) {

		Session session = factory.getSession();
		MonthlyReport district = (MonthlyReport) session.get(MonthlyReport.class, mrId);
		return district;
	}

	@Override
	@Transactional
	public boolean saveDistrict(DistrictMaster district) {

		Session session = factory.getSession();
		Criteria criteria = session.createCriteria(DistrictMaster.class);
		Criterion districtname = Restrictions.eq("districtName", district.getDistrictName());
		criteria.add(districtname);
		@SuppressWarnings("unchecked")
		List<DistrictMaster> list = criteria.list();
		if (list.size() == 0) {
			session.save(district);
			return false;
		} else {
			return true;
		}

	}

	@Override
	@Transactional
	public boolean getDistrictname(String districtName) {

		Session session = factory.getSession();
		Criteria criteria = session.createCriteria(DistrictMaster.class);
		Criterion username = Restrictions.eq("districtName", districtName);
		criteria.add(username);
		@SuppressWarnings("unchecked")
		List<DistrictMaster> list = criteria.list();
		if (list.size() == 0) {

			return true;
		} else {
			return false;
		}
	}

	@Override
	@Transactional
	public List<DistrictMaster> getdistrictList() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<DistrictMaster> district = session.createCriteria(DistrictMaster.class).list();
		return district;

	}

	@Override
	@Transactional
	public DistrictMaster getDistrictnameById(int id) {

		Session session = factory.getSession();

		DistrictMaster district = (DistrictMaster) session.get(DistrictMaster.class, id);

		return district;
	}

	@Override
	@SuppressWarnings("unused")
	@Transactional
	public List<MonthlyReport> getMonthlyreportAll(int year, String districtName) {
		System.out.println("inside get" + " " + year + " " + districtName);
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<MonthlyReport> list = session.createCriteria(MonthlyReport.class).createAlias("districtMaster", "dis")
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtName", districtName)).list();
		return null;
	}

	@Transactional
	@Override
	public MonthlyReport getmonthlyreportAll(long id) {
		System.out.println("inside get" + " " + id);
		Session session = factory.getSession();
		MonthlyReport report = (MonthlyReport) session.get(MonthlyReport.class, id);

		return report;
	}

	@Transactional
	@SuppressWarnings("unchecked")
	@Override
	public List<MonthlyReport> getMRAllreport() {
		System.out.println("inside get MRAll Report");
		Session session = factory.getSession();
		List<MonthlyReport> list = session.createCriteria(MonthlyReport.class).addOrder(Order.asc("month"))

				.list();

		return list;
	}

	@Transactional
	@Override
	public MonthlyReport getMonthlyReportAll(int year, int districtId, int month) {
		System.out.println("inside updatall get" + month + " " + year + " " + districtId);
		Session session = factory.getSession();
		MonthlyReport mr = (MonthlyReport) session.createCriteria(MonthlyReport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

		return mr;
	}

	@Transactional
	@Override
	public void deleteReport(long id) {

		Session session = factory.getSession();
		MonthlyReport deleteReport = (MonthlyReport) session.load(MonthlyReport.class, new Long(id));
		if (null != deleteReport) {
			session.delete(deleteReport);
		}
		System.out.println("Person deleted successfully, person details=" + deleteReport);
	}

	@Transactional
	@Override
	public List<MonthlyReport> viewMonthlyReport() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<MonthlyReport> viewList = session.createCriteria(MonthlyReport.class).list();
		System.out.println("hiiiiiiii DAO");
		return viewList;
	}

	@Override
	public MonthlyReport getMonthlyReportById(int year, String dirstictName, int month) {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional
	@Override
	public MonthlyReport getMonthchartReport() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		MonthlyReport viewList = (MonthlyReport) session.createCriteria(MonthlyReport.class).list();
		System.out.println("hiiiiiiii DAO");
		return viewList;
	}

	@Override
	@Transactional
	public List<MonthlyReport> getDistrictname() {
		Session session = factory.getSession();
		List<MonthlyReport> viewList = session.createCriteria(MonthlyReport.class).list();
		System.out.println("hiiiiiiii DAO");
		return viewList;
	}

	@Override
	@Transactional
	public MonthlyReport getMonthlyReportAll(String date1, int did) {
		System.out.println("inside get date1" + date1 + " " + did);
		Session session = factory.getSession();
		Date startDate = null;
		try {
			startDate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(date1).getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MonthlyReport mr = (MonthlyReport) session.createCriteria(MonthlyReport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("created_Date", startDate))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();
		System.out.println("inside get" + mr.getCreated_Date());
		return mr;
	}

	@Override
	@Transactional
	public MonthlyReport getMonthlyReportBydateDistrict(String cdate, int did) {
		System.out.println("inside get cdate" + cdate + " " + did);
		Session session = factory.getSession();
		Date startDate = null;
		try {
			startDate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(cdate).getTime());
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		MonthlyReport datedistr = (MonthlyReport) session.createCriteria(MonthlyReport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("created_Date", startDate))
				.add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return datedistr;
	}

	@Override
	@Transactional
	public MonthlyReport getMonthlyReportBydateDistrict(int districtId) {
		System.out.println("inside updatall get" +  districtId);
		Session session = factory.getSession();
		MonthlyReport mr = (MonthlyReport) session.createCriteria(MonthlyReport.class)
				.createAlias("districtMaster", "dis")
				.add(Restrictions.eq("dis.districtId", districtId)).uniqueResult();

		return mr;
	}

	@Override
	@Transactional
	public MonthlyReport getMonthlyReportByMonthYearDistrict(int year, int month) {
		
		
			System.out.println("inside get" + year + " " + month);
			Session session = factory.getSession();
			MonthlyReport mr = (MonthlyReport) session.createCriteria(MonthlyReport.class)
					.add(Restrictions.eq("month", month))
					.add(Restrictions.eq("year", year)).uniqueResult();

			return mr;
		

	}


	@Override
	@Transactional
	public List<DistrictMaster> getDistrictMasterList(String districtId) {
		System.out.println("inside districtId" + districtId );
		Session session = factory.getSession();
		List<DistrictMaster> mr = (List<DistrictMaster>) session.createCriteria(DistrictMaster.class).add(Restrictions.eq("districtName", districtId)).list();
		System.out.println("inside districtId" + mr );
		return mr;
	
	}

	@Override
	@Transactional
	public List<MonthlyReport> getByDistrictId(int districtId) {
		System.out.println("inside updatall get" +  districtId);
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<MonthlyReport> mr =  (List<MonthlyReport>)session.createCriteria(MonthlyReport.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("dis.districtId", districtId)).list();

		return mr;
	}

}
