package org.dao;

import java.util.List;

import org.dto.SubscriptionMaster;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.util.HibernateSessionFactory;

@Repository
public class SubscriptionDao implements ISubscriptionDao {

	@Autowired
	private HibernateSessionFactory factory;

	@Transactional
	@Override
	public void savesubscription(SubscriptionMaster subscribe) {
		Session session = factory.getSession();
		session.save(subscribe);
	}

	@Transactional
	@Override
	public List<SubscriptionMaster> getSubscriptionList() {
		System.out.println("inside DAO");
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<SubscriptionMaster> subscriptionlist = session.createCriteria(SubscriptionMaster.class).list();

		return subscriptionlist;
	}

	@Transactional
	@Override
	public List<SubscriptionMaster> getAllSubscription() {
		Session session = factory.getSession();
		@SuppressWarnings("unchecked")
		List<SubscriptionMaster> subList = session.createCriteria(SubscriptionMaster.class).list();
		System.out.println("hiiiiiiii DAO");
		return subList;
	}

	@Transactional
	@Override
	public SubscriptionMaster getSubscriptionById(long id) {
		System.out.println("hello DAO");
		Session session = factory.getSession();
		SubscriptionMaster editSubscription = (SubscriptionMaster) session.get(SubscriptionMaster.class, id);
		return editSubscription;
	}

	@Transactional
	@Override
	public void updateSubscription(SubscriptionMaster subscription) {
		Session session = factory.getSession();
		session.update(subscription);

	}

	@Transactional
	@Override
	public void deleteSubscription(long subId) {
		SubscriptionMaster deleteSubscription = (SubscriptionMaster) factory.getSession().load(SubscriptionMaster.class,
				subId);
		if (null != deleteSubscription) {

			this.factory.getSession().delete(deleteSubscription);

		}

	}

	@Transactional
	@Override
	public SubscriptionMaster getMonthlyReportByMonthYearDistrict(int year, int month, int did) {
		System.out.println("inside get" + month + " " + year + " " + did);
		Session session = factory.getSession();
		SubscriptionMaster subscription = (SubscriptionMaster) session.createCriteria(SubscriptionMaster.class)
				.createAlias("districtMaster", "dis").add(Restrictions.eq("month", month))
				.add(Restrictions.eq("year", year)).add(Restrictions.eq("dis.districtId", did)).uniqueResult();

		return subscription;
	}
}