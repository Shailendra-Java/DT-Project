package org.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dto.AttendanceMaster;
import org.dto.CdReport;
import org.dto.DistrictMaster;
import org.dto.MonthlyReport;
import org.dto.PEreport;
import org.dto.UserMaster;
import org.service.CdReportService;
import org.service.ICdReportService;
import org.service.IDistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.util.PasswordHasher;

@Controller
public class CDReportController {
	private static final Logger logger = LoggerFactory.getLogger(CDReportController.class);
	
	@Autowired
	ICdReportService iCdReport;
	
	/*@Autowired
	CdReportService cdReportService;*/
    
    @Autowired
	IDistrictService iDistrictService;
    
    @InitBinder
	 public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
	     final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
	     binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));    
	 }
    
	 @RequestMapping(value ="cdreport")
		public  String CreateCDReport(Model model)
		{
		 
		 CdReport cdr= new CdReport();
		 model.addAttribute("district", cdr);
		  //model.addAttribute("cdr", cdr);
		  model.addAttribute("cdreport2",cdr);
		  
		   List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		   model.addAttribute("districtMaster", districtMaster);	

		   return "cdreport";
	   }
	 
	 @RequestMapping(value = "checkmonth1", method = RequestMethod.POST)
		@ResponseBody
		public String Checkmonth(@RequestParam Date createdDate)
		{
			boolean error = false;
			System.out.println("checkmonth");
			//String[] arrOfStr = month.split("/");

			/*int m = Integer.valueOf(arrOfStr[0]);
			int y = Integer.valueOf(arrOfStr[1]);
			int did = Integer.valueOf(arrOfStr[2]);*/

			System.out.println("check did" + createdDate);

			CdReport mr = iCdReport.getMonthlyReportByMonthYearDistrict(createdDate);
			System.out.println(mr);

			if (mr != null) {
				System.out.println("Report is already present for this month");

				List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

				error = true;

			}

			System.out.println("check2");

			return "" + error;
		}

	 @RequestMapping(value="deleteCDreport")
		public ModelAndView deleteEmployee(HttpServletRequest request) {
			
		    int pereportID = Integer.parseInt(request.getParameter("id"));
		    iCdReport.deleteCDReport(pereportID);
		    return new ModelAndView("redirect:cdreportlist");
		}
	 
	/* @RequestMapping(value ="cdreport")
		public String cdreportForm(Model model) {
			
			CdReport cdr= new CdReport();
			model.addAttribute("cdreport2",cdr);
			List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
			model.addAttribute("districtMaster", districtMaster);
			return "redirect:cdreportlist";
		}*/
	 
	/* @RequestMapping(value="saveCdReport")
		public String saveCdReport(@ModelAttribute CdReport cdreport,final BindingResult result,Model model,@ModelAttribute("cdreport2") @Validated CdReport report) {
		
		
			 CdReport cdr= new CdReport();
			if(result.hasErrors()){
				return "redirect:cdreport";
			}
			System.out.println("check it ");
			 model.addAttribute("cdreport2",cdr);
			iCdReport.saveCdReport(cdreport);
			 Date createdDate=cdreport.getCreatedDate();
			 Integer DistrictId = cdreport.getDistrictMaster().getDistrictId();
			 if(!iCdReport.isReportExistForSelectedMonthAndYear(createdDate,DistrictId)) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(createdDate);
				int month = cal.get(Calendar.MONTH) + 1;
				int day = cal.get(Calendar.DATE);
				int year = cal.get(Calendar.YEAR);
				cdreport.setDate(day);
				cdreport.setMonth(month);
				cdreport.setYear(year);
				iCdReport.saveCdReport(cdreport);
				//return "redirect:cdreportlist";
			}else {
				logger.info("Record Exists for Selected Month");
			}
			        
			 return "redirect:cdreportlist";
			
		}*/
	 
	 @RequestMapping(value="saveCdReport")
		public String saveCdReport(@ModelAttribute CdReport report,final BindingResult result,Model model,@ModelAttribute("cdreport2") @Validated CdReport pereport){
			
			Date createdDate=report.getCreatedDate();
			Integer districtId=report.getDistrictMaster().getDistrictId();
			System.out.println("districtName::"+districtId);
			if(!iCdReport.isReportExistForSelectedMonthAndYear(createdDate,districtId)) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(createdDate);
				int month = cal.get(Calendar.MONTH) + 1;
				int day = cal.get(Calendar.DATE);
				int year = cal.get(Calendar.YEAR);
				report.setDate(day);
				report.setMonth(month);
				report.setYear(year);
				report.getMonth();
				iCdReport.saveCdReport(report);
				return "redirect:cdreportlist";
			}else {
				logger.info("Record Exists for Selected Month");
				JOptionPane.showMessageDialog(null, "Record Exists for Selected Month");
			}
			return "redirect:cdreport";
		}
	 
	/*	@RequestMapping(value="cdreportlist")
		public String cdReportList(Model model)
		{
	        List<CdReport> cdreport=iCdReport.getCdReportList();
			model.addAttribute("cdreport", cdreport);
			return "cdreportlist"; }*/
		
		
		   @RequestMapping(value="updateCdReport")
			public String updateCdReport(@ModelAttribute CdReport report, final BindingResult result, HttpServletRequest request)
			{
			   
			   Date createdDate=report.getCreatedDate();
				Calendar cal = Calendar.getInstance();
				cal.setTime(createdDate);
				int month = cal.get(Calendar.MONTH) + 1;
				int day = cal.get(Calendar.DATE);
				int year = cal.get(Calendar.YEAR);
				report.setDate(day);
				report.setMonth(month);
				report.setYear(year);
				//System.out.println("date::"+day+"Month:::"+month+"year::"+year);
				iCdReport.updateCdReport(report);
				//return "redirect:pe_report";
				
			     
				return "redirect:cdreportlist";
			}
		   
			@RequestMapping(value="cdreportedit")
			public String editCdReport(@RequestParam int id, Model model,HttpServletRequest request){
			/*	CdReport user2= new CdReport();
				
				String ProgramType = request.getParameter("pass"+user2.getProgramType());
				System.out.println("passworduser"+ProgramType);
				
				CdReport cdreportedit=iCdReport.getId(id);
		         model.addAttribute("cdreportedit",cdreportedit);
				
				return "cdreportedit";*/
				CdReport report= new CdReport();
				CdReport editCdreport= iCdReport.getId(id);
				model.addAttribute("cdreportedit",editCdreport);
				return "cdreportedit";
			}
			
			

			@RequestMapping(value="cdreportlist")
			public String cdreport(Model model,@ModelAttribute CdReport filteredYear,HttpServletRequest request){
				
				List<CdReport> cdreportList=iCdReport.getCDAllreport();
				CdReport year=new CdReport();
				CdReport finalmonth= new CdReport();
				model.addAttribute("cdreportList", cdreportList);
				model.addAttribute("year", year);
			
				Integer fiYear=filteredYear.getYear();
				Integer currentMonth=filteredYear.getMonth();
				
				HttpSession session=request.getSession();
				session.setAttribute("fiYear", fiYear);
				//session.setAttribute("currentMonth", currentMonth);
				session.setAttribute("currentMonthToDisplay",String.valueOf(currentMonth));
				Calendar cal = Calendar.getInstance();
				cal.setTime(new Date());
				int month = cal.get(Calendar.MONTH) + 1;
				int day = cal.get(Calendar.DATE);
				int yearf = cal.get(Calendar.YEAR);
				if(null== currentMonth) {
					//First Time value
					currentMonth = month;
				}
				session.setAttribute("currentMonth", currentMonth);
				List<CdReport> filteredYearReports = new ArrayList<CdReport>();
				List<CdReport> filtereMOnthsReports = new ArrayList<CdReport>();
				Map<Integer, Integer> filteredYearAndMonth= new HashMap<Integer, Integer>();
				if(fiYear == null ) {
					fiYear = yearf;
					
				}
				if(currentMonth == null ) {
					currentMonth = month;
					
				}
				
				List<Integer> availableYears = new ArrayList<Integer>();
				List<Integer> availableMOnths = new ArrayList<Integer>();
				
				for(CdReport reportYr: cdreportList) {
					if(!availableYears.contains(reportYr.getYear()) ) {
						availableYears.add(reportYr.getYear());
					}
					if(!availableMOnths.contains(reportYr.getMonth()) ) {
						availableMOnths.add(reportYr.getMonth());
					}
				if(reportYr.getYear().intValue()==fiYear && reportYr.getMonth().intValue()==currentMonth) {
						filteredYearReports.add(reportYr);
						
					}
					else {
						System.out.println("else :::");
					}
				if(null != filteredYearReports && !filteredYearReports.isEmpty()) {
					CdReport preport = filteredYearReports.get(0);
					if(null != preport.getDistrictMaster()) {
					  String distName = preport.getDistrictMaster().getDistrictName();
					  int distId = preport.getDistrictMaster().getDistrictId();
					  request.getSession().setAttribute("distName", distName);
					  request.getSession().setAttribute("distId", distId);			  
					}
				}
				availableYears = getAllAvailableYears(availableYears,yearf);
				model.addAttribute("cdreportList", filteredYearReports);
				model.addAttribute("availableYears", availableYears);
				//model.addAttribute("availableMOnths", availableMOnths);
				model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));

				}
				return "cdreportlist";
			}
			
			private List<Integer> getAvailableMonths(List<Integer> availableMOnths){
				
				if(null != availableMOnths) {
					if(!availableMOnths.contains(1)) {
						availableMOnths.add(1);
					}
					if(!availableMOnths.contains(2)) {
						availableMOnths.add(2);
					}
					if(!availableMOnths.contains(3)) {
						availableMOnths.add(3);
					}
					if(!availableMOnths.contains(4)) {
						availableMOnths.add(4);
					}
					if(!availableMOnths.contains(5)) {
						availableMOnths.add(5);
					}
					if(!availableMOnths.contains(6)) {
						availableMOnths.add(6);
					}
					if(!availableMOnths.contains(7)) {
						availableMOnths.add(7);
					}
					if(!availableMOnths.contains(8)) {
						availableMOnths.add(8);
					}
					if(!availableMOnths.contains(9)) {
						availableMOnths.add(9);
					}
					if(!availableMOnths.contains(10)) {
						availableMOnths.add(10);
					}
					if(!availableMOnths.contains(11)) {
						availableMOnths.add(11);
					}			
					if(!availableMOnths.contains(12)) {
						availableMOnths.add(12);
					}
				}
				return availableMOnths;
			}

			
			  private List<Integer> getAllAvailableYears(List<Integer> availableYears,int yearf){
			    	if(availableYears.size() < 10) {
			    		for(int i= availableYears.size() ; i<10;i++) {
			    			if(!availableYears.contains(yearf)) {
			    			   availableYears.add(yearf);    			  
			    			}
			    			yearf --;
			    		}
			    	}
			    	return availableYears;
			    }
			
			@RequestMapping(value="districtCDreport")
			public String district(Model model) {
				
				CdReport districtPEreport= new CdReport();
				model.addAttribute("districtPEreport", districtPEreport);
				return "cdreportlist";
			}
			
			@RequestMapping(value="monthlyCDreport")
			public String monthlyCDreport(Model model,@ModelAttribute CdReport filteredYear,HttpServletRequest request,@RequestParam int id) {
				//request.
				CdReport selectedReport = iCdReport.getId(id);
				List<CdReport> monthlyCDreport = iCdReport.getCDAllreport();
				CdReport monthlyCDreport1= monthlyCDreport.get(0);
				Integer year=filteredYear.getYear();
				HttpSession session=request.getSession();
				session.setAttribute("year", year);
				String distriName=selectedReport.getDistrictMaster().getDistrictName();
				session.setAttribute("distriName", distriName);
				session.setAttribute("year", year);
				model.addAttribute("monthlyCDreport", monthlyCDreport);
				model.addAttribute("monthlyCDreport1", monthlyCDreport1);
				List<CdReport>  filteredReport = new ArrayList<CdReport>();
				int selectedYear = 0 ;
				int selectedDistrict = 0 ;
				if(null != selectedReport) {
					selectedYear = selectedReport.getYear();
					selectedReport.getMonth();
					selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
				}
				if(null!= filteredYear && null != filteredYear.getYear()) {
					selectedYear =  filteredYear.getYear();
				}
				if(selectedYear<= 0) {
					if(null != request.getSession() && null != request.getSession().getAttribute("fiYear")) {
					  selectedYear = (Integer)request.getSession().getAttribute("fiYear");
					}
					
				}
				if(null !=filteredYear && null != filteredYear.getDistrictMaster() && filteredYear.getDistrictMaster().getDistrictId() > 0) {
					selectedDistrict =  filteredYear.getDistrictMaster().getDistrictId();
				}
				if(null != monthlyCDreport) {
					for(CdReport report:monthlyCDreport) {
						if(selectedYear == report.getYear()) {
						  if(selectedDistrict > 0) {
							  
							  if(null !=  report.getDistrictMaster() &&
									  selectedDistrict == report.getDistrictMaster().getDistrictId()) {
								  filteredReport.add(report);
							  }
						  }else {
							
							  if(null !=  report.getDistrictMaster()) {
								  selectedDistrict =  report.getDistrictMaster().getDistrictId();	
										filteredReport.add(report);
							  }
						  }
						
						}
					}
				}
				model.addAttribute("filteredReport",filteredReport);
				model.addAttribute("uniqueyears",getUniqueYear(monthlyCDreport));
				model.addAttribute("uniqueDistrictNames",getUniqueDistrictName(monthlyCDreport));
				return "monthlyCDreport";
			}
			
			@RequestMapping(value="monthlyCDreport_submit")
			public String monthlyCDreport_submit(Model model,@ModelAttribute CdReport filteredYear,HttpServletRequest request) {
				HttpSession session=request.getSession();
				String distriName=filteredYear.getDistrictMaster().getDistrictName();
				session.setAttribute("distriName", distriName);
				Integer selectedDistrict = 0 ;
				String districtName = "";
				if(null != filteredYear.getDistrictMaster()) {
				   selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
				   districtName = filteredYear.getDistrictMaster().getDistrictName();
				}
				Integer selectedYear=filteredYear.getYear();
				
				List<CdReport> monthlyPEreport = iCdReport.getCDAllreport();	
				CdReport monthlyCDreport1= monthlyPEreport.get(0);
				model.addAttribute("monthlyCDreport1", monthlyCDreport1);
				List<CdReport>  filteredReport = new ArrayList<CdReport>();		
				if(null != monthlyPEreport) {
					for(CdReport report:monthlyPEreport) {
						if(selectedYear.intValue() == report.getYear().intValue() ) {
							 if(null !=  report.getDistrictMaster() && 
									 districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
								 //&&  selectedDistrict == report.getDistrictMaster().getDistrictId()
								  filteredReport.add(report);
							  }
						}
					}
				}
				model.addAttribute("filteredReport",filteredReport);
				model.addAttribute("uniqueyears",getUniqueYear(monthlyPEreport));
				model.addAttribute("uniqueDistrictNames",getUniqueDistrictName(monthlyPEreport));
				return "monthlyCDreport";
			}
			
			/*@RequestMapping("updatemonthlyCDreport")
			public String updateMonthlyCDReport(@RequestParam int Id,@ModelAttribute CdReport updatePEreport, final BindingResult result, HttpServletRequest request){
				
				Date sectedDate=updatePEreport.getCreatedDate();
				CdReport editPereport= iCdReport.getId(Id);
				Integer disID=editPereport.getDistrictMaster().getDistrictId();
			
				if(!iCdReport.isReportExistForSelectedMonthAndYearEdit(sectedDate,disID,editPereport)) {
					Date createdDate=updatePEreport.getCreatedDate();
					Calendar cal = Calendar.getInstance();
					cal.setTime(createdDate);
					int month = cal.get(Calendar.MONTH) + 1;
					int day = cal.get(Calendar.DATE);
					int year = cal.get(Calendar.YEAR);
					updatePEreport.setDate(day);
					updatePEreport.setMonth(month);
					updatePEreport.setYear(year);
					
					iCdReport.updateCdReport(updatePEreport);
				}else {
					System.out.println("NOT UPDATED------------SUCCESS!!!------------");
				}
				return "redirect:cdreportlist";
			}*/
			
			@RequestMapping("updatemonthlyCDreport")
			public String updateMonthlyCDReport(@RequestParam int id,@ModelAttribute CdReport updatePEreport, final BindingResult result, HttpServletRequest request,Model model){
				
				Date sectedDate=updatePEreport.getCreatedDate();
				CdReport editPereport= iCdReport.getId(id);
				Integer disID=editPereport.getDistrictMaster().getDistrictId();
				System.out.println("inside the updateMonthly::"+sectedDate+"id::"+editPereport+"disID::"+disID);
				List<CdReport> monthlyPEreport = iCdReport.getCDAllreport();	
				CdReport monthlyCDreport1= monthlyPEreport.get(0);
				CdReport pereport= new CdReport();
				model.addAttribute("pereport", pereport);
				if(!iCdReport.isReportExistForSelectedMonthAndYearEdit(sectedDate,disID,editPereport)) {
					Date createdDate=updatePEreport.getCreatedDate();
					Calendar cal = Calendar.getInstance();
					cal.setTime(createdDate);
					int month = cal.get(Calendar.MONTH) + 1;
					int day = cal.get(Calendar.DATE);
					int year = cal.get(Calendar.YEAR);
					updatePEreport.setDate(day);
					updatePEreport.setMonth(month);
					updatePEreport.setYear(year);
					
					iCdReport.updateCdReport(updatePEreport);
				}else {
					System.out.println("NOT UPDATED------------SUCCESS!!!------------");
				}
				//return "redirect:pereport";
				return "redirect:cdreportlist";
			}
			
			@RequestMapping("/editMonthlyCDreport")
			public  String editMonthlyCDreport(Model model,@RequestParam int id) {
				
				CdReport pereport= new CdReport();
				CdReport editMonthlyReport=iCdReport.getId(id);
				//model.addAttribute("pereport", pereport);
				model.addAttribute("editMonthlyReport", editMonthlyReport);
				return "editMonthlyCDreport";
		}
			
			private List<String> getUniqueDistrictName(List<CdReport> monthlyCDreport){
				 List<String> districtName = new  ArrayList<String>();
				 if(null != monthlyCDreport) {
					 for(CdReport report:monthlyCDreport) {
						if(null != report.getDistrictMaster() && 
								!districtName.contains(report.getDistrictMaster().getDistrictName())) {
							districtName.add(report.getDistrictMaster().getDistrictName());
						}
					 }
				 }
				 return districtName;		 
			}
			
			private List<Integer> getUniqueYear(List<CdReport> monthlyCDreport){
				 List<Integer> years = new  ArrayList<Integer>();
				 if(null != monthlyCDreport) {
					 for(CdReport report:monthlyCDreport) {
						if(!years.contains(report.getYear())) {
							years.add(report.getYear());
						}
					 }
				 }
				 return years;		 
			}
			
			@RequestMapping(value = "ViewMonthReport1")
			public String ViewMonthReport(@RequestParam int id, Model model) {

				System.out.println("inside ViewMonthReport");
				System.out.println("id" + id);
				CdReport district1 = iCdReport.getId(id);
				System.out.println("district" + district1);
				model.addAttribute("district", district1);

				return "ViewMonthReport1";

			}	
			
			@RequestMapping(value = "CDReport_pdf", method = RequestMethod.GET)
			public ModelAndView downloadPdf(){
				List<CdReport> listattendance1=iCdReport.getCdReportList();
				
				return new ModelAndView("pdfViewcd","listattendance1",listattendance1);
			}

			@RequestMapping(value = "CDReport_excell", method = RequestMethod.GET)
			public ModelAndView downloadExcel() {
				List<CdReport> listattendance1=iCdReport.getCdReportList();
			    return new ModelAndView("excelViewcd","listattendance1",listattendance1);
			}
			
			@RequestMapping(value = "checkmonthattendance1",method=RequestMethod.POST)
			@ResponseBody
			public String dateCheck(@RequestParam String date){
				boolean error= false;
				System.out.println("inside checkDate method");
				String[] arrOfStr = date.split("/");
				 String date1 =String.valueOf(arrOfStr[0]);
				int did = Integer.valueOf(arrOfStr[1]);
				System.out.println(date1+""+did);
				String[] arrOfStr1 = date1.split("-");
				int y=Integer.valueOf(arrOfStr1[0]);
				int m=Integer.valueOf(arrOfStr1[1]);
				System.out.println("month"+m+"year"+y);
				
				CdReport att=iCdReport.getReportByMonthYearDistrict(m, y, did);
				System.out.println("hi" + att);
				
				if(att!=null){
					System.out.println("report present for this month");
					@SuppressWarnings("unused")
					List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

					error = true;
				}
				return "" + error;
				
			}
		
			/*@RequestMapping(value = "monthlyAllCDReportUpdate")
			public String getDistrictName(@ModelAttribute @Valid CdReport monthlyReport, final BindingResult result,
					@RequestParam String date, Model model)

			{
				System.out.println("test inside monthlyReportUpdate");

				System.out.println("checkmonth");
				String[] arrOfStr = date.split("/");
				
				
				   String date1 =String.valueOf(arrOfStr[0]);
				   String[] arrOfStr1 = date1.split("-");
				   int y =Integer.valueOf(arrOfStr1[0]);
				   int m =Integer.valueOf(arrOfStr1[1]);

					int did = Integer.valueOf(arrOfStr[1]);
					
					
					System.out.println("check did" + did);
					System.out.println("check did" + date1);
				System.out.println("check did" + did);
				CdReport list = iCdReport.getReportByMonthYearDistrict(m, y, did);

				System.out.println("test" + list);
				// model.put("monthlyReportAll", list);
				model.addAttribute("update", list);
				return "updatecdreport";

			}*/
		
	/*		@RequestMapping(value = "updateCDNewReport")
			public String updateDistrict(@ModelAttribute MonthlyReport district, final BindingResult result,
					@RequestParam("created_Date") String created_Date) throws ParseException {

				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date d = format.parse(created_Date.substring(0, created_Date.length() - 2));

				System.out.println("date-----" + d);

				Date date = new Date();
				district.setCreated_Date(d);
				district.setModified_Date(date);
				System.out.println("hi esquare");
				iDistrictService.updateMonthlyReport(district);

				return "redirect:cdreportlist";
			}
			@RequestMapping(value = "editdistrict")
			public String editDistrict(@RequestParam long id, Model model) {

				System.out.println("inside editMonthly");
				System.out.println("id" + id);
				MonthlyReport district = iDistrictService.getMonthlyReportById(id);
				System.out.println("district" + district);
				model.addAttribute("district", district);

				return "editdistrict";

			}*/

			@RequestMapping(value = "CDAllReportUpdate")
			public String getDistrictName(@ModelAttribute @Valid CdReport monthlyReport, final BindingResult result,
					@RequestParam String date, Model model)

			{
				System.out.println("test inside monthlyReportUpdate");

				System.out.println("checkmonth");
				String[] arrOfStr = date.split("/");
				
				
				   String date1 =String.valueOf(arrOfStr[0]);
				   String[] arrOfStr1 = date1.split("-");
				   int y =Integer.valueOf(arrOfStr1[0]);
				   int m =Integer.valueOf(arrOfStr1[1]);

					int did = Integer.valueOf(arrOfStr[1]);
					
					
					System.out.println("check did" + did);
					System.out.println("check did" + date1);
				System.out.println("check did" + did);
				CdReport list = iCdReport.getMonthlyreportAll(y, did, m);

				System.out.println("test" + list);
				// model.put("monthlyReportAll", list);
				model.addAttribute("update", list);
				return "updateCDreport";

			}
			
			@RequestMapping(value = "/CDchartReport", produces = "application/json")
			public String MonthchartReport(Model model, @ModelAttribute CdReport filteredYear, HttpServletRequest request) {

				System.out.println("inside MonthchartReport");
				System.out.println("id");
				List<CdReport> district1 = iCdReport.getCDAllreport();

				List<String> availableDistrict = new ArrayList<String>();
				List<Integer> availablefield = new ArrayList<Integer>();
				for (CdReport mr : district1) {
					if (!(availableDistrict.contains(mr.getDistrictMaster().getDistrictName())
							&& availableDistrict.contains(mr.getTotalExpense()))) {
						availableDistrict.add(mr.getDistrictMaster().getDistrictName());
					}

					if (!availablefield.contains(mr.getTotalExpense())) {
						availablefield.add(mr.getTotalExpense());
					}
					if (!availablefield.contains(mr.getMen())) {
						availablefield.add(mr.getMen());
					}
					if (!availablefield.contains(mr.getWoman())) {
						availablefield.add(mr.getWoman());
					}
				}

				System.out.println("district" + district1);
				model.addAttribute("district", district1);
				System.out.println("availablefield" + availablefield);
				model.addAttribute("availablefield", availablefield);
				System.out.println("availableDistrict" + availableDistrict);
				model.addAttribute("availableDistrict", availableDistrict);

				Map<String, Integer> map = new LinkedHashMap<>();
				
				/*for (int i = 0; i < availableDistrict.size(); i++) {
					map.put(availableDistrict.get(i), availablefield.get(i)); // is there a clearer way?

				}*/
				
				System.out.println("map" + map);
				model.addAttribute("map", map);
				
				return "CDchartReport";

			}
			
			@RequestMapping(value = "/CDMonthlyChart", produces = "application/json")
			public String MonthlyChart(@RequestParam String chartdata, ModelMap modelMap, HttpServletRequest request, 
					@ModelAttribute CdReport filteredYear) {

				System.out.println("inside monthlychart" + chartdata);
				
				List<CdReport> district1 = iCdReport.getCDAllreport();

				List<String> availableDistrict = new ArrayList<String>();
				List<Integer> availablefield = new ArrayList<Integer>();
				for (CdReport mr : district1) {
					
					if (!(availableDistrict.contains(mr.getDistrictMaster().getDistrictName()))) {
						availableDistrict.add(mr.getDistrictMaster().getDistrictName());
					}
		            if(chartdata.equals("TotalExpense")) {
					if (!availablefield.contains(mr.getTotalExpense())) {
						availablefield.add(mr.getTotalExpense());
					}
		            }
		            if(chartdata.equals("Woman")) {
						if (!availablefield.contains(mr.getWoman())) {
							availablefield.add(mr.getWoman());
						}
			            }
					else if(chartdata.equals("Men")) {
						System.out.println("inside else if");
						if (!availablefield.contains(mr.getMen())) {
							availablefield.add(mr.getMen());
						}
		            }
		            
				}
				modelMap.addAttribute("district",district1);
				
				/*
				 * System.out.println("district" + district1); model.addAttribute("district",
				 * district1); System.out.println("availablefield" + availablefield);
				 * model.addAttribute("availablefield", availablefield);
				 * System.out.println("availableDistrict" + availableDistrict);
				 * model.addAttribute("availableDistrict", availableDistrict);
				 */

				Map<String, Integer> map = new LinkedHashMap<>();
				
				for (int i = 0; i < availableDistrict.size(); i++) {
					map.put(availableDistrict.get(i), availablefield.get(i)); // is there a clearer way?

				}
				
			//	System.out.println("map" + map);
				modelMap.addAttribute("map", map);
				
				// HttpSession session = request.getSession();
				// session.setAttribute("map", map);
			//	request.setAttribute("map",map);
				modelMap.addAttribute("sample","One");
				modelMap.addAttribute("selectedOption",chartdata);
				
				
				return "CDchartReport";

			}
			
}