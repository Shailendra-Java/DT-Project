package org.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PrepareLinkList")
public class PrepareLinkList extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("month.properties");
         Properties props = new Properties();
         props.load(stream);

         HashMap<String, String> map = new HashMap<String, String>();

         for (final String month: props.stringPropertyNames()) {
             map.put(month, props.getProperty(month));
         }
         for (final String month: props.stringPropertyNames()) {
             map.put(month, props.getProperty(month));
         }

         // make the linkMap attribute available accross the application
         getServletContext().setAttribute("linkMap", map);
         // response.sendRedirect("dropdown.jsp");
         // or
         // request.getRequestDispatcher("dropdown.jsp").forward(request, response);
    }

}