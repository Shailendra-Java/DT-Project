package org.controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.dto.DistrictMaster;
import org.dto.UserMaster;
import org.service.IDistrictService;
import org.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.util.PasswordHasher;


@Controller
public class UserController {
	
@Autowired
IUserService iUserService;

@Autowired
IDistrictService iDistrictService;

	
	@RequestMapping(value="createuser")
	public String openCreateUser(Model model)
	{
	    UserMaster user= new UserMaster();
	
		model.addAttribute("user", user);
		
		List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		return "userenrollment";
    }
	
     @RequestMapping(value="enrollment")
	 public String enrollment(@ModelAttribute UserMaster user,final BindingResult result,Model model)
	 {
		
		if(result.hasErrors())
		{
				return "redirect:createuser";
		}
		
	 System.out.println("check it ");
		
	  iUserService.saveUser(user);
	  
	  
	  return "redirect:userlist";
	 }
	
	
	@RequestMapping(value="userlist")
	public String userList(Model model)
	{
      
		List<UserMaster> users=iUserService.getUserList();
		model.addAttribute("users", users);
		return "userlist";
	}
	
	
	@RequestMapping(value="edit")
	public String editUser(@RequestParam int id, Model model,HttpServletRequest request){
		UserMaster user2= new UserMaster();
		
		String password2 = request.getParameter("pass"+user2.getPassword());
		System.out.println("passworduser"+password2);
		
		UserMaster user=iUserService.getUserById(id);
         model.addAttribute("user",user);
		
		return "edit";
	}

    @RequestMapping(value="updateUser")
	public String updateUser(@ModelAttribute UserMaster user, final BindingResult result, HttpServletRequest request)
	{
		
		if(user.getPassword()==null)
		{
			System.out.println("null");
			HttpSession session=request.getSession();
			UserMaster user2=(UserMaster)session.getAttribute("user");
		
			user.setPassword(user2.getPassword());
		}
		
		else if(user.getPassword().isEmpty())
		{
			HttpSession session=request.getSession();
			UserMaster user2=(UserMaster)session.getAttribute("user");
			user.setPassword(user2.getPassword());
		}
		
	   else{
			System.out.println("pass");
			String cryptedPassword = new PasswordHasher().encode(user.getPassword());
			user.setPassword(cryptedPassword);
	 }
	 
		iUserService.updateUser(user);
		
		return "redirect:userlist";
	}
	

}
