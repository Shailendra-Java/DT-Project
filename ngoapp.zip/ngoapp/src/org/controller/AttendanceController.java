package org.controller;

import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.dto.AttendanceMaster;
import org.dto.DistrictMaster;
import org.dto.PublicGuidance;
import org.service.IAttendanceService;
import org.service.IDistrictService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AttendanceController {

	private static final Logger logger = LoggerFactory.getLogger(AttendanceController.class);
	// JOptionPane pane;
	@Autowired
	IAttendanceService iattendanceService;

	@Autowired
	IDistrictService iDistrictService;

	@InitBinder
	public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "attendance")
	public String CreateAttendance(Model model) {
		System.out.println("add_district");
		AttendanceMaster attendance = new AttendanceMaster();

		model.addAttribute("attendance1", attendance);

		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		System.out.println("hello world ");

		return "createattendance";
	}

	@RequestMapping(value = "saveattendance")
	public String saveAttendance(@ModelAttribute AttendanceMaster attendance, final BindingResult result, Model model) {
		System.out.println("inside create-----");
		Date createdDate = attendance.getCreatedDate();
		Integer districtId = attendance.getDistrictMaster().getDistrictId();
		System.out.println("districtName::" + districtId);
		if (!iattendanceService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			attendance.setDate(day);
			attendance.setMonth(month);
			attendance.setYear(year);
			attendance.getMonth();
			iattendanceService.saveattendance(attendance);
			/*
			 * CdReport cd = new CdReport(); cd.getMonth(); iCdReport.updateCdReport(cd);
			 */
			return "redirect:attendancelist";
		} else {
			// logger.info("Record Exists for Selected Month");
			JOptionPane.showMessageDialog(null, "Already Record Exists");
		}
		return "redirect:/attendance";
	}

	@RequestMapping(value = "attendancelist")
	public String attendancereport(Model model, @ModelAttribute AttendanceMaster filteredYear,
			HttpServletRequest request) {

		List<AttendanceMaster> attendancelist = iattendanceService.getAttendanceList();
		/*
		 * for(AttendanceMaster att:attendancelist){
		 * 
		 * }
		 */
		AttendanceMaster year = new AttendanceMaster();
		model.addAttribute("attendanceMaster", attendancelist);
		model.addAttribute("year", year);
		Integer fiYear = filteredYear.getYear();
		Integer currentMonth = filteredYear.getMonth();
		System.out.println("current month is " + currentMonth);
		HttpSession session = request.getSession();
		session.setAttribute("fiYear", fiYear);
		session.setAttribute("currentMonth", currentMonth);

		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		System.out.println("this is current month" + month);
		int day = cal.get(Calendar.DATE);
		int yearf = cal.get(Calendar.YEAR);

		List<AttendanceMaster> filteredYearReports = new ArrayList<AttendanceMaster>();
		List<AttendanceMaster> filtereMOnthsReports = new ArrayList<AttendanceMaster>();
		Map<Integer, Integer> filteredYearAndMonth = new HashMap<Integer, Integer>();

		if (fiYear == null) {
			fiYear = yearf;

		}
		if (currentMonth == null) {
			currentMonth = month;

		}

		List<Integer> availableYears = new ArrayList<Integer>();
		List<Integer> availableMOnths = new ArrayList<Integer>();

		for (AttendanceMaster reportYr : attendancelist) {
			if (!availableYears.contains(reportYr.getYear())) {
				availableYears.add(reportYr.getYear());
			}
			if (!availableMOnths.contains(reportYr.getMonth())) {
				availableMOnths.add(reportYr.getMonth());
			}
			if (reportYr.getYear().intValue() == fiYear && reportYr.getMonth().intValue() == currentMonth) {
				filteredYearReports.add(reportYr);

			} else {
				System.out.println("else :::");
			}

			if (null != filteredYearReports && !filteredYearReports.isEmpty()) {
				AttendanceMaster preport = filteredYearReports.get(0);
				if (null != preport.getDistrictMaster()) {
					String distName = preport.getDistrictMaster().getDistrictName();
					int distId = preport.getDistrictMaster().getDistrictId();
					request.getSession().setAttribute("distName", distName);
					request.getSession().setAttribute("distId", distId);
				}
			}
			availableYears = getAllAvailableYears(availableYears, yearf);
			model.addAttribute("attendanceMaster", filteredYearReports);
			model.addAttribute("availableYears", availableYears);
			// model.addAttribute("availableMOnths", availableMOnths);
			model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));

		}

		return "attendancelist";
	}

	private List<Integer> getAvailableMonths(List<Integer> availableMOnths) {

		if (null != availableMOnths) {
			if (!availableMOnths.contains(1)) {
				availableMOnths.add(1);
			}
			if (!availableMOnths.contains(2)) {
				availableMOnths.add(2);
			}
			if (!availableMOnths.contains(3)) {
				availableMOnths.add(3);
			}
			if (!availableMOnths.contains(4)) {
				availableMOnths.add(4);
			}
			if (!availableMOnths.contains(5)) {
				availableMOnths.add(5);
			}
			if (!availableMOnths.contains(6)) {
				availableMOnths.add(6);
			}
			if (!availableMOnths.contains(7)) {
				availableMOnths.add(7);
			}
			if (!availableMOnths.contains(8)) {
				availableMOnths.add(8);
			}
			if (!availableMOnths.contains(9)) {
				availableMOnths.add(9);
			}
			if (!availableMOnths.contains(10)) {
				availableMOnths.add(10);
			}
			if (!availableMOnths.contains(11)) {
				availableMOnths.add(11);
			}
			if (!availableMOnths.contains(12)) {
				availableMOnths.add(12);
			}
		}
		return availableMOnths;
	}

	private List<Integer> getAllAvailableYears(List<Integer> availableYears, int yearf) {
		if (availableYears.size() < 10) {
			for (int i = availableYears.size(); i < 10; i++) {
				if (!availableYears.contains(yearf)) {
					availableYears.add(yearf);
				}
				yearf--;
			}
		}
		return availableYears;
	}

	@RequestMapping(value = "editAttendancereport")
	public String editPEreport(@RequestParam Integer attdId, Model model, HttpServletRequest request) {

		AttendanceMaster attendancereport = new AttendanceMaster();

		AttendanceMaster editattendancereport = iattendanceService.getReportById(attdId);

		model.addAttribute("editattendancereport", editattendancereport);

		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		return "editattendance";
	}

	@RequestMapping(value = "updateattendancereport")
	public String updateUser(@ModelAttribute AttendanceMaster attendance, final BindingResult result,
			HttpServletRequest request) {
		System.out.println("ravi");
		Date createdDate = attendance.getCreatedDate();
		Integer districtId = attendance.getDistrictMaster().getDistrictId();
		if (!iattendanceService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		attendance.setDate(day);
		attendance.setMonth(month);
		attendance.setYear(year);
		
		System.out.println("india  ---- : "+ attendance.getDistrictMaster().getDistrictName());
		// System.out.println("date::"+day+"Month:::"+month+"year::"+year);
		iattendanceService.updateattendancereport(attendance);
		System.out.println("RaviSinghYadav");
		return "redirect:attendancelist";
		}
		else{
			return null;
		}

	}
	
	@RequestMapping(value = "monthyattendancereport")
	public String monthlyPEreport(Model model, @ModelAttribute AttendanceMaster filteredYear,
			HttpServletRequest request, @RequestParam int attdId) {
		AttendanceMaster selectedReport = iattendanceService.getReportById(attdId);
		List<AttendanceMaster> monthlyPEreport = iattendanceService.getAttendanceList();
		AttendanceMaster monthlyPEreport1 = monthlyPEreport.get(0);
		Integer year = filteredYear.getYear();

		String m = null;

		for (AttendanceMaster monthlyCDreport2 : monthlyPEreport) {
			int month = monthlyCDreport2.getMonth();

			m = Month.of(month).name();
			System.out.println("month" + m);

		}

		HttpSession session = request.getSession();
		session.setAttribute("year", year);
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		session.setAttribute("month", m);

		model.addAttribute("monthlyPEreport", monthlyPEreport);
		model.addAttribute("monthlyPEreport1", monthlyPEreport1);
		model.addAttribute("month", m);

		List<AttendanceMaster> filteredReport = new ArrayList<AttendanceMaster>();
		int selectedYear = 0;
		int selectedDistrict = 0;

		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		/*
		 * if(null!= filteredYear && null != filteredYear.getYear()) { selectedYear =
		 * filteredYear.getYear(); } if(selectedYear<= 0) { if(null !=
		 * request.getSession() && null != request.getSession().getAttribute("fiYear"))
		 * { selectedYear = (Integer)request.getSession().getAttribute("fiYear"); }
		 * 
		 * }
		 * 
		 * if(null !=filteredYear && null != filteredYear.getDistrictMaster() &&
		 * filteredYear.getDistrictMaster().getDistrictId() > 0) { selectedDistrict =
		 * filteredYear.getDistrictMaster().getDistrictId(); }
		 */

		if (null != monthlyPEreport) {
			for (AttendanceMaster report : monthlyPEreport) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {

						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		model.addAttribute("attendanceMaster", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyPEreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyPEreport));

		return "monthyattendancereport";
	}

	@RequestMapping(value = "monthyattendancereport_submit")
	public String monthlyCdreportprogram_submit(Model model, @ModelAttribute AttendanceMaster filteredYear,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		String distriName = filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		Integer selectedDistrict = 0;
		String districtName = "";
		if (null != filteredYear.getDistrictMaster()) {
			selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
			districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear = filteredYear.getYear();

		List<AttendanceMaster> monthlyPEreport = iattendanceService.getAttendanceList();
		AttendanceMaster monthlyPEreport1 = monthlyPEreport.get(0);
		model.addAttribute("monthlyPEreport1", monthlyPEreport1);
		List<AttendanceMaster> filteredReport = new ArrayList<AttendanceMaster>();
		if (null != monthlyPEreport1) {
			for (AttendanceMaster report : monthlyPEreport) {
				if (selectedYear.intValue() == report.getYear().intValue()) {
					if (null != report.getDistrictMaster()
							&& districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
						// && selectedDistrict == report.getDistrictMaster().getDistrictId()
						filteredReport.add(report);
					}
				}
			}
		}
		model.addAttribute("attendanceMaster", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyPEreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyPEreport));
		return "monthyattendancereport";
	}

	private List<Integer> getUniqueYear(List<AttendanceMaster> monthlyPEreport) {
		List<Integer> years = new ArrayList<Integer>();
		if (null != monthlyPEreport) {
			for (AttendanceMaster report : monthlyPEreport) {
				if (!years.contains(report.getYear())) {
					years.add(report.getYear());
				}
			}
		}
		return years;
	}

	private List<String> getUniqueDistrictName(List<AttendanceMaster> monthlyPEreport) {
		List<String> districtName = new ArrayList<String>();
		if (null != monthlyPEreport) {
			for (AttendanceMaster report : monthlyPEreport) {
				if (null != report.getDistrictMaster()
						&& !districtName.contains(report.getDistrictMaster().getDistrictName())) {
					districtName.add(report.getDistrictMaster().getDistrictName());
				}
			}
		}
		return districtName;
	}

	@RequestMapping(value = "deleteAttendancereport")
	public ModelAndView deleteAttendanceReport(HttpServletRequest request,final RedirectAttributes redirectAttributes) {
		Integer attendanceId = Integer.parseInt(request.getParameter("attdId"));
		iattendanceService.deleteAttendanceReport(attendanceId);
		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "User is deleted!");
		return new ModelAndView("redirect:attendancelist");
	}

	@RequestMapping(value = "viewMonthlyAttendance")
	public String ViewMonthReport(@RequestParam int attdId, Model model) {

		System.out.println("inside ViewMonthReport");
		System.out.println("id" + attdId);
		AttendanceMaster district1 = iattendanceService.getReportById(attdId);
		System.out.println("district" + district1);
		model.addAttribute("district", district1);

		return "viewMonthAttendance";

	}

	@RequestMapping(value = "downloadPDF", method = RequestMethod.GET)
	public ModelAndView downloadPdf() {
		List<AttendanceMaster> listattendance = iattendanceService.getAttendanceList();

		return new ModelAndView("pdfView", "listattendance", listattendance);
	}

	@RequestMapping(value = "downloadExcel", method = RequestMethod.GET)
	public ModelAndView downloadExcel() {
		List<AttendanceMaster> listattendance = iattendanceService.getAttendanceList();
		return new ModelAndView("excelView", "listattendance", listattendance);
	}

	@RequestMapping(value = "checkmonthattendance", method = RequestMethod.POST)
	@ResponseBody
	public String dateCheck(@RequestParam String date) {
		boolean error = false;
		System.out.println("inside checkDate method");
		String[] arrOfStr = date.split("/");
		String date1 = String.valueOf(arrOfStr[0]);
		int did = Integer.valueOf(arrOfStr[1]);
		System.out.println(date1 + "" + did);
		String[] arrOfStr1 = date1.split("-");
		int y = Integer.valueOf(arrOfStr1[0]);
		int m = Integer.valueOf(arrOfStr1[1]);
		System.out.println("month" + m + "year" + y);

		AttendanceMaster att = iattendanceService.getReportByMonthYearDistrict(m, y, did);
		System.out.println("hi" + att);

		if (att != null) {
			System.out.println("report present for this month");
			@SuppressWarnings("unused")
			List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

			error = true;
		}
		return "" + error;

	}

	@RequestMapping(value = "attendanceReportUpdate")
	public String getExistingAttendanceReport(@ModelAttribute @Valid AttendanceMaster attendanceMaster,
			final BindingResult result, @RequestParam String date, Model model)

	{
		System.out.println("test inside attendanceUpdate");

		System.out.println("checkmonth");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		String[] arrOfStr1 = date1.split("-");
		int y = Integer.valueOf(arrOfStr1[0]);
		int m = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);
		System.out.println("check did" + did);
		AttendanceMaster list = iattendanceService.getAttendancereportAll(y, did, m);

		System.out.println("test" + list);
		// model.put("monthlyReportAll", list);
		model.addAttribute("updateAttendance", list);
		return "updateAttendance";

	}

}
