package org.controller;

import java.util.List;
import org.dto.DistrictAdmin;
import org.dto.DistrictMaster;
import org.service.IDistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DistrictAdminContoller {

	@Autowired
	IDistrictService iDistrictService;

	@RequestMapping(value = "add_new_district")
	public String createnewdistrict(Model model) {
		System.out.println("add_new_district");

		DistrictMaster newdistrict = new DistrictMaster();

		model.addAttribute("newdistrict", newdistrict);

		/*
		 * List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		 * model.addAttribute("districtMaster", districtMaster);
		 */

		return "adddistrict";
	}

	@RequestMapping(value = "save_new_district")
	public String savenewdistrict(@ModelAttribute DistrictMaster district, final BindingResult result, Model model) {
		System.out.println("save_new_district");

		if (result.hasErrors()) {
			return "redirect:createuser";
		}

		boolean exits;

		exits = iDistrictService.savedistrict(district);

		System.out.println("Done" + exits);

		if (exits == true) {

			model.addAttribute("error", "Do not contains the duplicate values!please enter with district");

			return "redirect:add_new_district";
		}

		System.out.println("check it ");

		return "redirect:districtlist";

	}

	@RequestMapping(value = "districtlist")
	public String districtList(Model model) {

		List<DistrictMaster> districts = iDistrictService.getdistrictList();
		model.addAttribute("districts", districts);
		return "newdistrictlist";
	}

	@RequestMapping(value = "editnewdistrict")
	public String editdistrict(Model model, @RequestParam int id) {

		System.out.println("inside edit");
		System.out.println("id" + id);
		DistrictMaster districts = iDistrictService.getdistrictReportById(id);
		System.out.println("district" + districts);
		model.addAttribute("districts", districts);

		return "editnewdisrtict";
	}

	@RequestMapping(value = "checkdistrict", method = RequestMethod.POST)
	@ResponseBody
	public String CheckUserName(@RequestParam String DistrictName)

	{

		System.out.println("test");

		boolean district = iDistrictService.getDistrictname(DistrictName);

		System.out.println("test");

		return "" + district;
	}

	@RequestMapping(value = "updateDistrict")
	public String updateDistrict(@ModelAttribute DistrictAdmin district, final BindingResult result) {
		iDistrictService.updateDistrict(district);

		return "redirect:districtlist";
	}

}