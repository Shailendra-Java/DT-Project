package org.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.dto.DistrictMaster;
import org.dto.MonthlyReport;
import org.service.IDistrictService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MonthlyReportController {
	private static final Logger logger = LoggerFactory.getLogger(MonthlyReportController.class);

	@Autowired
	IDistrictService iDistrictService;

	@InitBinder
	public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	

	@RequestMapping(value = "add_district")
	public String openCreateUser(Model model) {
		System.out.println("add_district");

		MonthlyReport district = new MonthlyReport();

		model.addAttribute("district", district);

		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		return "createdistrict";

	}

	@RequestMapping(value = "enrolldistrict")
	public String enrolldistrict(@ModelAttribute @Valid MonthlyReport monthlyReport, final BindingResult result,
			Model model, @ModelAttribute("district") @Validated MonthlyReport mreport, final RedirectAttributes redirectAttributes) {

		Date createdDate = monthlyReport.getCreated_Date();
		Integer districtId = monthlyReport.getDistrictMaster().getDistrictId();
		System.out.println("districtName::" + districtId);
		if (!iDistrictService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			System.out.println("Record Exists for Selected Month and year" + month);
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			// report.setDate(day);
			monthlyReport.setMonth(month);
			monthlyReport.setYear(year);
			monthlyReport.getMonth();
			Date d = new Date();
			if (createdDate.equals(d)) {
				monthlyReport.setCreated_Date(d);
			}
			// monthlyReport.setCreated_Date(d);
			
			monthlyReport.setModified_Date(d);
			iDistrictService.saveMonthlyReport(monthlyReport);
			redirectAttributes.addFlashAttribute("msg", "Record added successfully!");
			return "redirect:monthlyReportList";
		} else {
			
			model.addAttribute("Error", "Record Exists for Selected Month and year");
			
			System.out.println("Record Exists for Selected Month and year");

		}
		
		
		return "redirect:createmonthlyreport";
	}

	@RequestMapping(value = "editdistrict")
	public String editDistrict(@RequestParam long id, Model model) {

		System.out.println("inside editMonthly");
		System.out.println("id" + id);
		MonthlyReport district = iDistrictService.getMonthlyReportById(id);
		System.out.println("district" + district);
		model.addAttribute("district", district);

		return "editdistrict";

	}

	
	@RequestMapping(value = "updateMreport")
	public String updateUser(@RequestParam int mrId, @ModelAttribute MonthlyReport updateMreport,
			final BindingResult result, HttpServletRequest request, Model model, final RedirectAttributes redirectAttributes) {
		Date sectedDate = updateMreport.getCreated_Date();
		MonthlyReport district = iDistrictService.getReportById(mrId);
		Integer disID = district.getDistrictMaster().getDistrictId();
		model.addAttribute("district", district);

		System.out.println("sectedDate::" + sectedDate + "disIDdisID" + disID);
		if (!iDistrictService.isReportExistForSelectedMonthAndYearEdit(sectedDate, disID, district)) {
			Date createdDate = updateMreport.getCreated_Date();
			System.out.println("createdDate::" + createdDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			// updateMreport.setDate(day);
			updateMreport.setMonth(month);
			updateMreport.setYear(year);

			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			// Date d = format.equals(createdDate);

			System.out.println("date-----" + createdDate);

			Date date = new Date();
			updateMreport.setCreated_Date(createdDate);
			updateMreport.setModified_Date(date);
			System.out.println("hi esquare");

			iDistrictService.updateMonthlyReport(updateMreport);
			redirectAttributes.addFlashAttribute("msg", "Record updated successfully!");
		} else {
			System.out.println("NOT UPDATED------------------------");
			return "editdistrict";
		}
		return "redirect:monthlyReportList";
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "monthlyReportList")
	public String monthlyReportList(Model model, @ModelAttribute MonthlyReport filteredYear,
			HttpServletRequest request) {
		// List<String> districtName=new ArrayList<String>();
       
		System.out.println("districtlist");
		List<MonthlyReport> monthlyReport = iDistrictService.getMonthlyReportList();
		MonthlyReport year = new MonthlyReport();

		System.out.println("monthlyReport>>>>>>>>>>>>  " + monthlyReport.size());
		model.addAttribute("monthlyReport1", monthlyReport);
		model.addAttribute("year", year);

		Integer fiYear = filteredYear.getYear();
		Integer currentMonth = filteredYear.getMonth();

		HttpSession session = request.getSession();
		session.setAttribute("fiYear", fiYear);

		session.setAttribute("currentMonthToDisplay", String.valueOf(currentMonth));
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int yearf = cal.get(Calendar.YEAR);
		if (null == currentMonth) {
			// First Time value
			currentMonth = month;
		}

		session.setAttribute("currentMonth", currentMonth);
		List<MonthlyReport> filteredYearReports = new ArrayList<MonthlyReport>();
		List<MonthlyReport> filtereMOnthsReports = new ArrayList<MonthlyReport>();
		Map<Integer, Integer> filteredYearAndMonth = new HashMap<Integer, Integer>();
		if (fiYear == null) {
			fiYear = yearf;

		}
		if (currentMonth == null) {
			currentMonth = month;

		}

		List<Integer> availableYears = new ArrayList<Integer>();
		List<Integer> availableMOnths = new ArrayList<Integer>();

		for (MonthlyReport reportYr : monthlyReport) {
			if (!availableYears.contains(reportYr.getYear())) {
				availableYears.add(reportYr.getYear());
			}
			if (!availableMOnths.contains(reportYr.getMonth())) {
				availableMOnths.add(reportYr.getMonth());
			}
			if (reportYr.getYear().intValue() == fiYear && reportYr.getMonth().intValue() == currentMonth) {
				filteredYearReports.add(reportYr);

			} else {
				System.out.println("else :::");
			}
			if (null != filteredYearReports && !filteredYearReports.isEmpty()) {
				MonthlyReport report = filteredYearReports.get(0);
				if (null != report.getDistrictMaster()) {
					String distName = report.getDistrictMaster().getDistrictName();
					int distId = report.getDistrictMaster().getDistrictId();
					request.getSession().setAttribute("distName", distName);
					request.getSession().setAttribute("distId", distId);
				}
			}

			model.addAttribute("monthlyReport", filteredYearReports);
			model.addAttribute("availableYears", availableYears);
			// model.addAttribute("availableMOnths", availableMOnths);
			availableYears = getAllAvailableYears(availableYears, yearf);
			model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));
		}

		// model.addAttribute("districtName", districtName);
		return "districtlist";
	}

	private List<Integer> getAvailableMonths(List<Integer> availableMOnths) {

		if (null != availableMOnths) {
			if (!availableMOnths.contains(1)) {
				availableMOnths.add(1);
			}
			if (!availableMOnths.contains(2)) {
				availableMOnths.add(2);
			}
			if (!availableMOnths.contains(3)) {
				availableMOnths.add(3);
			}
			if (!availableMOnths.contains(4)) {
				availableMOnths.add(4);
			}
			if (!availableMOnths.contains(5)) {
				availableMOnths.add(5);
			}
			if (!availableMOnths.contains(6)) {
				availableMOnths.add(6);
			}
			if (!availableMOnths.contains(7)) {
				availableMOnths.add(7);
			}
			if (!availableMOnths.contains(8)) {
				availableMOnths.add(8);
			}
			if (!availableMOnths.contains(9)) {
				availableMOnths.add(9);
			}
			if (!availableMOnths.contains(10)) {
				availableMOnths.add(10);
			}
			if (!availableMOnths.contains(11)) {
				availableMOnths.add(11);
			}
			if (!availableMOnths.contains(12)) {
				availableMOnths.add(12);
			}
		}
		return availableMOnths;
	}

	private List<Integer> getAllAvailableYears(List<Integer> availableYears, int yearf) {
		if (availableYears.size() < 12) {
			for (int i = availableYears.size(); i < 12; i++) {
				if (!availableYears.contains(yearf)) {
					availableYears.add(yearf);
				}
				yearf--;
			}
		}
		return availableYears;
	}

	@RequestMapping(value = "monthlyReportAll")
	public String monthlyReport(Model model, @ModelAttribute MonthlyReport filteredYear, HttpServletRequest request,
			@RequestParam long id) {

		MonthlyReport selectedReport = iDistrictService.getReportById(id);
		long mrid=selectedReport.getMrId();
		System.out.println("hello distr"+selectedReport.getMrId());
		
		model.addAttribute("MrId", mrid);
		
		List<MonthlyReport> monthlyreport = iDistrictService.getMRAllreport();
		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		MonthlyReport monthlyreport1 = monthlyreport.get(0);
		Integer year = filteredYear.getYear();

		HttpSession session = request.getSession();
		session.setAttribute("year", year);
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		System.out.println("hello distr"+distriName);
		session.setAttribute("distriName", distriName);

		model.addAttribute("monthlyreport", monthlyreport);
		model.addAttribute("monthlyreport1", monthlyreport1);
		List<MonthlyReport> filteredReport = new ArrayList<MonthlyReport>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		if (null != monthlyreport) {
			for (MonthlyReport report : monthlyreport) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {
						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		String m = null;
		List<String> filteredReport1 = new ArrayList<String>();
		for (MonthlyReport monthlyreport2 : monthlyreport) {

			int month = monthlyreport2.getMonth();

			m = Month.of(month).name();
			// m=Month.of(month).getDisplayName(TextStyle.FULL_STANDALONE, locale);
			filteredReport1.add(m);
			// filteredReport.addAll(filteredReport1);
			System.out.println("month" + m);

		}

		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("month", filteredReport1);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(districtMaster));
		return "monthlyReportAll";
	}

	@RequestMapping(value = "monthlyreport_submit")
	public String monthlyreport_submit(Model model, @ModelAttribute MonthlyReport filteredYear,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		String distriName = filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		@SuppressWarnings("unused")
		Integer selectedDistrict = 0;
		String districtName = "";
		if (null != filteredYear.getDistrictMaster()) {
			selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
			districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear = filteredYear.getYear();

		List<MonthlyReport> monthlyreport = iDistrictService.getMRAllreport();
		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		MonthlyReport monthlyreport1 = monthlyreport.get(0);
		model.addAttribute("monthlyreport1", monthlyreport1);
		List<MonthlyReport> filteredReport = new ArrayList<MonthlyReport>();
		if (null != monthlyreport) {
			for (MonthlyReport report : monthlyreport) {
				if (selectedYear.intValue() == report.getYear().intValue()) {
					if (null != report.getDistrictMaster()
							&& districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
						// && selectedDistrict == report.getDistrictMaster().getDistrictId()
						filteredReport.add(report);
					}
				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(districtMaster));
		return "monthlyReportAll";
	}

	private Object getUniqueYear(List<MonthlyReport> monthlyreport) {
		List<Integer> years = new ArrayList<Integer>();
		if (null != monthlyreport) {
			for (MonthlyReport report : monthlyreport) {
				if (!years.contains(report.getYear())) {
					years.add(report.getYear());
				}
			}
		}
		return years;
	}

	private Object getUniqueDistrictName(List<DistrictMaster> districtMaster) {
		List<String> districtName = new ArrayList<String>();
		
		if (null != districtMaster) {
			for (DistrictMaster report : districtMaster) {
				if (null != report.getDistrictName()
						&& !districtName.contains(report.getDistrictName())) {
					districtName.add(report.getDistrictName());
				}
			}
		}
		 
		return districtName;
	}

	
	
	
	@RequestMapping(value = "delete")
	public String deleteReport(@RequestParam long id,final RedirectAttributes redirectAttributes) {

		this.iDistrictService.deleteReport(id);
		// return "monthlyReportList";
		//ModelAndView model = new ModelAndView();
		
		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "Record is deleted!"); 
		return "redirect:monthlyReportList";
	}

	@RequestMapping(value = "ViewMonthReport")
	public String ViewMonthReport(@RequestParam long id, Model model) {

		System.out.println("inside ViewMonthReport");
		System.out.println("id" + id);
		MonthlyReport district1 = iDistrictService.getMonthlyReportById(id);
		System.out.println("district" + district1);
		model.addAttribute("district", district1);

		return "ViewMonthReport";

	}

	@RequestMapping(value = "/MonthlyChart", produces = "application/json")
	public String MonthlyChart(@RequestParam String chartdata, ModelMap modelMap, HttpServletRequest request,
			@ModelAttribute MonthlyReport filteredYear) {

		System.out.println("inside monthlychart" + chartdata);

		List<MonthlyReport> district1 = iDistrictService.getMRAllreport();

		List<String> availableDistrict = new ArrayList<String>();
		
		List<Integer> availablefield = new ArrayList<Integer>();
		
		modelMap.addAttribute("district", district1);
		Map<String, Integer> map = new LinkedHashMap<>();
		

		for (int i = 0; i < availableDistrict.size(); i++) {
			map.put(availableDistrict.get(i), availablefield.get(i)); // is there a clearer way?

		}
		
		// System.out.println("map" + map);
		modelMap.addAttribute("map", map);
		
		modelMap.addAttribute("sample", "One");
		modelMap.addAttribute("selectedOption", chartdata);

		return "MonthchartReport";

	}

	@RequestMapping(value = "/MonthchartReport", produces = "application/json")
	public String MonthchartReport(Model model, @ModelAttribute MonthlyReport filteredYear,
			HttpServletRequest request) {

		System.out.println("inside MonthchartReport");
		System.out.println("id");
		List<MonthlyReport> district1 = iDistrictService.getMRAllreport();

		List<String> availableDistrict = new ArrayList<String>();
		List<Integer> availablefield = new ArrayList<Integer>();
		for (MonthlyReport mr : district1) {
			if (!(availableDistrict.contains(mr.getDistrictMaster().getDistrictName()))) {
				availableDistrict.add(mr.getDistrictMaster().getDistrictName());
			}

			if (!availablefield.contains(mr.getCurrentMonthTotalMembers())) {
				availablefield.add(mr.getCurrentMonthTotalMembers());
			}
		}

		System.out.println("district" + district1);
		model.addAttribute("district", district1);
		System.out.println("availablefield" + availablefield);
		model.addAttribute("availablefield", availablefield);
		System.out.println("availableDistrict" + availableDistrict);
		model.addAttribute("availableDistrict", availableDistrict);
		

		Map<String, Integer> map = new LinkedHashMap<>();

		for (int i = 0; i < availableDistrict.size(); i++) {
			map.put(availableDistrict.get(i), availablefield.get(i)); // is there a clearer way?

		}

		System.out.println("map" + map);
		model.addAttribute("map", map);

		return "MonthchartReport";

	}

	@RequestMapping(value = "monthlyreportpdf", method = RequestMethod.GET)
	public ModelAndView pdfdownload() {
		List<MonthlyReport> monthlypdf = iDistrictService.getMRAllreport();

		return new ModelAndView("monthlyreportpdf", "monthlypdf", monthlypdf);
	}

	@RequestMapping(value = "MonthlyReport", method = RequestMethod.GET)
	public ModelAndView Exceldownload() {
		List<MonthlyReport> monthlyexcell = iDistrictService.getMRAllreport();
		return new ModelAndView("MonthlyReport", "monthlyexcell", monthlyexcell);
	}

	
	@RequestMapping(value = "checkmonth", method = RequestMethod.POST)
	@ResponseBody
	public String checkDateDistrict(@RequestParam String date)

	{
		boolean error = false;
		System.out.println("inside checkDate method");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		String[] arrOfStr1 = date1.split("-");
		int year = Integer.valueOf(arrOfStr1[0]);
		int month = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);

		MonthlyReport mr = iDistrictService.getMonthlyReportByMonthYearDistrict(year, month, did);
		System.out.println("month and year deatils" + mr);

		if (mr != null) {
			System.out.println("Report is already present for this month");

			@SuppressWarnings("unused")
			List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

			error = true;

		}

		System.out.println("check2");

		return "" + error;
	}

	@RequestMapping(value = "monthlyAllReportUpdate")
	public String getDistrictName(@ModelAttribute("monthlyReport") @Valid MonthlyReport monthlyReport, final BindingResult result,
			@RequestParam String date, Model model, final RedirectAttributes redirectAttributes)

	{
		System.out.println("test inside monthlyReportUpdate");

		System.out.println("checkmonth");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		String[] arrOfStr1 = date1.split("-");
		int year = Integer.valueOf(arrOfStr1[0]);
		int month = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);
		System.out.println("check did" + did);
		MonthlyReport list = iDistrictService.getMonthlyReportByMonthYearDistrict(year, month, did);

		System.out.println("test" + list);
		// model.put("monthlyReportAll", list);
		model.addAttribute("update", list);
		return "update";

	}
	
	@RequestMapping(value = "allMonthChart", produces = "application/json")
	public String MonthAllChart( @RequestParam long id, ModelMap modelMap, HttpServletRequest request,
			@ModelAttribute MonthlyReport filteredYear, Model model) {
		
		System.out.println("test inside allMonthChart" +id);
		
		
		MonthlyReport selectedReport = iDistrictService.getReportById(id);
		List<MonthlyReport> monthlyreport = iDistrictService.getMRAllreport();
		
		List<DistrictMaster> distriname = iDistrictService.getDistrictMasterList();
		
		MonthlyReport monthlyreport1 = monthlyreport.get(0);
		System.out.println("monthlyreport1"+monthlyreport1.getMrId());
		
		Integer year = filteredYear.getYear();

		HttpSession session = request.getSession();
		session.setAttribute("year", year);
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);

		model.addAttribute("monthlyreport", monthlyreport);
		model.addAttribute("monthlyreport1", monthlyreport1);
		List<MonthlyReport> filteredReport = new ArrayList<MonthlyReport>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		if (null != monthlyreport) {
			for (MonthlyReport report : monthlyreport) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {
						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		
		
		List<Integer> availableMonth = new ArrayList<Integer>();
		List<Integer> availablefield = new ArrayList<Integer>();
		
		for (MonthlyReport mr : filteredReport) {
			if (!(availableMonth.contains(mr.getMonth()))) {
				availableMonth.add(mr.getMonth());
			}

			if (!availablefield.contains(mr.getCurrentMonthTotalMembers())) {
				availablefield.add(mr.getCurrentMonthTotalMembers());
			}
		}
		
		
		
		Map<Integer, Integer> map = new LinkedHashMap<>();
		
		for (int i = 0; i < availableMonth.size(); i++) {
			map.put(availableMonth.get(i), availablefield.get(i)); // is there a clearer way?

		}

		System.out.println("map" + map);

		model.addAttribute("filteredReport", filteredReport);
		System.out.println("filteredReport" + filteredReport.get(0));
		System.out.println("selectedDistrict" + selectedDistrict);
		
		
		model.addAttribute("map", map);
		System.out.println("selectedDistrict" + map);
		
		System.out.println("availablefield" + availablefield);
		model.addAttribute("availablefield", availablefield);
		System.out.println("availableDistrict" + availableMonth);
		model.addAttribute("availableDistrict", availableMonth);
		
		
		
		
		return null;

	}
	
	
	
	@RequestMapping(value = "repoertAll")
	public String repoertAll(@RequestParam String districtId, ModelMap modelMap, HttpServletRequest request, @ModelAttribute MonthlyReport filteredYear, Model model) {
		
		System.out.println("test inside allMonthChart district"+districtId);
		
		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		
		System.out.println("test inside allMonthChart districthellll"+districtMaster);
		
		List<DistrictMaster> districtName= iDistrictService.getDistrictMasterList(districtId);
		
		System.out.println("test inside allMonthChart districtName"+districtName);
		
		int id=0;
		boolean error = false;
		for(DistrictMaster ds:districtName) {
			id=ds.getDistrictId();
			System.out.println("test inside allMonthChart district"+id);
			error=true;
		}
		
		
		  
		 
		
		HttpSession session = request.getSession();
		
		//Integer id=Integer.valueOf(districtId);
		
		System.out.println("test inside allMonthChart" +id);
		
		
		//MonthlyReport selectedReport = iDistrictService.getReportByDistrictId(id);
		
		List<MonthlyReport> selectedReportdist = iDistrictService.getByDistrictId(id);
		
		List<MonthlyReport> monthlyreport = iDistrictService.getMRAllreport();
		
		List<DistrictMaster> distriname = iDistrictService.getDistrictMasterList();
		
		MonthlyReport monthlyreport1 = monthlyreport.get(0);
		Integer year = filteredYear.getYear();

		
		session.setAttribute("year", year);
		//String distriName = selectedReport.getDistrictMaster().getDistrictName();
		//session.setAttribute("distriName", distriName);

		model.addAttribute("monthlyreport", monthlyreport);
		model.addAttribute("monthlyreport1", monthlyreport1);
		List<MonthlyReport> filteredReport = new ArrayList<MonthlyReport>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		for(MonthlyReport report:selectedReportdist)
		if (null != selectedReportdist) {
			selectedYear = report.getYear();
			report.getMonth();
			selectedDistrict = report.getDistrictMaster().getDistrictId();
		}

		if (null != monthlyreport) {
			for (MonthlyReport report : monthlyreport) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {
						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		
		
		List<Integer> availableMonth = new ArrayList<Integer>();
		List<Integer> availablefield = new ArrayList<Integer>();
		
		for (MonthlyReport mr : filteredReport) {
			if (!(availableMonth.contains(mr.getMonth()))) {
				availableMonth.add(mr.getMonth());
			}

			if (!availablefield.contains(mr.getCurrentMonthTotalMembers())) {
				availablefield.add(mr.getCurrentMonthTotalMembers());
			}
		}
		
		
		
		Map<Integer, Integer> map = new LinkedHashMap<>();
		
		for (int i = 0; i < availableMonth.size(); i++) {
			map.put(availableMonth.get(i), availablefield.get(i)); // is there a clearer way?

		}

		
		System.out.println("map" + map);

		model.addAttribute("filteredReport", filteredReport);
		System.out.println("filteredReport" + filteredReport.get(0));
		System.out.println("selectedDistrict" + selectedDistrict);
		
		
		model.addAttribute("map", map);
		System.out.println("selectedDistrict" + map);
		
		System.out.println("availablefield" + availablefield);
		model.addAttribute("availablefield", availablefield);
		System.out.println("availableDistrict" + availableMonth);
		model.addAttribute("availableDistrict", availableMonth);
		
		
		
		
		return "repoertAll";

	}
	
	
}
