
package org.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.dao.PublicGuidanceDao;
import org.dto.AttendanceMaster;
import org.dto.DistrictMaster;
import org.dto.MonthlyReport;
import org.dto.PublicGuidance;
import org.service.IDistrictService;
import org.service.IPublicGuidanceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class publicguidanceController {
	private static final Logger logger = LoggerFactory.getLogger(publicguidanceController.class);

	@Autowired
	IPublicGuidanceService ipublicservice;
	@Autowired
	IDistrictService iDistrictService;

	@InitBinder
	public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "publicguidance_report")
	public String publicguidance_report(Model model) {
		PublicGuidance pubGui = new PublicGuidance();
		model.addAttribute("pubGui", pubGui);
		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("district", districtMaster);
		// model.addAttribute("districtMaster", districtMaster);
		return "publicguidance_report";
	}

	
	@RequestMapping(value = "districtPublicGuidancereport")
	public String district(Model model) {

		PublicGuidance districtPublicGuidancereport = new PublicGuidance();
		model.addAttribute("districtPublicGuidancereport", districtPublicGuidancereport);

		return "PublicGuidance_report";
	}

	@RequestMapping(value = "PublicGuidanceRegistration")

	public String PublicGuidanceRegistration(Model model) {

		System.out.println("PublicGuidancedsds");
		PublicGuidance publicguidance = new PublicGuidance();

		model.addAttribute("publicguidance", publicguidance);
		
		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		return "PublicGuidanceRegistration";

	}

	@RequestMapping(value = "savePublicguidance")
	public String savePublicguidance(@ModelAttribute PublicGuidance publicguide, final BindingResult result,
			Model model, @ModelAttribute("publicguidance") @Validated PublicGuidance pgreport) {

		System.out.println("savepublic");
		Date createdDate = publicguide.getCreatedDate();
		Integer districtId = publicguide.getDistrictMaster().getDistrictId();
		System.out.println("districtName::" + districtId);
		if (!ipublicservice.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);

			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			publicguide.setDate(day);
			publicguide.setMonth(month);
			publicguide.setYear(year);
			
			ipublicservice.savePublicguidance(publicguide);
			return "redirect:publicguidance_reportlist";
		}

		else {
			logger.info("Record exist for select month");
			JOptionPane.showMessageDialog(null, "Record Exists for Selected Month");
		}

		return "redirect:publicguidance_reportlist";
	}

	@RequestMapping(value = "editpublicguidancereport")

	public String editpublicguidancereport(Model model, @RequestParam Integer pgId) {

	
		PublicGuidance editpublicguidancereport = ipublicservice.geteditReportById(pgId);
		model.addAttribute("editpublicguidancereport", editpublicguidancereport);

		return "editpublicguidancereport";
		
	}
	
	
	@RequestMapping(value = "updatepreport")
	public String updateUser(@RequestParam int pgId, @ModelAttribute PublicGuidance updateMreport,
			final BindingResult result, HttpServletRequest request, Model model) {
		Date createdDate = updateMreport.getCreatedDate();
        PublicGuidance district = ipublicservice.geteditReportById(pgId);
		Integer districtId = district.getDistrictMaster().getDistrictId();
		model.addAttribute("district", district);

		System.out.println("sectedDate::" + createdDate + "disIDdisID" + districtId);
		/*if (!ipublicservice.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {*/
			Date createdate = updateMreport.getCreatedDate();
			System.out.println("createdDate::" + createdate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			// updateMreport.setDate(day);
			updateMreport.setMonth(month);
			updateMreport.setYear(year);

			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			// Date d = format.equals(createdDate);

			System.out.println("date-----" + createdDate);

			Date date = new Date();
			updateMreport.setCreatedDate(createdDate);
		//	updateMreport.setModifiedDate(date);
			System.out.println("hi esquare");
			ipublicservice.updatepublicguidancereport(updateMreport);
			System.out.println("dilip");

		//	iDistrictService.updateMonthlyReport(updateMreport);
		/*} else {
			System.out.println("NOT UPDATED------------------------");
			return "redirect:publicguidance_reportlist";
		}*/
		return "redirect:publicguidance_reportlist";
	}

	@RequestMapping(value = "updatepublicguidancereport")

	public String updatepublicguidancereport(@ModelAttribute PublicGuidance updatepublicguidancereport,
			final BindingResult result,final RedirectAttributes redirectAttributes) {

		Date createdDate = updatepublicguidancereport.getCreatedDate();
		Integer districtId = updatepublicguidancereport.getDistrictMaster().getDistrictId();
		if (!ipublicservice.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(createdDate);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int year = cal.get(Calendar.YEAR);
		updatepublicguidancereport.setDate(day);
		updatepublicguidancereport.setMonth(month);
		updatepublicguidancereport.setYear(year);
		// System.out.println("date::"+day+"Month:::"+month+"year::"+year);

		ipublicservice.updatepublicguidancereport(updatepublicguidancereport);
		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "User is updated! through");
		System.out.println("dilip");
		return "redirect:publicguidance_reportlist";
		}
		else{
			return null;
		}

	
	}

	@RequestMapping(value = "publicguidance_reportlist")
	public String publicguidance_reportlist(Model model, @ModelAttribute PublicGuidance filteredYear,
			HttpServletRequest request) {
		// PublicGuidance selectedReport = ipublicservice.getId(pgId);
		List<PublicGuidance> publicguidance_reportlist = ipublicservice.getPGAllreport();
		PublicGuidance year = new PublicGuidance();
		PublicGuidance finalmonth = new PublicGuidance();
		model.addAttribute("pubGui", publicguidance_reportlist);
		model.addAttribute("year", year);

		Integer fiYear = filteredYear.getYear();
		Integer currentMonth = filteredYear.getMonth();

		HttpSession session = request.getSession();
		session.setAttribute("fiYear", fiYear);
		session.setAttribute("currentMonth", currentMonth);
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int yearf = cal.get(Calendar.YEAR);
		List<PublicGuidance> filteredYearReports = new ArrayList<PublicGuidance>();
		List<PublicGuidance> filtereMOnthsReports = new ArrayList<PublicGuidance>();
		Map<Integer, Integer> filteredYearAndMonth = new HashMap<Integer, Integer>();
		if (fiYear == null) {
			fiYear = yearf;

		}
		if (currentMonth == null) {
			currentMonth = month;

		}

		List<Integer> availableYears = new ArrayList<Integer>();
		List<Integer> availableMOnths = new ArrayList<Integer>();

		for (PublicGuidance reportYr : publicguidance_reportlist) {
			if (!availableYears.contains(reportYr.getYear())) {
				availableYears.add(reportYr.getYear());
			}
			if (!availableMOnths.contains(reportYr.getMonth())) {
				availableMOnths.add(reportYr.getMonth());
			}
			if (reportYr.getYear().intValue() == fiYear && reportYr.getMonth().intValue() == currentMonth) {
				filteredYearReports.add(reportYr);

			} else {
				System.out.println("else :::dilip");
			}
			if (null != filteredYearReports && !filteredYearReports.isEmpty()) {
				PublicGuidance pgreport = filteredYearReports.get(0);
				if (null != pgreport.getDistrictMaster()) {
					String distName = pgreport.getDistrictMaster().getDistrictName();
					int distId = pgreport.getDistrictMaster().getDistrictId();
					request.getSession().setAttribute("distName", distName);
					request.getSession().setAttribute("distId", distId);
				}
			}
			model.addAttribute("publicguidanceList", filteredYearReports);
			model.addAttribute("availableYears", availableYears);
			model.addAttribute("availableMOnths", availableMOnths);
		}

		return "publicguidance_reportlist";
	}

	
	@RequestMapping(value = "deletePGreport", method = RequestMethod.GET)
	public String deleteEmployee(@RequestParam Integer pgId,final RedirectAttributes redirectAttributes) {
		
		System.out.println("inside delete-------");
	
		ipublicservice.deletePGReport(pgId);
		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "User is deleted!");
		
		return("redirect:publicguidance_reportlist");
	}

	

	@RequestMapping(value = "monthlypublicguidance1")
	public String monthlyPEreport_submit(Model model, @ModelAttribute PublicGuidance filteredYear,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		String distriName = filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		Integer selectedDistrict = 0;
		String districtName = "";
		if (null != filteredYear.getDistrictMaster()) {
			selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
			districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear = filteredYear.getYear();

		List<PublicGuidance> monthlyPEreport = ipublicservice.getPGAllreport();
		PublicGuidance monthlyPEreport1 = monthlyPEreport.get(0);
		model.addAttribute("monthlyPEreport2", monthlyPEreport1);
		List<PublicGuidance> filteredReport = new ArrayList<PublicGuidance>();
		if (null != monthlyPEreport) {
			for (PublicGuidance report : monthlyPEreport) {
				if (selectedYear.intValue() == report.getYear().intValue()) {
					if (null != report.getDistrictMaster()
							&& districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
						
						filteredReport.add(report);
					}
				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyPEreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyPEreport));
		return "monthlypublicguidance1";
	}

	@RequestMapping(value = "monthlypublicguidance")
	public String monthlyPGreport(Model model, @ModelAttribute PublicGuidance filteredYear, HttpServletRequest request,
			@RequestParam Integer pgId) {

		PublicGuidance selectedReport = ipublicservice.getId(pgId);
		System.out.println("ggsdgf dilip" + pgId);
		List<PublicGuidance> monthlyPEreport = ipublicservice.getPGAllreport();
		PublicGuidance monthlyPEreport1 = monthlyPEreport.get(0);
		Integer year = filteredYear.getYear();
		HttpSession session = request.getSession();
		session.setAttribute("year", year);
	
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);

		model.addAttribute("monthlyPEreport", monthlyPEreport);
		model.addAttribute("monthlyPEreport2", monthlyPEreport1);
		List<PublicGuidance> filteredReport = new ArrayList<PublicGuidance>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		if (null != monthlyPEreport) {
			for (PublicGuidance report : monthlyPEreport) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {
						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyPEreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyPEreport));
		return "monthlypublicguidance1";
	}

	// for the pop up
	@RequestMapping(value = "checkmonthpg", method = RequestMethod.POST)
	@ResponseBody
	public String Checkmonth(@RequestParam String date)

	{
		boolean error = false;
		System.out.println("inside pg controller");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		int did = Integer.valueOf(arrOfStr[1]);
		System.out.println(date1 + "" + did);

		String[] arrOfStr1 = date1.split("-");// here we will get the year month
												// and date

		int y = Integer.valueOf(arrOfStr1[0]);
		int m = Integer.valueOf(arrOfStr1[1]);
		System.out.println("month" + m + "year" + y);
		PublicGuidance pg = ipublicservice.getReportByMonthYearDistrict(y, m, did);
		System.out.println("hi" + pg);

		if (pg != null) {
			System.out.println("report present for this month");
			@SuppressWarnings("unused")
			List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

			error = true;
		}
		return "" + error;

	}

	private List<Integer> getUniqueYear(List<PublicGuidance> monthlypublicguidance) {
		List<Integer> years = new ArrayList<Integer>();
		if (null != monthlypublicguidance) {
			for (PublicGuidance pgreport : monthlypublicguidance) {
				if (!years.contains(pgreport.getYear())) {
					years.add(pgreport.getYear());
				}
			}
		}
		return years;
	}

	private List<String> getUniqueDistrictName(List<PublicGuidance> monthlypublicguidance) {
		List<String> districtName = new ArrayList<String>();
		if (null != monthlypublicguidance) {
			for (PublicGuidance pgreport : monthlypublicguidance) {
				if (null != pgreport.getDistrictMaster()
						&& !districtName.contains(pgreport.getDistrictMaster().getDistrictName())) {
					districtName.add(pgreport.getDistrictMaster().getDistrictName());
				}
			}
		}
		return districtName;
	}

	@RequestMapping(value = "ViewMonthReport3")
	public String ViewMonthReport(@RequestParam Integer pgId, Model model) {

		System.out.println("inside ViewMonthReport");
		System.out.println("id" + pgId);
		PublicGuidance district1 = ipublicservice.getId(pgId);
		System.out.println("district" + district1);
		model.addAttribute("district", district1);

		return "ViewMonthReport3";

	}

	@RequestMapping(value = "PublicGuadience_PDF_Report", method = RequestMethod.GET)
	public ModelAndView downloadPdf() {
		List<PublicGuidance> listpublic = ipublicservice.getPGAllreport();

		return new ModelAndView("pdfViewpg", "listpublic", listpublic);
	}

	@RequestMapping(value = "downloadExcelpg", method = RequestMethod.GET)
	public ModelAndView downloadExcel() {
		List<PublicGuidance> listpublice = ipublicservice.getPGAllreport();
		return new ModelAndView("excelViewpg", "listpublice", listpublice);
	}
// after popup update
	@RequestMapping(value = "MonthlyPublicGuadienceReportUpdateMonth")
	public String getDistrictName(@ModelAttribute @Valid PublicGuidance monthlyReport, final BindingResult result,
			@RequestParam String date, Model model)

	{
		System.out.println("test inside monthlyReportUpdate");

		System.out.println("checkmonth");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		String[] arrOfStr1 = date1.split("-");
		int y = Integer.valueOf(arrOfStr1[0]);
		int m = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);
		System.out.println("check did" + did);
		PublicGuidance list = ipublicservice.getReportByMonthYearDistrict(y, m, did);
/*		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "User is updated with id!");*/
		System.out.println("test" + list);
		
		model.addAttribute("updatepg", list);
		return "updatepg";

	}

	// this is for when we change the date while updating
	@RequestMapping(value = "Monthly")
	public String getData(@ModelAttribute @Valid PublicGuidance monthlyReport, final BindingResult result,
			@RequestParam String date, Model model)

	{
		System.out.println("test inside monthly");

		System.out.println("inside edit and update"+date);
		
		String[] arrOfStr = date.split("/");
		
		System.out.println(arrOfStr[0]);

		String date1 = String.valueOf(arrOfStr[0]);
		
		System.out.println(arrOfStr[1]);
		int did = Integer.valueOf(arrOfStr[1]);
		
		
		String[] arrOfStr1 = date1.split("-");
		int y = Integer.valueOf(arrOfStr1[0]);
		int m = Integer.valueOf(arrOfStr1[1]);
		
		
		
		
		System.out.println("check pgid" + did);
		System.out.println("check date1" + date1);


	

		System.out.println("check did" + date1);
	
		PublicGuidance list = ipublicservice.getReportByMonthYearDistrictpgid(y, m,  did);

		System.out.println("test" + list);
		
		model.addAttribute("updatepublicguidancereport", list);
		return "updatepublicguidancereport";

	}
/*	@RequestMapping(value = "task", method = RequestMethod.GET)
	@ResponseBody 
	public List<PublicGuidance> taskList(Map<String, Object> model) {
		PublicGuidance getReport;

		Date createdDate = getReport.getCreatedDate();
		Integer districtId = getReport.getDistrictMaster().getDistrictId();
	    List<PublicGuidance> dtoList = ipublicservice.isReportExistForSelectedMonthAndYear(createdDate, districtId);
	    return dtoList;
	  }*/

}
