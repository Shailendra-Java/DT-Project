package org.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.dto.CdReport;
import org.dto.DistrictMaster;
import org.dto.PEreport;
import org.service.IDistrictService;
import org.service.PEreportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PereportController  {
	
	private static final Logger logger = LoggerFactory.getLogger(PereportController.class);
	@Autowired
	private PEreportService pereportService;
	
	@Autowired
	IDistrictService iDistrictService;
	 
	@InitBinder
	 public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
	     final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
	     binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));    
	 }
	
	@RequestMapping(value="districtPEreport")
	public String district(Model model) {
		
		PEreport districtPEreport= new PEreport();
		model.addAttribute("districtPEreport", districtPEreport);
		return "pe_report";
	}
	
	@RequestMapping("pereportForm")
	public String pereportForm(Model model) {
		
		PEreport pereport= new PEreport();
		model.addAttribute("pereport2",pereport);
		List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);
		return "pereportForm";
	}

	@RequestMapping(value="savePEreport")
	public String savepeform(@ModelAttribute PEreport report,final BindingResult result,Model model,@ModelAttribute("pereport2") @Validated PEreport pereport){
		
		Date createdDate=report.getCreatedDate();
		Integer districtId=report.getDistrictMaster().getDistrictId();
		System.out.println("districtName::"+districtId);
		if(!pereportService.isReportExistForSelectedMonthAndYear(createdDate,districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			report.setDate(day);
			report.setMonth(month);
			report.setYear(year);
			pereportService.saveReport(report);
			return "redirect:pe_report";
		}else {
			logger.info("Record Exists for Selected Month");
			JOptionPane.showMessageDialog(null, "Record Exists for Selected Month");
		}
		return "redirect:pereportForm";
	}
	
	
	@RequestMapping(value="editPEreport")
	public String editPEreport(@RequestParam int id, Model model,HttpServletRequest request){
		
		PEreport pereport= new PEreport();
		PEreport editPereport= pereportService.getReportById(id);
		System.out.println("editPereport::"+editPereport);
		model.addAttribute("editPereport",editPereport);
		return "editPEreport";
	}
	
	@RequestMapping(value="updatePEreport")
	public String updateUser(@RequestParam int peId,@ModelAttribute PEreport updatePEreport, final BindingResult result, HttpServletRequest request,Model model){
		Date sectedDate=updatePEreport.getCreatedDate();
		PEreport editPereport= pereportService.getReportById(peId);
		Integer disID=editPereport.getDistrictMaster().getDistrictId();
		model.addAttribute("editPereport",editPereport);
		
		System.out.println("sectedDate::"+sectedDate+"disIDdisID"+disID);
		if(!pereportService.isReportExistForSelectedMonthAndYearEdit(sectedDate,disID,editPereport)) {
			Date createdDate=updatePEreport.getCreatedDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			updatePEreport.setDate(day);
			updatePEreport.setMonth(month);
			updatePEreport.setYear(year);
			
			pereportService.updatePEreport(updatePEreport);
		}else {
			System.out.println("NOT UPDATED------------------------");
			return "editPEreport";
		}
		return "redirect:pe_report";
	}
	
	@RequestMapping(value="deletePEreport")
	public ModelAndView deleteEmployee(HttpServletRequest request) {
		
	    int pereportID = Integer.parseInt(request.getParameter("id"));
	    pereportService.deletePEReport(pereportID);
	    return new ModelAndView("redirect:pe_report");
	}
		
	@RequestMapping(value = "monthlyPEreportDist")
	public String monthlyPEreportDist( Model model) {
	
		PEreport monthlyPereport= new PEreport();
		model.addAttribute("monthlyPereport",monthlyPereport);
		return "redirect:monthlyPEreport";
	}
		
	@RequestMapping(value="pe_report")
	public String pereoprt(Model model,@ModelAttribute PEreport filteredYear,HttpServletRequest request){
		
		List<PEreport> pereportList=pereportService.getPEAllreport();
		PEreport year=new PEreport();
		PEreport finalmonth= new PEreport();
		model.addAttribute("pereportList", pereportList);
		model.addAttribute("year", year);
	
		Integer fiYear=filteredYear.getYear();
		Integer currentMonth=filteredYear.getMonth();
		
		HttpSession session=request.getSession();
		session.setAttribute("fiYear", fiYear);
		
		session.setAttribute("currentMonthToDisplay",String.valueOf(currentMonth));
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int yearf = cal.get(Calendar.YEAR);
		if(null== currentMonth) {
			//First Time value
			currentMonth = month;
		}
		session.setAttribute("currentMonth", currentMonth);
		List<PEreport> filteredYearReports = new ArrayList<PEreport>();
		List<PEreport> filtereMOnthsReports = new ArrayList<PEreport>();
		Map<Integer, Integer> filteredYearAndMonth= new HashMap<Integer, Integer>();
		if(fiYear == null ) {
			fiYear = yearf;
			
		}
		if(currentMonth == null ) {
			currentMonth = month;
			
		}
		
		List<Integer> availableYears = new ArrayList<Integer>();
		List<Integer> availableMOnths = new ArrayList<Integer>();
		
		for(PEreport reportYr: pereportList) {
			if(!availableYears.contains(reportYr.getYear()) ) {
				availableYears.add(reportYr.getYear());
			}
			if(!availableMOnths.contains(reportYr.getMonth()) ) {
				availableMOnths.add(reportYr.getMonth());
			}
			if(reportYr.getYear().intValue()==fiYear && reportYr.getMonth().intValue()==currentMonth) {
				filteredYearReports.add(reportYr);
				
			}else {
				System.out.println("else :::");
			}
		if(null != filteredYearReports && !filteredYearReports.isEmpty()) {
			PEreport preport = filteredYearReports.get(0);
			if(null != preport.getDistrictMaster()) {
			  String distName = preport.getDistrictMaster().getDistrictName();
			  int distId = preport.getDistrictMaster().getDistrictId();
			  request.getSession().setAttribute("distName", distName);
			  request.getSession().setAttribute("distId", distId);			  
			}
		}
		availableYears = getAllAvailableYears(availableYears,yearf);
		model.addAttribute("pereportList", filteredYearReports);
		model.addAttribute("availableYears", availableYears);
		model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));
		//model.addAttribute("availableMonthsForDisplay", getAvailableMonthsForDisplay(availableMOnths));
		}
		return "pe_report";
	}
	private List<Integer> getAvailableMonths(List<Integer> availableMOnths){
		
		if(null != availableMOnths) {
			if(!availableMOnths.contains(1)) {
				availableMOnths.add(1);
			}
			if(!availableMOnths.contains(2)) {
				availableMOnths.add(2);
			}
			if(!availableMOnths.contains(3)) {
				availableMOnths.add(3);
			}
			if(!availableMOnths.contains(4)) {
				availableMOnths.add(4);
			}
			if(!availableMOnths.contains(5)) {
				availableMOnths.add(5);
			}
			if(!availableMOnths.contains(6)) {
				availableMOnths.add(6);
			}
			if(!availableMOnths.contains(7)) {
				availableMOnths.add(7);
			}
			if(!availableMOnths.contains(8)) {
				availableMOnths.add(8);
			}
			if(!availableMOnths.contains(9)) {
				availableMOnths.add(9);
			}
			if(!availableMOnths.contains(10)) {
				availableMOnths.add(10);
			}
			if(!availableMOnths.contains(11)) {
				availableMOnths.add(11);
			}			
			if(!availableMOnths.contains(12)) {
				availableMOnths.add(12);
			}
		}
		return availableMOnths;
	}
    private List<Integer> getAllAvailableYears(List<Integer> availableYears,int yearf){
    	if(availableYears.size() < 10) {
    		for(int i= availableYears.size() ; i<10;i++) {
    			if(!availableYears.contains(yearf)) {
    			   availableYears.add(yearf);    			  
    			}
    			yearf --;
    		}
    	}
    	return availableYears;
    }
	@RequestMapping(value="monthlyPEreport")
	public String monthlyPEreport(Model model,@ModelAttribute PEreport filteredYear,HttpServletRequest request,@RequestParam int id) {
	
		PEreport selectedReport = pereportService.getReportById(id);
		List<PEreport> monthlyPEreport = pereportService.getPEAllreport();	
		PEreport monthlyPEreport1= monthlyPEreport.get(0);
		Integer year=filteredYear.getYear();
		HttpSession session=request.getSession();
		session.setAttribute("year", year);
		String distriName=selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		
		model.addAttribute("monthlyPEreport", monthlyPEreport);
		model.addAttribute("monthlyPEreport1", monthlyPEreport1);
		List<PEreport>  filteredReport = new ArrayList<PEreport>();
		int selectedYear = 0 ;
		int selectedDistrict = 0 ;
		if(null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}
		
		if(null != monthlyPEreport) {
			for(PEreport report:monthlyPEreport) {
				if(selectedYear == report.getYear()) {
				  if(selectedDistrict > 0) {
					  
					  if(null !=  report.getDistrictMaster() &&
							  selectedDistrict == report.getDistrictMaster().getDistrictId()) {
						  filteredReport.add(report);
					  }
				  }else {					
					  if(null !=  report.getDistrictMaster()) {
						  selectedDistrict =  report.getDistrictMaster().getDistrictId();	
								filteredReport.add(report);
					  }
				  }
				
				}
			}
		}
		model.addAttribute("filteredReport",filteredReport);
		model.addAttribute("uniqueyears",getUniqueYear(monthlyPEreport));
		model.addAttribute("uniqueDistrictNames",getUniqueDistrictName(monthlyPEreport));
		return "monthlyPEreport";
	}
	
	@RequestMapping(value="monthlyPEreport_submit")
	public String monthlyPEreport_submit(Model model,@ModelAttribute PEreport filteredYear,HttpServletRequest request) {
		HttpSession session=request.getSession();
		String distriName=filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		Integer selectedDistrict = 0 ;
		String districtName = "";
		if(null != filteredYear.getDistrictMaster()) {
		   selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
		   districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear=filteredYear.getYear();
		
		List<PEreport> monthlyPEreport = pereportService.getPEAllreport();	
		PEreport monthlyPEreport1= monthlyPEreport.get(0);
		model.addAttribute("monthlyPEreport1", monthlyPEreport1);
		List<PEreport>  filteredReport = new ArrayList<PEreport>();		
		if(null != monthlyPEreport) {
			for(PEreport report:monthlyPEreport) {
				if(selectedYear.intValue() == report.getYear().intValue() ) {
					 if(null !=  report.getDistrictMaster() && 
							 districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
						 //&&  selectedDistrict == report.getDistrictMaster().getDistrictId()
						  filteredReport.add(report);
					  }
				}
			}
		}
		model.addAttribute("filteredReport",filteredReport);
		model.addAttribute("uniqueyears",getUniqueYear(monthlyPEreport));
		model.addAttribute("uniqueDistrictNames",getUniqueDistrictName(monthlyPEreport));
		return "monthlyPEreport";
	}
	

	private List<Integer> getUniqueYear(List<PEreport> monthlyPEreport){
	 List<Integer> years = new  ArrayList<Integer>();
	 if(null != monthlyPEreport) {
		 for(PEreport report:monthlyPEreport) {
			if(!years.contains(report.getYear())) {
				years.add(report.getYear());
			}
		 }
	 }
	 return years;		 
}
	private List<String> getUniqueDistrictName(List<PEreport> monthlyPEreport){
	 List<String> districtName = new  ArrayList<String>();
	 if(null != monthlyPEreport) {
		 for(PEreport report:monthlyPEreport) {
			if(null != report.getDistrictMaster() && 
					!districtName.contains(report.getDistrictMaster().getDistrictName())) {
				districtName.add(report.getDistrictMaster().getDistrictName());
			}
		 }
	 }
	 return districtName;		 
}
	@RequestMapping("/editMonthlyPEreport")
	public  String editMonthlyPEreport(Model model,@RequestParam int id) {
		
		PEreport pereport= new PEreport();
		PEreport editMonthlyReport=pereportService.getReportById(id);
		//model.addAttribute("pereport", pereport);
		model.addAttribute("editMonthlyReport", editMonthlyReport);
		return "editMonthlyPEreport";
}
	@RequestMapping("updateMonthlyPEReport")
	
	public String updateMonthlyPEReport(@RequestParam int peId,@ModelAttribute PEreport updatePEreport, final BindingResult result, HttpServletRequest request,Model model){
		
		Date sectedDate=updatePEreport.getCreatedDate();
		PEreport editPereport= pereportService.getReportById(peId);
		Integer disID=editPereport.getDistrictMaster().getDistrictId();
		System.out.println("inside the updateMonthly::"+sectedDate+"id::"+editPereport+"disID::"+disID);
		List<PEreport> monthlyPEreport = pereportService.getPEAllreport();	
		PEreport monthlyPEreport1= monthlyPEreport.get(0);
		PEreport pereport= new PEreport();
		model.addAttribute("pereport", pereport);
		if(!pereportService.isReportExistForSelectedMonthAndYearEdit(sectedDate,disID,editPereport)) {
			Date createdDate=updatePEreport.getCreatedDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			updatePEreport.setDate(day);
			updatePEreport.setMonth(month);
			updatePEreport.setYear(year);
			
			pereportService.updatePEreport(updatePEreport);
		}else {
			System.out.println("NOT UPDATED------------SUCCESS!!!------------");
		}
		//return "redirect:pereport";
		return "redirect:pe_report";
	}
	
	@RequestMapping(value = "ViewMonthReport2")
	public String ViewMonthReport(@RequestParam Integer peId, Model model) {

		System.out.println("inside ViewMonthReport");
		System.out.println("id" + peId);
		PEreport district1 = pereportService.getReportById(peId);
		System.out.println("district" + district1);
		model.addAttribute("district", district1);

		return "ViewMonthReport2";

	}	
	
	@RequestMapping(value = "PEReport_pdf", method = RequestMethod.GET)
	public ModelAndView downloadPdf(){
		List<PEreport> listattendance2=pereportService.getPEAllreport();
		
		return new ModelAndView("pdfViewpe","listattendance2",listattendance2);
	}

	@RequestMapping(value = "PEReport_excell", method = RequestMethod.GET)
	public ModelAndView downloadExcel() {
		List<PEreport> listattendance2=pereportService.getPEAllreport();
	    return new ModelAndView("excelViewpe","listattendance2",listattendance2);
	}
	//PEReportChart Controller
	  @RequestMapping(value = "/PEReport_chart", produces =
	  "application/json") public String MonthchartReport(Model
	  model, @ModelAttribute PEreport filteredYear, HttpServletRequest
	  request) {
	  
	  System.out.println("inside PEreport"
	  		+ "ChartReport"); System.out.println("id");
	  List<PEreport> district1 = pereportService.getPEAllreport();
	  
	  List<String> availableDistrict = new ArrayList<String>(); List<Integer>
	  availablefield = new ArrayList<Integer>(); for (PEreport mr :
	  district1) { if
	  (!(availableDistrict.contains(mr.getDistrictMaster().getDistrictName()))) {
	  availableDistrict.add(mr.getDistrictMaster().getDistrictName()); }
	  
	  if (!availablefield.contains(mr.getPeId())) {
	  availablefield.add(mr.getPeId()); } }
	  
	  System.out.println("district" + district1); model.addAttribute("district",
	  district1); System.out.println("availablefield" + availablefield);
	  model.addAttribute("availablefield", availablefield);
	  System.out.println("availableDistrict" + availableDistrict);
	  model.addAttribute("availableDistrict", availableDistrict);
	  
	  Map<String, Integer> map = new LinkedHashMap<>();
	  
	  for (int i = 0; i < availableDistrict.size(); i++) {
	  map.put(availableDistrict.get(i), availablefield.get(i)); // is // there // a
	  // clearer // way?
	  
	  }
	  
	  System.out.println("map" + map); model.addAttribute("map", map);
	  
	  return "pe_report"; 
	  }
	 
	
	@RequestMapping(value = "pereportcheckmonth",method=RequestMethod.POST)
	@ResponseBody
	public String dateCheck(@RequestParam String date){
		boolean error= false;
		System.out.println("inside checkDate method");
		String[] arrOfStr = date.split("/");
		 String date1 =String.valueOf(arrOfStr[0]);
		int did = Integer.valueOf(arrOfStr[1]);
		System.out.println(date1+""+did);
		String[] arrOfStr1 = date1.split("-");
		int y=Integer.valueOf(arrOfStr1[0]);
		int m=Integer.valueOf(arrOfStr1[1]);
		System.out.println("month"+m+"year"+y);
		
		PEreport att=pereportService.getReportByMonthYearDistrict(m, y, did);
		System.out.println("hi" + att);
		
		if(att!=null){
			System.out.println("report present for this month");
			@SuppressWarnings("unused")
			List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

			error = true;
		}
		return "" + error;
		
	}
	
	@RequestMapping(value = "PEAllReportUpdate")
	public String getDistrictName(@ModelAttribute @Valid PEreport monthlyReport, final BindingResult result,
			@RequestParam String date, Model model)

	{
		System.out.println("test inside monthlyReportUpdate");

		System.out.println("checkmonth");
		String[] arrOfStr = date.split("/");
		
		
		   String date1 =String.valueOf(arrOfStr[0]);
		   String[] arrOfStr1 = date1.split("-");
		   int y =Integer.valueOf(arrOfStr1[0]);
		   int m =Integer.valueOf(arrOfStr1[1]);

			int did = Integer.valueOf(arrOfStr[1]);
			
			
			System.out.println("check did" + did);
			System.out.println("check did" + date1);
		System.out.println("check did" + did);
		PEreport list = pereportService.getMonthlyreportAll(y, did, m);

		System.out.println("test" + list);
		// model.put("monthlyReportAll", list);
		model.addAttribute("update", list);
		return "updatepereport";

	}
	
}
