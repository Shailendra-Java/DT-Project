package org.controller;

import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.dto.DistrictMaster;
import org.dto.SubscriptionMaster;
import org.service.IDistrictService;
import org.service.ISubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SubscriptionController {

	@Autowired
	ISubscriptionService subcriptionService;

	@Autowired
	IDistrictService iDistrictService;

	@InitBinder
	public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "districtSubscription")
	public String district(Model model) {

		SubscriptionMaster districtSubscriptionMaster = new SubscriptionMaster();
		model.addAttribute("districtSubscriptionMaster", districtSubscriptionMaster);
		return "subscriptionlist";
	}

	@RequestMapping(value = "add_subcription")
	public String CreateSubscription(Model model) {
		System.out.println("add_district");
		SubscriptionMaster subscription = new SubscriptionMaster();

		model.addAttribute("subscription", subscription);

		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		System.out.println("hello world ");

		return "createsubcription";
	}

	@RequestMapping(value = "savesubscription")
	public String saveSubscription(@ModelAttribute SubscriptionMaster subscribe, final BindingResult result,
			Model model, @ModelAttribute("subscription") @Validated SubscriptionMaster subscription) {
		System.out.println("inside savesubscription method ");
		Date createdDate = subscribe.getCreatedDate();
		Integer districtId = subscribe.getDistrictMaster().getDistrictId();
		System.out.println("districtName::" + districtId);
		if (!subcriptionService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			subscribe.setDate(day);
			subscribe.setMonth(month);
			subscribe.setYear(year);
			subscribe.getMonth();
			subcriptionService.savesubscription(subscribe);
			return "redirect:subscriptionlist";
		} else {
			System.out.println("Record Exists for Selected Month");
		}
		return "redirect:createsubscription";
	}

	/*
	 * @RequestMapping(value="subscriptionlist") public String userList(Model model)
	 * { List<SubscriptionMaster>
	 * subscribe=subcriptionService.getSubscriptionList();
	 * model.addAttribute("subscribe", subscribe); return "subscriptionlist"; }
	 */
	@RequestMapping(value = "subscriptionlist")
	public String subscriptionlist(Model model, @ModelAttribute SubscriptionMaster filteredYear,
			HttpServletRequest request) {

		System.out.println("inside subscriptionlist method");
		List<SubscriptionMaster> subscription = subcriptionService.getAllSubscription();
		System.out.println("inside subscriptionlist method111" + subscription);
		SubscriptionMaster year = new SubscriptionMaster();
		SubscriptionMaster finalmonth = new SubscriptionMaster();
		model.addAttribute("subscriptionlist", subscription);
		model.addAttribute("year", year);

		Integer fiYear = filteredYear.getYear();
		Integer currentMonth = filteredYear.getMonth();

		HttpSession session = request.getSession();
		session.setAttribute("fiYear", fiYear);
		session.setAttribute("currentMonth", currentMonth);
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int yearf = cal.get(Calendar.YEAR);

		List<SubscriptionMaster> filteredYearReports = new ArrayList<SubscriptionMaster>();
		List<SubscriptionMaster> filtereMOnthsReports = new ArrayList<SubscriptionMaster>();
		Map<Integer, Integer> filteredYearAndMonth = new HashMap<Integer, Integer>();
		if (fiYear == null) {
			fiYear = yearf;

		}
		if (currentMonth == null) {
			currentMonth = month;

		}

		List<Integer> availableYears = new ArrayList<Integer>();
		List<Integer> availableMOnths = new ArrayList<Integer>();
		for (SubscriptionMaster reportYr : subscription) {
			if (!availableYears.contains(reportYr.getYear())) {
				availableYears.add(reportYr.getYear());
			}
			if (!availableMOnths.contains(reportYr.getMonth())) {
				availableMOnths.add(reportYr.getMonth());
			}
			if (reportYr.getYear().intValue() == fiYear && reportYr.getMonth().intValue() == currentMonth) {
				filteredYearReports.add(reportYr);

			} else {
				System.out.println("else :::");
			}
			if (null != filteredYearReports && !filteredYearReports.isEmpty()) {
				SubscriptionMaster subscription1 = filteredYearReports.get(0);
				if (null != subscription1.getDistrictMaster()) {
					String distName = subscription1.getDistrictMaster().getDistrictName();
					int distId = subscription1.getDistrictMaster().getDistrictId();
					request.getSession().setAttribute("distName", distName);
					request.getSession().setAttribute("distId", distId);
				}
			}
			availableYears = getAllAvailableYears(availableYears, yearf);
			model.addAttribute("subscriptionlist", filteredYearReports);
			model.addAttribute("availableYears", availableYears);
			model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));
			// availableMOnths=getAvailableMonths(availableMOnths);
			// model.addAttribute("availableMonthsForDisplay",
			// getAvailableMonthsForDisplay(availableMOnths));
		}
		return "subscriptionlist";

	}

	private List<Integer> getAvailableMonths(List<Integer> availableMOnths) {

		if (null != availableMOnths) {
			if (!availableMOnths.contains(1)) {
				availableMOnths.add(1);
			}
			if (!availableMOnths.contains(2)) {
				availableMOnths.add(2);
			}
			if (!availableMOnths.contains(3)) {
				availableMOnths.add(3);
			}
			if (!availableMOnths.contains(4)) {
				availableMOnths.add(4);
			}
			if (!availableMOnths.contains(5)) {
				availableMOnths.add(5);
			}
			if (!availableMOnths.contains(6)) {
				availableMOnths.add(6);
			}
			if (!availableMOnths.contains(7)) {
				availableMOnths.add(7);
			}
			if (!availableMOnths.contains(8)) {
				availableMOnths.add(8);
			}
			if (!availableMOnths.contains(9)) {
				availableMOnths.add(9);
			}
			if (!availableMOnths.contains(10)) {
				availableMOnths.add(10);
			}
			if (!availableMOnths.contains(11)) {
				availableMOnths.add(11);
			}
			if (!availableMOnths.contains(12)) {
				availableMOnths.add(12);
			}
		}
		return availableMOnths;
	}

	private List<Integer> getAllAvailableYears(List<Integer> availableYears, int yearf) {
		if (availableYears.size() < 10) {
			for (int i = availableYears.size(); i < 10; i++) {
				if (!availableYears.contains(yearf)) {
					availableYears.add(yearf);
				}
				yearf--;
			}
		}
		return availableYears;
	}

	@RequestMapping(value = "viewSubscription")

	public String viewSubscription(Model model, @RequestParam long id) {

		SubscriptionMaster subscription = new SubscriptionMaster();
		SubscriptionMaster view = subcriptionService.getSubscriptionById(id);
		model.addAttribute("view", view);
		return "viewSubscription";
	}

	@RequestMapping(value = "editSubscription")

	public String editSubscription(@RequestParam long id, Model model, HttpServletRequest request) {

		// SubscriptionMaster subscription = new SubscriptionMaster();

		SubscriptionMaster editSubscription = subcriptionService.getSubscriptionById(id);
		System.out.println(" editSubscription ::" + editSubscription);
		model.addAttribute("editSubscription", editSubscription);

		return "editSubscription";

	}

	@RequestMapping(value = "updateSubscription")
	public String updateSubscription(@RequestParam long subId, @ModelAttribute SubscriptionMaster updateSubscription,
			final BindingResult result, HttpServletRequest request, Model model) {
		Date sectedDate = updateSubscription.getCreatedDate();
		SubscriptionMaster editSubscription = subcriptionService.getSubscriptionById(subId);
		Integer disID = editSubscription.getDistrictMaster().getDistrictId();
		model.addAttribute("editSubscription", editSubscription);

		System.out.println("sectedDate::" + sectedDate + "disIDdisID" + disID);
		if (!subcriptionService.isReportExistForSelectedMonthAndYearEdit(sectedDate, disID, editSubscription)) {
			Date createdDate = updateSubscription.getCreatedDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			updateSubscription.setDate(day);
			updateSubscription.setMonth(month);
			updateSubscription.setYear(year);

			subcriptionService.updateSubscription(updateSubscription);
		} else {
			System.out.println("NOT UPDATED------------------------");
			return "editSubscription";
		}
		return "redirect:subscriptionlist";
	}

	@RequestMapping(value = "deleteSubscription")
	public ModelAndView deleteEmployee(HttpServletRequest request) {
		long subscriptionId = Integer.parseInt(request.getParameter("id"));
		subcriptionService.deleteSubscription(subscriptionId);
		System.out.println("Report deleted successfully");

		return new ModelAndView("redirect:subscriptionlist");
	}

	@RequestMapping(value = "monthlySubscription")
	public String monthlySubscription(Model model, @ModelAttribute SubscriptionMaster filteredYear,
			HttpServletRequest request, @RequestParam long id) {

		SubscriptionMaster selectedReport = subcriptionService.getSubscriptionById(id);
		List<SubscriptionMaster> monthlySub = subcriptionService.getSubscriptionList();
		SubscriptionMaster monthlySub1 = monthlySub.get(0);
		Integer year = filteredYear.getYear();

		String m = null;

		for (SubscriptionMaster monthlySub2 : monthlySub) {
			int month = monthlySub2.getMonth();

			m = Month.of(month).name();
			System.out.println("month" + m);

		}

		HttpSession session = request.getSession();
		session.setAttribute("year", year);
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);

		model.addAttribute("monthlySub", monthlySub);
		model.addAttribute("monthlySub1", monthlySub1);

		List<SubscriptionMaster> filteredReport = new ArrayList<SubscriptionMaster>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		if (null != monthlySub) {
			for (SubscriptionMaster sub : monthlySub) {
				if (selectedYear == sub.getYear()) {
					if (selectedDistrict > 0) {

						if (null != sub.getDistrictMaster()
								&& selectedDistrict == sub.getDistrictMaster().getDistrictId()) {
							filteredReport.add(sub);
						}
					} else {
						if (null != sub.getDistrictMaster()) {
							selectedDistrict = sub.getDistrictMaster().getDistrictId();
							filteredReport.add(sub);
						}
					}

				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlySub));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlySub));
		return "monthlySubscription";
	}

	@RequestMapping(value = "monthlySubscription_submit")
	public String monthlySubscription_submit(Model model, @ModelAttribute SubscriptionMaster filteredYear,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		String distriName = filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		Integer selectedDistrict = 0;
		String districtName = "";
		if (null != filteredYear.getDistrictMaster()) {
			selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
			districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear = filteredYear.getYear();

		List<SubscriptionMaster> monthlySub = subcriptionService.getAllSubscription();
		SubscriptionMaster monthlySub1 = monthlySub.get(0);
		model.addAttribute("monthlySub1", monthlySub1);
		List<SubscriptionMaster> filteredReport = new ArrayList<SubscriptionMaster>();
		if (null != monthlySub1) {
			for (SubscriptionMaster sub : monthlySub) {
				if (selectedYear.intValue() == sub.getYear().intValue()) {
					if (null != sub.getDistrictMaster()
							&& districtName.equalsIgnoreCase(sub.getDistrictMaster().getDistrictName())) {
						// && selectedDistrict == report.getDistrictMaster().getDistrictId()
						filteredReport.add(sub);
					}
				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlySub));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlySub));
		return "monthlySubscription";
	}

	private Object getUniqueDistrictName(List<SubscriptionMaster> monthlySub) {
		List<String> districtName = new ArrayList<String>();
		if (null != monthlySub) {
			for (SubscriptionMaster sub : monthlySub) {
				if (null != sub.getDistrictMaster()
						&& !districtName.contains(sub.getDistrictMaster().getDistrictName())) {
					districtName.add(sub.getDistrictMaster().getDistrictName());
				}
			}
		}
		return districtName;

	}

	private Object getUniqueYear(List<SubscriptionMaster> monthlySub) {
		List<Integer> years = new ArrayList<Integer>();
		if (null != monthlySub) {

			for (SubscriptionMaster sub : monthlySub) {
				if (!years.contains(sub.getYear())) {
					years.add(sub.getYear());
				}
			}
		}
		return years;

	}

	@RequestMapping("/editMonthlySubscription")
	public String editMonthlySubscription(Model model, @RequestParam long id) {

		SubscriptionMaster subscription = new SubscriptionMaster();
		SubscriptionMaster editMonthlySubscription = subcriptionService.getSubscriptionById(id);
		model.addAttribute("editMonthlySubscription", editMonthlySubscription);
		return "editMonthlySubscription";
	}

	@RequestMapping("updateMonthlySubscription")

	public String updateMonthlySubscription(@RequestParam long subId,
			@ModelAttribute SubscriptionMaster updateSubscription, final BindingResult result,
			HttpServletRequest request, Model model) {

		Date sectedDate = updateSubscription.getCreatedDate();
		SubscriptionMaster editSubscription = subcriptionService.getSubscriptionById(subId);
		Integer disID = editSubscription.getDistrictMaster().getDistrictId();
		System.out.println("inside the updateMonthly::" + sectedDate + "id::" + editSubscription + "disID::" + disID);
		List<SubscriptionMaster> monthlySubscription = subcriptionService.getAllSubscription();
		SubscriptionMaster monthlySubscription1 = monthlySubscription.get(0);
		SubscriptionMaster subscription = new SubscriptionMaster();
		model.addAttribute("subscription", subscription);
		if (!subcriptionService.isReportExistForSelectedMonthAndYearEdit(sectedDate, disID, editSubscription)) {
			Date createdDate = updateSubscription.getCreatedDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			updateSubscription.setDate(day);
			updateSubscription.setMonth(month);
			updateSubscription.setYear(year);

			subcriptionService.updateSubscription(updateSubscription);
		} else {
			System.out.println("Not Updated Successfully---!!!------------");
		}

		return "redirect:subscriptionlist";
	}

	@ResponseBody
	@RequestMapping(value = "checkDateDistrictName", method = RequestMethod.POST)

	public String checkDateDistrictName(@RequestParam String date) {

		boolean error = false;
		System.out.println("inside checkDateDistrictName method");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);

		String[] arrOfStr1 = date1.split("-");
		int year = Integer.valueOf(arrOfStr1[0]);
		int month = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);

		SubscriptionMaster subscription = subcriptionService.getMonthlyReportByMonthYearDistrict(year, month, did);
		System.out.println("cd" + subscription);

		if (subscription != null) {
			System.out.println("Report is allready exist for the selected date and district");

			List<DistrictMaster> distList = iDistrictService.getDistrictMasterList();

			error = true;

		}
		System.out.println("check2");

		return "" + error;

	}

	@RequestMapping(value = "subscriptionUpdate")
	public String getDistrictName(@ModelAttribute @Valid SubscriptionMaster subscription, final BindingResult result,
			@RequestParam String date, Model model)

	{
		System.out.println("test inside subscriptionUpdate");

		System.out.println("checkDate");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);

		String[] arrOfStr1 = date1.split("-");
		int year = Integer.valueOf(arrOfStr1[0]);
		int month = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);

		SubscriptionMaster sublist = subcriptionService.getMonthlyReportByMonthYearDistrict(year, month, did);
		System.out.println("test" + sublist);
		// model.put("monthlyReportAll", list);
		model.addAttribute("update", sublist);
		return "subscriptionUpdate";

	}

	@RequestMapping(value = "subscriptionPdf", method = RequestMethod.GET)
	public ModelAndView downloadSubscription() {
		List<SubscriptionMaster> subscription = subcriptionService.getAllSubscription();

		return new ModelAndView("subscriptionpdf", "subscription", subscription);
	}

	@RequestMapping(value = "subscriptionExcel", method = RequestMethod.GET)
	public ModelAndView downloadExcelSubscription() {
		List<SubscriptionMaster> subscription = subcriptionService.getAllSubscription();
		return new ModelAndView("subscriptionexcel", "subscription", subscription);
	}

}