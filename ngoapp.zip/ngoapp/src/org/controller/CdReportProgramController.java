package org.controller;

import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.dto.CdReportProgram;
import org.dto.DistrictMaster;
import org.service.CdReportProgramService;
import org.service.IDistrictService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@SuppressWarnings("unused")
@Controller
public class CdReportProgramController {
	private static final Logger logger = LoggerFactory.getLogger(CdReportProgramController.class);

	@Autowired
	private CdReportProgramService cdReportPgmService;

	@Autowired
	IDistrictService iDistrictService;

	@InitBinder
	public final void initBinderUsuariosFormValidator(final WebDataBinder binder, final Locale locale) {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", locale);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "districtCdReportPgm")
	public String district(Model model) {

		CdReportProgram districtCdReportProgram = new CdReportProgram();
		model.addAttribute("districtCdReportProgram", districtCdReportProgram);
		return "cdreportprogramlist";
	}

	@RequestMapping("cdreportprogram")
	public String cdReportprogram(Model model) {
		System.out.println("inside cdreportprogram");

		CdReportProgram cdReportProgram = new CdReportProgram();
		model.addAttribute("cdreport2", cdReportProgram);
		List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);
		System.out.println("inside cdreportprogram");
		return "cdreportprogram";
	}

	@RequestMapping(value = "savereport")
	public String savecdform(@ModelAttribute CdReportProgram report, final BindingResult result, Model model,
			@ModelAttribute("cdreport2") @Validated CdReportProgram cdreport, final RedirectAttributes redirectAttributes) {

		Date createdDate = report.getCreatedDate();
		Integer districtId = report.getDistrictMaster().getDistrictId();
		System.out.println("districtName::" + districtId);
		if (!cdReportPgmService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			report.setDate(day);
			report.setMonth(month);
			report.setYear(year);
			report.getMonth();
			cdReportPgmService.saveReport(report);
			redirectAttributes.addFlashAttribute("css", "success");
			redirectAttributes.addFlashAttribute("msg", "Record added successfully!");
			return "redirect:cdreportprogramlist";
		} else {
			model.addAttribute("Error", "Record Exists for Selected Month and year");

			System.out.println("Record Exists for Selected Month and year");

		}
		return "redirect:cdreportprogram";
	}

	@RequestMapping(value = "editCDreportprogram")
	public String editCDreportprogram(@RequestParam int id, Model model, HttpServletRequest request) {

		CdReportProgram cdReportProgram = new CdReportProgram();
		CdReportProgram editCDCdReportProgram = cdReportPgmService.getReportById(id);
		System.out.println("editCDCdReportProgram::" + editCDCdReportProgram);
		model.addAttribute("editCDCdReportProgram", editCDCdReportProgram);
		return "editCDreportprogram";

	}

	@RequestMapping(value = "updateCDreportprogram")
	public String updateCDreportprogram(@RequestParam int cdId, @ModelAttribute CdReportProgram updateCDreportprogram,
			final BindingResult result, HttpServletRequest request, Model model, final RedirectAttributes redirectAttributes) {
		Date sectedDate = updateCDreportprogram.getCreatedDate();
		CdReportProgram editCdreportprogram = cdReportPgmService.getReportById(cdId);
		Integer disID = editCdreportprogram.getDistrictMaster().getDistrictId();
		model.addAttribute("editCdreportprogram", editCdreportprogram);

		System.out.println("sectedDate::" + sectedDate + "disIDdisID" + disID);
		if (!cdReportPgmService.isReportExistForSelectedMonthAndYearEdit(sectedDate, disID, editCdreportprogram)) {
			Date createdDate = updateCDreportprogram.getCreatedDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			updateCDreportprogram.setDate(day);
			updateCDreportprogram.setMonth(month);
			updateCDreportprogram.setYear(year);

			cdReportPgmService.updateCDreportprogram(updateCDreportprogram);
			redirectAttributes.addFlashAttribute("css", "success");
			redirectAttributes.addFlashAttribute("msg", "Record updated successfully!");
		} else {
			System.out.println("NOT UPDATED------------------------");
			return "editCDreportprogram";
		}
		return "redirect:cdreportprogramlist";
	}

	@RequestMapping(value = "monthlyCDreportprogramDist")
	public String monthlyCDreportprogramDist(Model model) {
		CdReportProgram monthlyCdreportprogram = new CdReportProgram();
		model.addAttribute("monthlyCdreportprogram", monthlyCdreportprogram);
		return "redirect:monthlyCdreportprogram";

	}

	@RequestMapping(value = "cdreportprogramlist")
	public String cdreportprogramlist(Model model, @ModelAttribute CdReportProgram filteredYear,
			HttpServletRequest request) {

		System.out.println("inside cdreportprogramlist method");
		List<CdReportProgram> cdreportprogram = cdReportPgmService.getAllCDreportprogram();
		System.out.println("inside cdreportprogramlist method111" + cdreportprogram);
		CdReportProgram year = new CdReportProgram();
		CdReportProgram finalmonth = new CdReportProgram();
		model.addAttribute("cdreportprogramList", cdreportprogram);
		model.addAttribute("year", year);

		Integer fiYear = filteredYear.getYear();
		Integer currentMonth = filteredYear.getMonth();

		HttpSession session = request.getSession();
		session.setAttribute("fiYear", fiYear);
		session.setAttribute("currentMonth", currentMonth);
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int yearf = cal.get(Calendar.YEAR);

		List<CdReportProgram> filteredYearReports = new ArrayList<CdReportProgram>();
		List<CdReportProgram> filtereMOnthsReports = new ArrayList<CdReportProgram>();
		Map<Integer, Integer> filteredYearAndMonth = new HashMap<Integer, Integer>();
		if (fiYear == null) {
			fiYear = yearf;

		}
		if (currentMonth == null) {
			currentMonth = month;

		}

		List<Integer> availableYears = new ArrayList<Integer>();
		List<Integer> availableMOnths = new ArrayList<Integer>();
		for (CdReportProgram reportYr : cdreportprogram) {
			if (!availableYears.contains(reportYr.getYear())) {
				availableYears.add(reportYr.getYear());
			}
			if (!availableMOnths.contains(reportYr.getMonth())) {
				availableMOnths.add(reportYr.getMonth());
			}
			if (reportYr.getYear().intValue() == fiYear && reportYr.getMonth().intValue() == currentMonth) {
				filteredYearReports.add(reportYr);

			} else {
				System.out.println("else :::");
			}
			if (null != filteredYearReports && !filteredYearReports.isEmpty()) {
				CdReportProgram cdreportprogram1 = filteredYearReports.get(0);
				if (null != cdreportprogram1.getDistrictMaster()) {
					String distName = cdreportprogram1.getDistrictMaster().getDistrictName();
					int distId = cdreportprogram1.getDistrictMaster().getDistrictId();
					request.getSession().setAttribute("distName", distName);
					request.getSession().setAttribute("distId", distId);
				}
			}
			availableYears = getAllAvailableYears(availableYears, yearf);
			model.addAttribute("cdreportprogramList", filteredYearReports);
			model.addAttribute("availableYears", availableYears);
			model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));
			// availableMOnths=getAvailableMonths(availableMOnths);
			// model.addAttribute("availableMonthsForDisplay",
			// getAvailableMonthsForDisplay(availableMOnths));
		}
		return "cdreportprogramlist";

	}

	private List<Integer> getAvailableMonths(List<Integer> availableMOnths) {

		if (null != availableMOnths) {
			if (!availableMOnths.contains(1)) {
				availableMOnths.add(1);
			}
			if (!availableMOnths.contains(2)) {
				availableMOnths.add(2);
			}
			if (!availableMOnths.contains(3)) {
				availableMOnths.add(3);
			}
			if (!availableMOnths.contains(4)) {
				availableMOnths.add(4);
			}
			if (!availableMOnths.contains(5)) {
				availableMOnths.add(5);
			}
			if (!availableMOnths.contains(6)) {
				availableMOnths.add(6);
			}
			if (!availableMOnths.contains(7)) {
				availableMOnths.add(7);
			}
			if (!availableMOnths.contains(8)) {
				availableMOnths.add(8);
			}
			if (!availableMOnths.contains(9)) {
				availableMOnths.add(9);
			}
			if (!availableMOnths.contains(10)) {
				availableMOnths.add(10);
			}
			if (!availableMOnths.contains(11)) {
				availableMOnths.add(11);
			}
			if (!availableMOnths.contains(12)) {
				availableMOnths.add(12);
			}
		}
		return availableMOnths;
	}

	private List<Integer> getAllAvailableYears(List<Integer> availableYears, int yearf) {
		if (availableYears.size() < 10) {
			for (int i = availableYears.size(); i < 10; i++) {
				if (!availableYears.contains(yearf)) {
					availableYears.add(yearf);
				}
				yearf--;
			}
		}
		return availableYears;
	}

	@RequestMapping(value = "monthlyCdreportprogram")
	public String monthlyCdreportprogram(Model model, @ModelAttribute CdReportProgram filteredYear,
			HttpServletRequest request, @RequestParam int id) {

		CdReportProgram selectedReport = cdReportPgmService.getReportById(id);
		List<CdReportProgram> monthlyCDreport = cdReportPgmService.getAllCDreportprogram();
		CdReportProgram monthlyCDreport1 = monthlyCDreport.get(0);
		Integer year = filteredYear.getYear();

		String m = null;

		for (CdReportProgram monthlyCDreport2 : monthlyCDreport) {
			int month = monthlyCDreport2.getMonth();

			m = Month.of(month).name();
			System.out.println("month" + m);

		}

		HttpSession session = request.getSession();
		session.setAttribute("year", year);
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		session.setAttribute("month", m);

		model.addAttribute("monthlyCDreport", monthlyCDreport);
		model.addAttribute("monthlyCDreport1", monthlyCDreport1);
		model.addAttribute("month", m);

		List<CdReportProgram> filteredReport = new ArrayList<CdReportProgram>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		if (null != monthlyCDreport) {
			for (CdReportProgram report : monthlyCDreport) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {
						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyCDreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyCDreport));
		return "monthlyCdreportprogram";
	}

	@RequestMapping(value = "monthlyCdreportprogram_submit")
	public String monthlyCdreportprogram_submit(Model model, @ModelAttribute CdReportProgram filteredYear,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		String distriName = filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		Integer selectedDistrict = 0;
		String districtName = "";
		if (null != filteredYear.getDistrictMaster()) {
			selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
			districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear = filteredYear.getYear();

		List<CdReportProgram> monthlyCDreport = cdReportPgmService.getAllCDreportprogram();
		CdReportProgram monthlyCDreport1 = monthlyCDreport.get(0);
		model.addAttribute("monthlyCDreport1", monthlyCDreport1);
		List<CdReportProgram> filteredReport = new ArrayList<CdReportProgram>();
		if (null != monthlyCDreport1) {
			for (CdReportProgram report : monthlyCDreport) {
				if (selectedYear.intValue() == report.getYear().intValue()) {
					if (null != report.getDistrictMaster()
							&& districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
						// && selectedDistrict == report.getDistrictMaster().getDistrictId()
						filteredReport.add(report);
					}
				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyCDreport));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyCDreport));
		return "monthlyCdreportprogram";
	}

	private List<Integer> getUniqueYear(List<CdReportProgram> monthlyCDreport) {
		List<Integer> years = new ArrayList<Integer>();
		if (null != monthlyCDreport) {

			for (CdReportProgram report : monthlyCDreport) {
				if (!years.contains(report.getYear())) {
					years.add(report.getYear());
				}
			}
		}
		return years;

	}

	private List<String> getUniqueDistrictName(List<CdReportProgram> monthlyCDreport) {
		List<String> districtName = new ArrayList<String>();
		if (null != monthlyCDreport) {
			for (CdReportProgram report : monthlyCDreport) {
				if (null != report.getDistrictMaster()
						&& !districtName.contains(report.getDistrictMaster().getDistrictName())) {
					districtName.add(report.getDistrictMaster().getDistrictName());
				}
			}
		}
		return districtName;

	}

	@RequestMapping("/editMonthlyCDreportprogram")
	public String editMonthlyCDreportprogram(Model model, @RequestParam int id) {

		CdReportProgram cdreportprogram = new CdReportProgram();
		CdReportProgram editMonthlyReport = cdReportPgmService.getReportById(id);
		// model.addAttribute("cdreportprogram", cdreportprogram);
		model.addAttribute("editMonthlyReport", editMonthlyReport);
		return "editMonthlyCDreportprogram";
	}

	@RequestMapping("updateMonthlyCdReportProgram")

	public String updateMonthlyCdReportProgram(@RequestParam int cdId,
			@ModelAttribute CdReportProgram updateCdReportProgram, final BindingResult result,
			HttpServletRequest request, Model model, final RedirectAttributes redirectAttributes) {

		Date sectedDate = updateCdReportProgram.getCreatedDate();
		CdReportProgram editCdreportprogram = cdReportPgmService.getReportById(cdId);
		Integer disID = editCdreportprogram.getDistrictMaster().getDistrictId();
		System.out
				.println("inside the updateMonthly::" + sectedDate + "id::" + editCdreportprogram + "disID::" + disID);
		List<CdReportProgram> monthlyCdreportprogram = cdReportPgmService.getAllCDreportprogram();
		CdReportProgram monthlyCdreport1 = monthlyCdreportprogram.get(0);
		CdReportProgram cdreportprogram = new CdReportProgram();
		model.addAttribute("cdreportprogram", cdreportprogram);
		if (!cdReportPgmService.isReportExistForSelectedMonthAndYearEdit(sectedDate, disID, editCdreportprogram)) {
			Date createdDate = updateCdReportProgram.getCreatedDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			updateCdReportProgram.setDate(day);
			updateCdReportProgram.setMonth(month);
			updateCdReportProgram.setYear(year);

			cdReportPgmService.updateCDreportprogram(updateCdReportProgram);
			redirectAttributes.addFlashAttribute("css", "success");
			redirectAttributes.addFlashAttribute("msg", "Record updated successfully!");
			
		} else {
			System.out.println("Not Updated Successfully---!!!------------");
		}
		return "redirect:cdreportprogramlist";
	}

	@RequestMapping(value = "deleteCDreportprogram")
	public ModelAndView deleteEmployee(HttpServletRequest request, final RedirectAttributes redirectAttributes) {
		int cdreportprogramId = Integer.parseInt(request.getParameter("id"));
		cdReportPgmService.deleteCDreportprogram(cdreportprogramId);
		System.out.println("Report deleted successfully");

		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "Record is deleted!");
		return new ModelAndView("redirect:cdreportprogramlist");
	}

	@RequestMapping(value = "viewReport")

	public String viewReport(Model model, @RequestParam int id) {

		CdReportProgram cdreportprogram = new CdReportProgram();
		CdReportProgram view = cdReportPgmService.getReportById(id);
		model.addAttribute("view", view);
		return "viewReport";
	}

	@RequestMapping(value = "checkDate", method = RequestMethod.POST)
	@ResponseBody
	public String checkDate(@RequestParam String date) {

		boolean error = false;
		System.out.println("inside checkDate method");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		System.out.println(date1 + "--------");
		String[] arrOfStr1 = date1.split("-");
		int year = Integer.valueOf(arrOfStr1[0]);
		int month = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);

		CdReportProgram cdreportprogram = cdReportPgmService.getMonthlyReportByMonthYearDistrict(year, month, did);
		System.out.println("cdreportprogram" + cdreportprogram);

		if (cdreportprogram != null) {
			System.out.println("Report is allready exist for the selected date and district");

			List<DistrictMaster> distList = iDistrictService.getDistrictMasterList();

			error = true;

		}
		System.out.println("check2");
		System.out.println(error + "--------------");
		return "" + error;

	}

	@RequestMapping(value = "updateCdReportProgram")
	public String getDistrictName(@ModelAttribute @Valid CdReportProgram cdreportprogram, final BindingResult result,
			@RequestParam String date, Model model, final RedirectAttributes redirectAttributes)

	{
		System.out.println("test inside updateCdReportProgram");

		System.out.println("checkDate");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);

		String[] arrOfStr1 = date1.split("-");
		int year = Integer.valueOf(arrOfStr1[0]);
		int month = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);

		CdReportProgram cdlist = cdReportPgmService.getMonthlyReportByMonthYearDistrict(year, month, did);
		System.out.println("test" + cdlist);
		// model.put("monthlyReportAll", list);
		model.addAttribute("updateCdReportProgram", cdlist);
		return "updateCdReportProgram";

	}

	@RequestMapping(value = "cdReportProgramPdf", method = RequestMethod.GET)
	public ModelAndView downloadCdreportprogram() {
		List<CdReportProgram> cdreportprogram = cdReportPgmService.getAllCDreportprogram();

		return new ModelAndView("cdreportprogrampdf", "cdreportprogram", cdreportprogram);
	}

	@RequestMapping(value = "cdReportProgramExcel", method = RequestMethod.GET)
	public ModelAndView downloadExcelCdReportProgram() {
		List<CdReportProgram> cdreportprogramlist1 = cdReportPgmService.getAllCDreportprogram();
		return new ModelAndView("cdreportprogramexcel", "cdreportprogramlist1", cdreportprogramlist1);
	}

}
