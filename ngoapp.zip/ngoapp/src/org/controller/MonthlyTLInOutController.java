package org.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.dto.DistrictMaster;
import org.dto.MonthlyTLIN;
import org.service.IDistrictService;
import org.service.IMonthlyTLInOutService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MonthlyTLInOutController {
	private static final Logger logger = LoggerFactory.getLogger(MonthlyTLInOutController.class);
	
	@Autowired
	IMonthlyTLInOutService iMonthlyTLInOutService;
	
	@Autowired
	IDistrictService iDistrictService;
	
	@RequestMapping(value="monthly_inout")
	public String MonthlyTLInOut(Model model)
	{
		System.out.println("Inside MonthlyTLInOut Controller");
		
		MonthlyTLIN monthlyTLInOut= new MonthlyTLIN();
	
		model.addAttribute("monthlyTLINOUT", monthlyTLInOut);
		
		List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);
		
		for(DistrictMaster d : districtMaster) {
            System.out.println(d.getDistrictName());
        }
		return "createTL";

    }
	

	
	@RequestMapping(value = "saveTL", method = RequestMethod.POST)
	public String saveTL(@ModelAttribute MonthlyTLIN monthlyTLIN, final BindingResult result, Model model,
			@ModelAttribute("monthlyTLINOUT") @Validated MonthlyTLIN mtTLINOUT, final RedirectAttributes redirectAttributes) {
          
		System.out.println("Creating TL Details"); 
		
		Date createdDate = monthlyTLIN.getCreatedDate();
		Integer districtId = monthlyTLIN.getDistrictMaster().getDistrictId();
		
		System.out.println("districtName::" + districtId);
		System.out.println("createdDate::"+createdDate);
		
		if (!iMonthlyTLInOutService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;			
			int year = cal.get(Calendar.YEAR);
						
			monthlyTLIN.setMonth(month);
			monthlyTLIN.setYear(year);
			monthlyTLIN.getMonth();
			
			Date d = new Date();
			if (createdDate.equals(d)) {
				monthlyTLIN.setCreatedDate(d);
			} 
			   monthlyTLIN.setModifiedDate(d);
			iMonthlyTLInOutService.saveMonthlyTLIn(monthlyTLIN);
			redirectAttributes.addFlashAttribute("msg", "TL added successfully!");
			return "redirect:tLList";
		} else {
			model.addAttribute("Error", "Record Exists for Selected Month and year");

			System.out.println("Record Exists for Selected Month and year");

		}
		return "redirect:createTL";
	}
	
	
	@RequestMapping(value = "addTLOut")
	public String addTLOut(@ModelAttribute @Valid MonthlyTLIN monthlyTLIN, final BindingResult result,
			Model model, @ModelAttribute("monthlyTLINOUT") @Validated MonthlyTLIN mtlout) {

		Date createdDate = monthlyTLIN.getCreatedDate();
		Integer districtId = monthlyTLIN.getDistrictMaster().getDistrictId();
		System.out.println("districtName::" + districtId);
		if (!iMonthlyTLInOutService.isReportExistForSelectedMonthAndYear(createdDate, districtId)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(createdDate);
			int month = cal.get(Calendar.MONTH) + 1;
			System.out.println("Record Exists for Selected Month and year" + month);
			int day = cal.get(Calendar.DATE);
			int year = cal.get(Calendar.YEAR);
			// report.setDate(day);
			
			monthlyTLIN.setMonth(month);
			monthlyTLIN.setYear(year);
			monthlyTLIN.getMonth();
			
			Date d = new Date();
			
			if (createdDate.equals(d)) {
				monthlyTLIN.setCreatedDate(d);
			}
			// monthlyTLIN.setCreated_Date(d);
			monthlyTLIN.setModifiedDate(d);
			iMonthlyTLInOutService.saveMonthlyTLIn(monthlyTLIN);
			return "redirect:tLList";
		} else {
			model.addAttribute("Error", "Record Exists for Selected Month and year");

			System.out.println("Record Exists for Selected Month and year");

		}
		return "redirect:tLOut";
	}
	
	@RequestMapping(value = "updateTL")
	public String getDistrictName(@ModelAttribute @Valid MonthlyTLIN monthlyTLIN, final BindingResult result,
			@RequestParam String date, Model model)

	{
		System.out.println("test inside monthlyTLUpdate");

		System.out.println("checkmonth");
		String[] arrOfStr = date.split("/");
		
		
		   String date1 =String.valueOf(arrOfStr[0]);
		   String[] arrOfStr1 = date1.split("-");
		   int y =Integer.valueOf(arrOfStr1[0]);
		   int m =Integer.valueOf(arrOfStr1[1]);

			int did = Integer.valueOf(arrOfStr[1]);
			
			
			System.out.println("check did" + did);
			System.out.println("check did" + date1);
		System.out.println("check did" + did);
		MonthlyTLIN list = iMonthlyTLInOutService.getMonthlyreportAll(y, did, m);

		System.out.println("test" + list);
		// model.put("monthlyReportAll", list);
		model.addAttribute("update", list);
		return "updateTL";

	}

	
	@RequestMapping(value="updateTLInOutDismiss")
	public String updateTLInOutDismiss(@ModelAttribute MonthlyTLIN monthlyTLIN, final BindingResult result, @RequestParam("createdDate") String createdDate) throws ParseException
	{
		System.out.println("inside updateTLInOutDismiss");
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d = format.parse(createdDate.substring(0, createdDate.length()-2));
		
		System.out.println("date-----"+d);
		Date m = new Date();
		monthlyTLIN.setModifiedDate(m);
		monthlyTLIN.setCreatedDate(d);
		
		iMonthlyTLInOutService.updateTLInOutDismiss(monthlyTLIN);
			     return "redirect:tLList";
	}
	
	@RequestMapping(value="editTLIn")
	public String editTLIn(@RequestParam long mtlId, Model model){
		
	 System.out.println("inside edit");
		System.out.println("id"+mtlId);
		MonthlyTLIN tLin=iMonthlyTLInOutService.getByMtlId(mtlId);
		System.out.println("tLin"+tLin);
		model.addAttribute("monthlyTLInOut",tLin);
		if(tLin.getMemberStatus()==0)
		{
			return "tLinEdit";
		}
		else if (tLin.getMemberStatus()==1) {
			return "tLOutEdit";
		}
		else
			return "dismissedEdit";
	}
	
	@RequestMapping(value="tLOut")
	public String CreateTLOut(Model model)
	{
		System.out.println("MonthlyTLInOut page");
		
		MonthlyTLIN monthlyTLInOut= new MonthlyTLIN();
	
		model.addAttribute("monthlyTLINOUT", monthlyTLInOut);
		
		List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		for(DistrictMaster d : districtMaster) {
            System.out.println(d.getDistrictName());
        }
		
		return "tLOut";

    }
	
	
	
	@RequestMapping(value="dismissedDetails")
	public String CreateDismissedDetails(Model model)
	{
		System.out.println("dismissedDetails");
		
		MonthlyTLIN monthlyTLInOut= new MonthlyTLIN();
	
		model.addAttribute("monthlyTLInOut", monthlyTLInOut);
		
		List<DistrictMaster> districtMaster=iDistrictService.getDistrictMasterList();
		model.addAttribute("districtMaster", districtMaster);

		for(DistrictMaster d : districtMaster) {
            System.out.println(d.getDistrictName());
        }
		return "dismissedDetails";

    }
	
	@RequestMapping(value="addTLDismiss")
	 public String addTLDismiss(@ModelAttribute MonthlyTLIN monthlyTLIN1,final BindingResult result,Model model)
	 {
		System.out.println("in addTLDismiss");
      String Null = "0";
	  Date d = new Date();
	  monthlyTLIN1.setCreatedDate(d);
	  monthlyTLIN1.setModifiedDate(d);
	  monthlyTLIN1.setTypeofTL(Null);
	  iMonthlyTLInOutService.saveMonthlyTLIn(monthlyTLIN1);
	  
	  List<MonthlyTLIN> monthlyTLIN=iMonthlyTLInOutService.getMonthlyTLINList();
	  model.addAttribute("monthlyTLIN", monthlyTLIN);
	  return "dismissedList";
	 }
	
	@RequestMapping(value="deleteTLInOut")
	public ModelAndView deleteTLInout(@RequestParam long mtlId){
		this.iMonthlyTLInOutService.deleteTLInOut(mtlId);
	
		return new ModelAndView("redirect:tLList");
	}
	
	@RequestMapping(value = "viewMonthlyTLInOut")
	public String viewMonthlyTLInOut(@RequestParam long mtlId, Model model) {

		System.out.println("inside ViewMonthlyTLInOut");
		System.out.println("id" + mtlId);
		MonthlyTLIN district = iMonthlyTLInOutService.getByMtlId(mtlId);
		System.out.println("district" + district);
		model.addAttribute("district", district);

		return "viewMonthlyTLInOut";

	}
	
	
	
	@SuppressWarnings("unused")
	@RequestMapping(value="tLList")
    public String tLList(Model model, @ModelAttribute MonthlyTLIN filteredYear,
            HttpServletRequest request) throws Exception
    {
        System.out.println("inside tLList");
        //List<MonthlyTLIN> monthlyTLIN1 = new ArrayList<MonthlyTLIN>();
        List<MonthlyTLIN> monthlyTLIN=iMonthlyTLInOutService.getMonthlyTLINList();
        MonthlyTLIN year = new MonthlyTLIN();
        model.addAttribute("monthlyTLIN", monthlyTLIN);
        model.addAttribute("year", year);
        
        Integer fiYear = filteredYear.getYear();
        Integer currentMonth = filteredYear.getMonth();

        HttpSession session = request.getSession();
        session.setAttribute("fiYear", fiYear);               
        session.setAttribute("currentMonthToDisplay",String.valueOf(currentMonth));
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DATE);
        int yearf = cal.get(Calendar.YEAR);
        if(null== currentMonth) {
            //First Time value
            currentMonth = month;
        }

        session.setAttribute("currentMonth", currentMonth);
        List<MonthlyTLIN> filteredYearReports = new ArrayList<MonthlyTLIN>();
        
        List<MonthlyTLIN> filtereMOnthsReports = new ArrayList<MonthlyTLIN>();
        
        Map<Integer, Integer> filteredYearAndMonth = new HashMap<Integer, Integer>();
        if (fiYear == null) {
            fiYear = yearf;

        }
        if (currentMonth == null) {
            currentMonth = month;

        }
         System.out.println("gfvhgsjuv");
        List<Integer> availableYears = new ArrayList<Integer>();
        List<Integer> availableMOnths = new ArrayList<Integer>();

        for (MonthlyTLIN reportYr : monthlyTLIN) {
            if (!availableYears.contains(reportYr.getYear())) {
                availableYears.add(reportYr.getYear());
            }
            if (!availableMOnths.contains(reportYr.getMonth())) {
                availableMOnths.add(reportYr.getMonth());
            }
            if (reportYr.getYear().intValue() == fiYear && reportYr.getMonth().intValue() == currentMonth) {
                filteredYearReports.add(reportYr);

            } else {
                System.out.println("else :::");
            }
           if (null != filteredYearReports && !filteredYearReports.isEmpty()) {
                MonthlyTLIN preport = filteredYearReports.get(0);
                if (null != preport.getDistrictMaster()) {
                    String distName = preport.getDistrictMaster().getDistrictName();
                    int distId = preport.getDistrictMaster().getDistrictId();
                    request.getSession().setAttribute("distName", distName);
                    request.getSession().setAttribute("distId", distId);
                }
            }
            model.addAttribute("monthlyTLIN", filteredYearReports);
            model.addAttribute("availableYears", availableYears);
            // model.addAttribute("availableMOnths", availableMOnths);
            availableYears = getAllAvailableYears(availableYears, yearf);
            model.addAttribute("availableMOnths", getAvailableMonths(availableMOnths));
        }
        
        return "tLList";
    }
    
    private List<Integer> getAvailableMonths(List<Integer> availableMOnths) {
        if (null != availableMOnths) {
            if (!availableMOnths.contains(1)) {
                availableMOnths.add(1);
            }
            if (!availableMOnths.contains(2)) {
                availableMOnths.add(2);
            }
            if (!availableMOnths.contains(3)) {
                availableMOnths.add(3);
            }
            if (!availableMOnths.contains(4)) {
                availableMOnths.add(4);
            }
            if (!availableMOnths.contains(5)) {
                availableMOnths.add(5);
            }
            if (!availableMOnths.contains(6)) {
                availableMOnths.add(6);
            }
            if (!availableMOnths.contains(7)) {
                availableMOnths.add(7);
            }
            if (!availableMOnths.contains(8)) {
                availableMOnths.add(8);
            }
            if (!availableMOnths.contains(9)) {
                availableMOnths.add(9);
            }
            if (!availableMOnths.contains(10)) {
                availableMOnths.add(10);
            }
            if (!availableMOnths.contains(11)) {
                availableMOnths.add(11);
            }
            if (!availableMOnths.contains(12)) {
                availableMOnths.add(12);
            }
        }
        return availableMOnths;
    }

    private List<Integer> getAllAvailableYears(List<Integer> availableYears, int yearf) {
        if (availableYears.size() < 12) {
            for (int i = availableYears.size(); i < 12; i++) {
                if (!availableYears.contains(yearf)) {
                    availableYears.add(yearf);
                }
                yearf--;
            }
        }
        return availableYears;
    }

	@RequestMapping(value="tLListAllMonths")
	public String tLListAllMonths(@RequestParam long mtlId, @RequestParam String typeofTL,@ModelAttribute MonthlyTLIN filteredYear, HttpServletRequest request,
			Model model) throws Exception
	{
		System.out.println("id"+mtlId);
		System.out.println("inside tLListAllMonths");
		
		MonthlyTLIN selectedReport = iMonthlyTLInOutService.getByMtlId(mtlId);
		List<MonthlyTLIN> monthlyTLIN1 = new ArrayList<MonthlyTLIN>();
		List<MonthlyTLIN> monthlyTLIN=iMonthlyTLInOutService.getMonthlyTLINList(typeofTL);
		
		System.out.println("after");
		/*
		 * Calendar cal = Calendar.getInstance(); cal.setTime(new Date()); int m1 =
		 * cal.get(Calendar.MONTH) + 1; int y = cal.get(Calendar.YEAR);
		 * 
		 * for(MonthlyTLIN m: monthlyTLIN){
		 * 
		 * if(y==m.getYear()){ monthlyTLIN1.add(m); }else{
		 * model.addAttribute("monthlyTLIN", monthlyTLIN); } }
		 */
		MonthlyTLIN monthlyreport1 = monthlyTLIN.get(0);
		Integer year = filteredYear.getYear();
		
		
		HttpSession session = request.getSession();
		session.setAttribute("year", year);
		String distriName = selectedReport.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);

		model.addAttribute("monthlyTLIN", monthlyTLIN);
		model.addAttribute("monthlyreport1", monthlyreport1);
		List<MonthlyTLIN> filteredReport = new ArrayList<MonthlyTLIN>();
		int selectedYear = 0;
		int selectedDistrict = 0;
		if (null != selectedReport) {
			selectedYear = selectedReport.getYear();
			selectedReport.getMonth();
			selectedDistrict = selectedReport.getDistrictMaster().getDistrictId();
		}

		if (null != monthlyTLIN) {
			for (MonthlyTLIN report : monthlyTLIN) {
				if (selectedYear == report.getYear()) {
					if (selectedDistrict > 0) {

						if (null != report.getDistrictMaster()
								&& selectedDistrict == report.getDistrictMaster().getDistrictId()) {
							filteredReport.add(report);
						}
					} else {
						if (null != report.getDistrictMaster()) {
							selectedDistrict = report.getDistrictMaster().getDistrictId();
							filteredReport.add(report);
						}
					}

				}
			}
		}
		String m = null;
		List<String> filteredReport1 = new ArrayList<String>();
		for (MonthlyTLIN monthlyreport2 : monthlyTLIN) {
			
			int month = monthlyreport2.getMonth();

			m = Month.of(month).name();
			//m=Month.of(month).getDisplayName(TextStyle.FULL_STANDALONE, locale);
			filteredReport1.add(m);
			//filteredReport.addAll(filteredReport1);
			System.out.println("month" + m);

		}	
		
		model.addAttribute("monthlyTLIN", monthlyTLIN1);
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("month", filteredReport1);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyTLIN));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyTLIN));
		return "tLListAllMonths";
	}
	
	@RequestMapping(value="searchYearMonth")
	public String searchYearMonth(Model model, @ModelAttribute MonthlyTLIN filteredYear,
			HttpServletRequest request){
		
		System.out.println("inside searchYearMonth"+request);
		
		HttpSession session = request.getSession();
		String distriName = filteredYear.getDistrictMaster().getDistrictName();
		session.setAttribute("distriName", distriName);
		Integer selectedDistrict = 0;
		String districtName = "";
		if (null != filteredYear.getDistrictMaster()) {
			selectedDistrict = filteredYear.getDistrictMaster().getDistrictId();
			districtName = filteredYear.getDistrictMaster().getDistrictName();
		}
		Integer selectedYear = filteredYear.getYear();

		List<MonthlyTLIN> monthlyTLIN = iMonthlyTLInOutService.getMonthlyTLINList();
		MonthlyTLIN monthlyreport1 = monthlyTLIN.get(0);
		model.addAttribute("monthlyreport1", monthlyreport1);
		List<MonthlyTLIN> filteredReport = new ArrayList<MonthlyTLIN>();
		if (null != monthlyTLIN) {
			for (MonthlyTLIN report : monthlyTLIN) {
				if (selectedYear.intValue() == report.getYear().intValue()) {
					if (null != report.getDistrictMaster()
							&& districtName.equalsIgnoreCase(report.getDistrictMaster().getDistrictName())) {
						// && selectedDistrict == report.getDistrictMaster().getDistrictId()
						filteredReport.add(report);
					}
				}
			}
		}
		model.addAttribute("filteredReport", filteredReport);
		model.addAttribute("uniqueyears", getUniqueYear(monthlyTLIN));
		model.addAttribute("uniqueDistrictNames", getUniqueDistrictName(monthlyTLIN));
		return "tLListAllMonths";
		
	}

	private Object getUniqueDistrictName(List<MonthlyTLIN> monthlyTLIN) {
		List<String> districtName = new ArrayList<String>();
		if (null != monthlyTLIN) {
			for (MonthlyTLIN report : monthlyTLIN) {
				if (null != report.getDistrictMaster()
						&& !districtName.contains(report.getDistrictMaster().getDistrictName())) {
					districtName.add(report.getDistrictMaster().getDistrictName());
				}
			}
		}
		return districtName;
	}

	private Object getUniqueYear(List<MonthlyTLIN> monthlyTLIN) {
		List<Integer> years = new ArrayList<Integer>();
		if (null != monthlyTLIN) {
			for (MonthlyTLIN report : monthlyTLIN) {
				if (!years.contains(report.getYear())) {
					years.add(report.getYear());
				}
			}
		}
		return years;
	}
	
	@RequestMapping(value = "checkMonthTL", method = RequestMethod.POST)
	@ResponseBody
	public String Checkmonth(@RequestParam String date)

	{
		boolean error = false;
		System.out.println("inside  checkMonthTL controller");
		
		String[] arrOfStr = date.split("/");		
		 String date1 =String.valueOf(arrOfStr[0]);
		 int did = Integer.valueOf(arrOfStr[1]);		 
			System.out.println(date1+""+did);			
		 String[] arrOfStr1 = date1.split("-");// here we will get the year month and date 
		 
		 int year = Integer.valueOf(arrOfStr1[0]);
		 int month = Integer.valueOf(arrOfStr1[1]);
		 
		 
		 
		 System.out.println("check did" +" "+did);
		 System.out.println("check did" +" "+date1);						
		System.out.println("month"+" "+month+" "+"year"+" "+year);
		
		MonthlyTLIN tl=null;
		try {
			 tl= iMonthlyTLInOutService.getReportByMonthYearDistrict(year,month,did);
			System.out.println("hi" + tl);
			
		} catch (Exception e) {
			
		}
	
		
		if(tl!=null){
			System.out.println("report present for this month");
			@SuppressWarnings("unused")
			List<DistrictMaster> districtMaster = iDistrictService.getDistrictMasterList();

			error = true;
		}
		System.out.println("check2------------");
		
		return "" + error;
		
	}
	
	@RequestMapping(value = "monthlyTLpdf", method = RequestMethod.GET)
	public ModelAndView pdfdownload() {
		
		System.out.println("inside monthlyTLpdf");
		List<MonthlyTLIN> monthlytlpdf =iMonthlyTLInOutService.getTLAllreport();

		return new ModelAndView("monthlyTLpdf", "monthlytlpdf", monthlytlpdf);
	}
	
	@RequestMapping(value = "monthlyTLExcell", method = RequestMethod.GET)
	public ModelAndView downloadExcel() {
		
		System.out.println("inside monthlyTLexcell");
	  	List<MonthlyTLIN> monthlyTLexcell=iMonthlyTLInOutService.getTLAllreport();
	      return new ModelAndView("monthlyTLExcell","monthlyTLexcell",monthlyTLexcell);
	  }
	
	@RequestMapping(value = "monthlyTLUpdate")
	public String getDistrictName(@ModelAttribute("monthlyTLINOUT") @Valid MonthlyTLIN monthlyTLINOUT, final BindingResult result,
			@RequestParam String date, Model model, final RedirectAttributes redirectAttributes)

	{
		System.out.println("test inside monthlyTLUpdate");

		System.out.println("checkmonth");
		String[] arrOfStr = date.split("/");

		String date1 = String.valueOf(arrOfStr[0]);
		String[] arrOfStr1 = date1.split("-");
		int y = Integer.valueOf(arrOfStr1[0]);
		int m = Integer.valueOf(arrOfStr1[1]);

		int did = Integer.valueOf(arrOfStr[1]);

		System.out.println("check did" + did);
		System.out.println("check did" + date1);
		System.out.println("check did" + did);
		MonthlyTLIN list = iMonthlyTLInOutService.getMonthlyreportAll(y, did, m);

		System.out.println("test" + list);
		// model.put("monthlyReportAll", list);
		model.addAttribute("update", list);
		return "update";

	}
	
	
	
	
}